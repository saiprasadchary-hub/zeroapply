import test from 'node:test';
import assert from 'node:assert/strict';
import { visualContext } from '../desktop/visual-context.mjs';

test('visual context bounds page data, preserves exact facts and original target IDs', () => {
  const result = visualContext({ goal: 'Apply for Python internships', facts: { fullName: 'Test Applicant', experienceYears: '0', longResume: 'x'.repeat(12000) }, history: [], resume: null }, {
    url: 'https://example.com/jobs', title: 'Jobs', text: 'x'.repeat(12000),
    targets: Array.from({ length: 180 }, (_, id) => ({ id, tag: 'button', type: '', label: id === 179 ? 'Easy Apply' : `Navigation ${id}`, value: '' })),
  });
  assert.equal(result.facts.fullName, 'Test Applicant');
  assert.equal(result.facts.experienceYears, '0');
  assert.equal(result.facts.longResume, undefined);
  assert.equal(result.observation.text.length, 1600);
  assert.equal(result.observation.targets[0].id, 179);
  assert.ok(JSON.stringify(result).length < 6000);
});
