import assert from 'node:assert/strict';
import test from 'node:test';
import { VisualWorkflowController, profileFacts } from '../src/agent/visualWorkflow/controller';
import type { PersonaData } from '../src/types';
import type { VisualPage } from '../src/agent/visualWorkflow/controller';
import type { VisualStep } from '../src/agent/visualWorkflow/types';
import type { AgentActivity } from '../src/agent/visualWorkflow/activity';

const persona: PersonaData = { fullName: 'Synthetic Applicant', email: 'test@example.com', phone: '123', location: 'Hyderabad', linkedIn: '', gitHub: '', portfolio: '', experienceYears: 0, minSalary: 0, workPreference: 'Remote', tone: 'Minimalist', techStack: ['Python'], targetRoles: ['Python Internship'], applyMode: 'easy', verified: true, applicationLimit: 1 };
function harness() {
  const store = new Map<string, string>();
  let submitted = false;
  let confirmed = true;
  let acts = 0;
  let decisions = 0;
  let late: (() => void) | undefined;
  let delay = false;
  const page: VisualPage = { getWebContentsId: () => 12, getURL: () => 'https://example.com/jobs/1', loadURL: async () => {}, executeJavaScript: async <T>(script: string): Promise<T> => {
    if (script.includes('confirmationPatterns')) return { isConfirmed: submitted && confirmed, reason: 'Website receipt' } as T;
    return { jobTitle: 'Python Internship', companyName: 'Fixture', skillsRequired: [], rawDescriptionText: '', jobSummary: '' } as T;
  } };
  const bridge = { isDesktop: true, startVisualWorkflow: async () => {}, stopVisualWorkflow: async () => {},
    secureGet: (key: string) => store.get(key) || null,
    secureSet: async (key: string, value: string) => { store.set(key, value); return true; },
    decideVisualWorkflow: async (): Promise<VisualStep> => {
      decisions++;
      if (delay) await new Promise<void>(resolve => { late = resolve; });
      return { observation: { id: 'observation', url: page.getURL(), title: 'Python Internship', text: '', jobKey: 'job-1', targets: [] }, decision: { action: 'submit', target: 0, factKey: '', reason: 'Submit completed application', direction: 'down' } };
    },
    actVisualWorkflow: async () => { acts++; submitted = true; return { submitted: true }; },
  };
  Object.assign(globalThis, { window: { zeroApply: bridge } });
  return { store, page, bridge, acts: () => acts, decisions: () => decisions, unconfirmed: () => { confirmed = false; }, delay: () => { delay = true; }, release: () => late?.() };
}
test('facts preserve zero experience and never invent an answer', () => {
  const facts = profileFacts(persona);
  assert.equal(facts.experienceYears, '0'); assert.equal(facts.firstName, 'Synthetic');
  assert.equal(facts.workAuthorization, undefined);
});
test('one submission plus fresh website confirmation completes the target and persists the lease', async () => {
  const h = harness(); const messages: string[] = []; const activity: AgentActivity[] = [];
  await new VisualWorkflowController().run({ persona, page: h.page, currentPage: () => h.page, returnToSearch: async () => {}, notify: message => { messages.push(message); }, onActivity: event => { activity.push(event); }, isActive: () => true });
  assert.equal(h.acts(), 1); assert.equal(h.decisions(), 1);
  assert.match(h.store.get('zeroapply_visual_application_ledger') || '', /confirmed/);
  assert.ok(messages.some(message => message.includes('1/1 applications confirmed')));
  assert.ok(activity.some(event => event.phase === 'verifying'));
  assert.ok(activity.some(event => event.phase === 'confirmed' && event.confirmed === 1));
  assert.equal(activity.at(-1)?.phase, 'completed');
});
test('a previous unconfirmed submission blocks another submit', async () => {
  const h = harness(); h.store.set('zeroapply_visual_application_ledger', JSON.stringify({ 'test@example.com|job-1': { outcome: 'unconfirmed', at: Date.now() } }));
  await assert.rejects(new VisualWorkflowController().run({ persona, page: h.page, currentPage: () => h.page, returnToSearch: async () => {}, notify: () => {}, isActive: () => true }), /previously submitted/);
  assert.equal(h.acts(), 0);
});
test('stopping during inference prevents a late decision from dispatching', async () => {
  const h = harness(); h.delay(); const controller = new VisualWorkflowController();
  const running = controller.run({ persona, page: h.page, currentPage: () => h.page, returnToSearch: async () => {}, notify: () => {}, isActive: () => true });
  await new Promise<void>(resolve => setTimeout(resolve, 10)); controller.stop(); h.release(); await running;
  assert.equal(h.acts(), 0);
});
