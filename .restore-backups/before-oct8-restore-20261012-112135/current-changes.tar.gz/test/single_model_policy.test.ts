import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { getActiveModelName, ONLY_LLM_MODEL } from '../src/agent/llm/ollamaClient';

interface DesktopPackage {
  dependencies: Record<string, string>;
  scripts: Record<string, string>;
  build: { extraResources?: unknown[]; asarUnpack?: string[] };
}

const packageConfig = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')) as DesktopPackage;
const main = readFileSync(new URL('../main.js', import.meta.url), 'utf8');
const router = readFileSync(new URL('../desktop/local-model-router.mjs', import.meta.url), 'utf8');

assert.equal(ONLY_LLM_MODEL, 'qwen3.5:4b');
assert.equal(getActiveModelName(), ONLY_LLM_MODEL);
assert.equal(packageConfig.dependencies['node-llama-cpp'], undefined, 'Desktop must not install a separate inference runtime');
assert.equal(packageConfig.scripts['model:download'], undefined, 'Desktop must not download standalone weights');
assert.equal(packageConfig.build.extraResources, undefined, 'Desktop must not package standalone model weights');
assert.doesNotMatch(main, /EmbeddedModelService|utilityProcess|verify-bundled-model/);
assert.match(main, /localModel\.enableAlwaysOn\(\)/, 'Ollama must connect automatically at app startup');
assert.match(router, /http:\/\/127\.0\.0\.1:11434\/api\//);
assert.doesNotMatch(router, /node-llama-cpp|model-runtime|EmbeddedModelService/);

console.log('Ollama-only exact-model policy checks passed.');
