import assert from 'node:assert/strict';
import { auditFormFields } from '../src/agent/formFiller/formAuditor';
import { WizardStepNavigator } from '../src/agent/navigation/wizardStepNavigator';
import type { WebviewTarget } from '../src/agent/domScanner/injectedScanner';
import { matchSelectOption } from '../src/agent/formFiller/optionMatching';

const failingView: WebviewTarget = {
  executeJavaScript: async <T>(): Promise<T> => { throw new Error('Navigation destroyed execution context'); },
};
assert.equal((await auditFormFields(failingView)).ready, false);
const malformedView: WebviewTarget = { executeJavaScript: async <T>(): Promise<T> => ({}) as T };
assert.equal((await auditFormFields(malformedView)).ready, false);
const contradictoryView: WebviewTarget = {
  executeJavaScript: async <T>(): Promise<T> => ({ ready: true, missingRequired: ['Email'], unansweredQuestions: [], errors: [] }) as T,
};
assert.equal((await auditFormFields(contradictoryView)).ready, false);

const navigator = new WizardStepNavigator();
navigator.detectForwardButton = async () => ({ exists: true, action: 'next', selector: '#next', text: 'Next', disabled: true });
let commands = 0;
const view: WebviewTarget = { executeJavaScript: async <T>(): Promise<T> => { commands++; return false as T; } };
assert.equal((await navigator.advance(view)).success, false);
assert.equal(commands, 0, 'A persistently disabled button must never be force-enabled or clicked');
navigator.detectForwardButton = async () => ({ exists: true, action: 'next', selector: '#next', text: 'Next', disabled: false });
const missingClick = await navigator.advance(view);
assert.equal(missingClick.success, false);
assert.equal(missingClick.stepChanged, false);
assert.equal(matchSelectOption('Yes', ['No, I need sponsorship', 'Yes, I am authorized']), 'Yes, I am authorized');
assert.equal(matchSelectOption('No', ['Yes, I am authorized']), null);
console.log('Audit failure, disabled controls, missing clicks, and option polarity regressions passed.');
