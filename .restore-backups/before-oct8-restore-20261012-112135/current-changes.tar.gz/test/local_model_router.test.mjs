import assert from 'node:assert/strict';
import test from 'node:test';
import { LocalModelRouter, OLLAMA_MODEL } from '../desktop/local-model-router.mjs';
const response = (data) => ({ ok: true, json: async () => data });
function setup(fetchImpl) {
  const router = new LocalModelRouter({ fetchImpl });
  return { router };
}
function healthy(url) {
  if (url.endsWith('tags')) return response({ models: [{ name: OLLAMA_MODEL }] });
  if (url.endsWith('show')) return response({ capabilities: ['vision', 'completion'] });
  return response({ model: OLLAMA_MODEL, response: 'READY' });
}
test('Passive status cannot wake a model, and another installed model cannot satisfy readiness', async () => {
  let calls = 0;
  const { router } = setup(async () => { calls++; return response({ models: [{ name: 'qwen2.5:3b' }] }); });
  assert.equal(router.status().isReady, false); assert.equal(calls, 0);
  await assert.rejects(router.generate({ prompt: 'Question' }), /connecting automatically/);
  await assert.rejects(router.start(), /Required model missing/);
  assert.equal(router.status().isReady, false);
});
test('Failed warmup never reports ready', async () => {
  const { router } = setup(async (url) => url.endsWith('generate') ? response({ error: 'Insufficient memory' }) : healthy(url));
  await assert.rejects(router.start(), /memory/);
  assert.equal(router.status().isReady, false);
  await router.stop(); assert.equal(router.status().error, undefined);
});
test('Exact-model nonempty inference is required; disconnect invalidates readiness', async () => {
  let generates = 0;
  const { router } = setup(async (url, options) => {
    if (!url.endsWith('generate')) return healthy(url);
    const body = JSON.parse(options.body); assert.equal(body.model, OLLAMA_MODEL); assert.equal(body.think, false);
    if (++generates > 1) throw new Error('Disconnected');
    return healthy(url);
  });
  const loading = router.start(); assert.equal(router.start(), loading);
  await loading; assert.equal(router.status().isReady, true);
  await assert.rejects(router.generate({ prompt: 'Question' }), /Disconnected/);
  assert.equal(router.status().isReady, false);
});
test('Wrong returned model and empty warmup both fail', async () => {
  for (const data of [{ model: 'zeroapply:latest', response: 'READY' }, { model: OLLAMA_MODEL, response: '' }]) {
    const { router } = setup(async (url) => url.endsWith('generate') ? response(data) : healthy(url));
    await assert.rejects(router.start(), /verification failed/);
  }
});
test('Stop during discovery cannot revive a cancelled session', async () => {
  let release;
  const { router } = setup(() => new Promise((resolve) => { release = () => resolve(healthy('tags')); }));
  const loading = router.start(); await Promise.resolve();
  await router.stop(); release();
  await assert.rejects(loading, /cancelled/); assert.equal(router.status().isReady, false);
});
test('Vision chat uses the exact model and generation cancellation rejects late results', async () => {
  let release;
  const { router } = setup(async (url, options) => {
    if (!url.endsWith('chat')) return healthy(url);
    const body = JSON.parse(options.body);
    assert.equal(body.model, OLLAMA_MODEL); assert.deepEqual(body.messages[0].images, ['image']);
    return new Promise((resolve) => { release = () => resolve(response({ model: OLLAMA_MODEL, message: { content: 'RED' } })); });
  });
  await router.start(); const chat = router.chat([{ role: 'user', images: ['image'], content: 'Color?' }]);
  for (let i = 0; i < 10 && !release; i++) await Promise.resolve();
  await router.stop(); release(); await assert.rejects(chat, /cancelled/);
});

test('all inference shares a queue and cancelled queued work cannot run', async () => {
  let release; let requests = 0;
  const { router } = setup(async (url) => {
    if (!url.endsWith('chat')) return healthy(url);
    requests++;
    return new Promise(resolve => { release = () => resolve(response({ model: OLLAMA_MODEL, message: { content: 'Answer' } })); });
  });
  await router.start();
  const first = router.chat([{ role: 'user', content: 'First' }]);
  const second = router.chat([{ role: 'user', content: 'Second' }]);
  for (let i = 0; i < 10 && !release; i++) await Promise.resolve();
  assert.equal(requests, 1);
  await router.stop(); release();
  await assert.rejects(first, /cancelled/); await assert.rejects(second, /cancelled/);
  assert.equal(requests, 1);
});

function streamed(records) {
  const bytes = new TextEncoder().encode(records.map(record => JSON.stringify(record)).join('\n'));
  return new Response(new ReadableStream({ start(controller) {
    for (let offset = 0; offset < bytes.length; offset += 3) controller.enqueue(bytes.slice(offset, offset + 3));
    controller.close();
  } }));
}
test('fragmented UTF-8 image responses assemble only after a completion record', async () => {
  const { router } = setup(async url => url.endsWith('chat') ? streamed([
    { model: OLLAMA_MODEL, message: { content: 'Résumé ' }, done: false },
    { model: OLLAMA_MODEL, message: { content: 'ready' }, done: false },
    { model: OLLAMA_MODEL, message: { content: '' }, done: true },
  ]) : healthy(url));
  await router.start();
  assert.equal(await router.chat([{ role: 'user', content: 'Read', images: ['image'] }]), 'Résumé ready');
  assert.equal(router.status().isReady, true);
});
test('a truncated image response never becomes a successful answer', async () => {
  const { router } = setup(async url => url.endsWith('chat') ? streamed([
    { model: OLLAMA_MODEL, message: { content: 'Partial answer' }, done: false },
  ]) : healthy(url));
  await router.start();
  await assert.rejects(router.chat([{ role: 'user', content: 'Read', images: ['image'] }]), /before completion/);
  assert.equal(router.status().isReady, false);
});
test('a wrong model in a streamed answer fails before it can be accepted', async () => {
  const { router } = setup(async url => url.endsWith('chat') ? streamed([
    { model: 'another-model', message: { content: 'Answer' }, done: true },
  ]) : healthy(url));
  await router.start();
  await assert.rejects(router.chat([{ role: 'user', content: 'Read' }]), /unexpected model/);
});


test('always-on startup recovers after daemon failure and keeps the exact model loaded', async () => {
  let online = false;
  const { router } = setup(async (url, options) => {
    if (!online) throw new Error('Daemon offline');
    if (url.endsWith('generate')) assert.equal(JSON.parse(options.body).keep_alive, -1);
    return healthy(url);
  });
  try {
    router.enableAlwaysOn();
    await router.maintenance;
    assert.equal(router.status().isReady, false);
    assert.equal(router.status().autoReconnect, true);
    online = true;
    await router.maintainConnection();
    assert.equal(router.status().isReady, true);
    assert.equal(router.status().error, undefined);
    await router.stop();
    assert.equal(router.status().isReady, true);
    await router.maintainConnection();
    assert.equal(router.status().isReady, true);
  } finally { await router.shutdown(); }
  assert.equal(router.recoveryTimer, null);
});

test('always-on detects an unloaded runner and verifies inference again', async () => {
  let probes = 0;
  const { router } = setup(async (url) => {
    if (url.endsWith('ps')) return response({ models: [] });
    if (url.endsWith('generate')) probes++;
    return healthy(url);
  });
  try {
    router.enableAlwaysOn(); await router.maintenance;
    assert.equal(probes, 1);
    await router.maintainConnection();
    assert.equal(probes, 2);
    assert.equal(router.status().isReady, true);
  } finally { await router.shutdown(); }
});


test('batch cleanup keeps always-on readiness and cancels a late inference', async () => {
  let release;
  const { router } = setup(async url => url.endsWith('chat')
    ? new Promise(resolve => { release = () => resolve(response({ model: OLLAMA_MODEL, message: { content: 'Late answer' } })); })
    : healthy(url));
  try {
    router.enableAlwaysOn(); await router.maintenance;
    const pending = router.chat([{ role: 'user', content: 'Question' }]);
    for (let i = 0; i < 10 && !release; i++) await Promise.resolve();
    await router.stop();
    assert.equal(router.status().isReady, true);
    assert.equal(router.status().progressPercent, 100);
    assert.equal(router.status().error, undefined);
    release();
    await assert.rejects(pending, /cancelled/);
    assert.equal(router.status().isReady, true);
    assert.equal(await router.generate({ prompt: 'Still available?' }), 'READY');
  } finally { await router.shutdown(); }
  assert.equal(router.status().isReady, false);
});
