import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from 'playwright-core';
import { AutoApplyOrchestrator } from '../src/agent/workflow/orchestrator';
import type { PersonaData } from '../src/types';
import type { WebviewTarget } from '../src/agent/domScanner/injectedScanner';

const executablePath = [
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser',
].find((candidate): boolean => fs.existsSync(candidate));
assert.ok(executablePath, 'An installed Chromium browser is required for the local DOM test');
const persona: PersonaData = {
  fullName: 'Local Test Candidate', email: 'candidate@example.com', phone: '+1 555 010 0200',
  location: 'Test City', targetRoles: ['Software Engineer'], techStack: ['TypeScript'],
  experienceYears: 3, minSalary: 10, workPreference: 'Remote', tone: 'Confident',
  resumeText: 'Local Test Candidate has three years of TypeScript experience.',
};
const fixture = `<!doctype html><html><head><style>
body{font:16px sans-serif;padding:30px}.jobs-easy-apply-modal{width:600px;border:1px solid;padding:24px}
input{display:block;width:350px;height:35px;margin:15px 0}button{padding:15px;margin:12px}footer{display:block}
</style></head><body><main><h1>Software Engineer at Local Test Company</h1>
<section role="dialog" aria-modal="true" class="jobs-easy-apply-modal"><div id="step"></div></section></main>
<script>
window.testResult={stage:1,submits:0,values:{}};
function render(){const s=window.testResult.stage;
 document.querySelector('#step').innerHTML=s===1?'<h3>Contact information</h3><label for="email">Email address</label><input id="email" name="email" type="email" required><footer><button id="next" type="button">Next</button></footer>':s===2?'<h3>Phone number</h3><label for="phone">Mobile phone number</label><input id="phone" name="phone" type="tel" required><footer><button id="review" type="button">Review</button></footer>':'<h3>Review application</h3><p>Ready to submit your local test application.</p><footer><button id="submit" type="button">Submit application</button></footer>';
 const b=document.querySelector('footer button');b.onclick=()=>{const input=document.querySelector('#step input');
 if(input&&!input.checkValidity()){input.setAttribute('aria-invalid','true');return;}
 if(input)window.testResult.values[input.name]=input.value;
 if(s<3){window.testResult.stage++;render();return;}
 window.testResult.submits++;document.querySelector('#step').innerHTML='<div class="success-view"><h3>Your application was sent</h3><p>Application submitted successfully to Local Test Company.</p></div>';
 };}
render();</script></body></html>`;

const browser = await chromium.launch({ executablePath, headless: true });
try {
  const context = await browser.newContext({ viewport: { width: 1100, height: 800 } });
  await context.route('**/*', async (route): Promise<void> => { await route.abort(); });
  const page = await context.newPage();
  const view: WebviewTarget = {
    executeJavaScript: async <T>(code: string): Promise<T> => page.evaluate<T>(code),
  };
  const artifacts = path.resolve('artifacts/local-submission-review');
  fs.mkdirSync(artifacts, { recursive: true });
  for (const allowSubmit of [false, true]) {
    await page.setContent(fixture);
    let active = true;
    const timeout = setTimeout((): void => { active = false; }, 90000);
    const result = await new AutoApplyOrchestrator().runApplication(view, persona, {
      maxSteps: 5, stepDelayMs: 0, allowSubmit, isActive: (): boolean => active,
    });
    clearTimeout(timeout);
    const observed = await page.evaluate((): { submits: number; stage: number; values: Record<string, string> } => (window as unknown as { testResult: { submits: number; stage: number; values: Record<string, string> } }).testResult);
    await page.screenshot({ path: path.join(artifacts, allowSubmit ? 'confirmed-submission.png' : 'ready-for-review.png') });
    console.log(JSON.stringify({ allowSubmit, result, observed }));
    assert.equal(observed.values.email, persona.email, 'Email must be filled from the synthetic profile');
    assert.ok(observed.values.phone, 'Phone must be filled before review');
    assert.equal(observed.stage, 3, 'Agent must reach review');
    assert.equal(observed.submits, allowSubmit ? 1 : 0, 'Submit must fire exactly once, or never in review mode');
    assert.equal(result.outcome, allowSubmit ? 'submitted' : 'skipped');
  }
  console.log('Real browser DOM workflow passed through review, one submit, and website confirmation.');
} finally {
  await browser.close();
}
