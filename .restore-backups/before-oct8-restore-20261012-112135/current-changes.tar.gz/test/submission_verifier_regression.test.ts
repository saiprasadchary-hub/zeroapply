import assert from 'node:assert/strict';
import vm from 'node:vm';
import { SubmissionVerifier } from '../src/agent/normalApply/submissionVerifier';
import type { WebviewTarget } from '../src/agent/domScanner/injectedScanner';

const verifier = new SubmissionVerifier();
async function check(text: string, url: string, selector = '', overlayText = ''): Promise<boolean> {
  const view: WebviewTarget = {
    executeJavaScript: async <T>(script: string): Promise<T> => vm.runInNewContext(script, {
      URL,
      window: { location: { href: url } },
      document: {
        body: { innerText: text },
        createTreeWalker: (): { nextNode: () => object | null } => {
          const nodes = [
            { textContent: text, parentElement: { closest: (): null => null, getClientRects: (): object[] => [{}] } },
            { textContent: overlayText, parentElement: { closest: (): object => ({}), getClientRects: (): object[] => [{}] } },
          ];
          return { nextNode: (): object | null => nodes.shift() || null };
        },
        querySelector: (selectors: string): object | null => selector && selectors.includes(selector)
          ? { offsetParent: {}, className: selector, id: '' } : null,
      },
    }) as T,
  };
  return (await verifier.verifySubmission(view)).isConfirmed;
}

assert.equal(await check('Congratulations! We will contact you after you apply.', 'https://jobs.example.com/apply'), false);
assert.equal(await check('We have received your support message.', 'https://jobs.example.com/apply'), false);
assert.equal(await check('Fill this form', 'https://jobs.example.com/apply?redirect=/success'), false);
assert.equal(await check('Complete your application', 'https://jobs.example.com/complete-profile'), false);
assert.equal(await check('Review application', 'https://www.linkedin.com/jobs/view/123', '[data-test-modal-close-btn]'), false);
assert.equal(await check('Your application was sent', 'https://www.linkedin.com/jobs/view/123'), true);
assert.equal(await check('Your response has been recorded', 'https://docs.google.com/forms/d/e/test/formResponse'), true);
assert.equal(await check('Thank you for applying', 'https://jobs.example.com/thank-you'), true);
assert.equal(await check('Fill your application', 'https://jobs.example.com/apply', '', 'Your application was sent'), false);
console.log('Submission evidence regression checks passed.');
