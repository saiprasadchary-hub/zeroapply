# Ollama desktop AI

Electron uses only `qwen3.5:4b` through the local Ollama daemon at `127.0.0.1:11434`. Install Ollama and pull that exact model with `ollama pull qwen3.5:4b` before opening the app.

The app automatically verifies the model with real inference on launch, keeps it loaded with `keep_alive: -1`, and checks the connection in the background. Failed connections retry automatically. Review & start AutoApply starts the application workflow; model availability is independent of that button.

No model weights or standalone inference runtime are bundled in desktop installers. Stop cancels current inference; the availability watchdog reconnects while the app remains open. Quitting the app clears its watchdog. Ollama must remain running and the computer awake.

Verification:

- `node --test test/local_model_router.test.mjs`: readiness, cancellation, exact model enforcement, and recovery.
- `npm run verify:ollama:connection`: real text inference through Ollama.
- `npm run verify:ollama`: text and screenshot inference in Electron.

## Google sign-in in Chrome

The desktop Google button opens a local ZeroApply sign-in page in installed Google Chrome. After Google authentication, a short-lived callback sends the Google credential directly to the desktop app, which verifies it through Firebase and persists its own session. The app comes to the foreground after the handoff. Cancel and a five-minute timeout close the callback listener. Job-site sign-in sessions remain independent.

Enable Google as a provider in Firebase Authentication and include `localhost` under Authentication → Settings → Authorized domains for project `zero-apply`. The browser page displays an authorization error if this domain is missing. No website deployment or custom URL protocol is required; the sign-in page is bundled with the desktop app. Chrome is required for desktop Google sign-in. Email sign-in continues through the existing form.

Verification: `node --test test/browser_auth_handoff.test.mjs`. A real Google-account sign-in should also be checked in the desktop app with the project's Firebase configuration; callback tests do not authenticate a live account.

The embedded agent browser keeps Google pages and new tabs inside ZeroApply. All embedded browser tabs and their authentication popups share `persist:zeroapply_auth`, so a website session established there persists across tabs and app restarts. Chrome-based ZeroApply account login authenticates Firebase; it does not establish Google website cookies in Electron. The built-in browser's Google account chooser only shows accounts signed into that browser session. Google may reject embedded sign-in with `disallowed_useragent`; an OAuth identity token cannot be converted into Google website cookies.

Direct Google website **Sign in** and **Add account** links from embedded Google pages open their original Google authentication URL in Chrome. New tabs, search, and third-party OAuth popup callbacks stay inside their original browsing context. This routing is not a Google website session transfer: unlike ZeroApply's Firebase sign-in, the Google website authentication endpoint does not supply the app's loopback callback. Users return manually; Google website cookies established in Chrome remain there.
