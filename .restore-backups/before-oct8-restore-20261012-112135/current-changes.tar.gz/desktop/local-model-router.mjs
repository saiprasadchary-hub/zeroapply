export const OLLAMA_MODEL = 'qwen3.5:4b';
const COLD_START_TIMEOUT_MS = 240000;
const VISION_TIMEOUT_MS = 300000;

// One exact-model session. No fallback may turn a failed model into a ready badge.
export class LocalModelRouter {
  constructor({ notify = () => {}, fetchImpl = globalThis.fetch }) {
    this.notify = notify;
    this.fetch = fetchImpl;
    this.version = 0;
    this.loading = null;
    this.alwaysOn = false;
    this.recoveryTimer = null;
    this.maintenance = null;
    this.recoveryFailures = 0;
    this.controllers = new Set();
    this.inference = Promise.resolve();
    this.state = { isReady: false, isLoading: false, modelName: OLLAMA_MODEL, backend: 'ollama', progressText: 'Ollama standby', progressPercent: 0 };
  }
  status() { return { ...this.state }; }
  update(state) { this.state = { ...this.state, ...state }; this.notify(this.status()); }
  enableAlwaysOn() {
    if (this.alwaysOn) return;
    this.alwaysOn = true;
    this.update({ autoReconnect: true });
    void this.maintainConnection();
  }
  maintainConnection() {
    if (!this.alwaysOn || this.maintenance) return this.maintenance || Promise.resolve();
    const version = this.version;
    const run = async () => {
      if (this.loading || this.controllers.size) return;
      if (this.state.isReady) {
        const running = await this.request('ps', undefined, 5000);
        this.checkVersion(version);
        if (running.models?.some(model => (model.name || model.model) === OLLAMA_MODEL)) return;
        this.update({ isReady: false, visionVerified: false, progressText: 'Reconnecting to Ollama…' });
      }
      await this.start();
      this.recoveryFailures = 0;
    };
    const maintenance = run().catch(error => {
      // A user Stop invalidates old work; it must not publish a stale failure.
      if (!this.alwaysOn || /cancelled/i.test(error.message)) return;
      this.recoveryFailures++;
      this.update({ isReady: false, isLoading: false, visionVerified: false, error: error.message,
        progressText: 'Ollama unavailable · retrying automatically' });
    }).finally(() => {
      if (this.maintenance === maintenance) this.maintenance = null;
      if (!this.alwaysOn) return;
      clearTimeout(this.recoveryTimer);
      this.recoveryTimer = setTimeout(() => { void this.maintainConnection(); }, Math.min(120000, 30000 * 2 ** Math.min(this.recoveryFailures, 2)));
      this.recoveryTimer.unref?.();
    });
    this.maintenance = maintenance;
    return maintenance;
  }
  shutdown() {
    this.alwaysOn = false;
    clearTimeout(this.recoveryTimer);
    this.recoveryTimer = null;
    return this.stop();
  }

  checkVersion(version) { if (version !== this.version) throw new Error('AutoApply startup cancelled.'); }
  async request(path, body, timeout = 120000) {
    const version = this.version;
    const controller = new AbortController();
    this.controllers.add(controller);
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await this.fetch(`http://127.0.0.1:11434/api/${path}`, {
        signal: controller.signal,
        ...(body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {}),
      });
      if (!response.ok) throw new Error(`Ollama HTTP ${response.status}. Check the daemon and ${OLLAMA_MODEL}.`);
      const data = body?.stream && response.body
        ? await this.readStream(response.body, version)
        : await response.json();
      if (data.error) throw new Error(String(data.error));
      return data;
    } catch (error) {
      if (controller.signal.aborted) throw new Error('Ollama request cancelled or timed out.');
      throw error;
    } finally { clearTimeout(timer); this.controllers.delete(controller); }
  }
  async readStream(stream, version) {
    const decoder = new TextDecoder();
    let pending = ''; let content = ''; let completion = ''; let chunks = 0; let model;
    let received = 0; let lastProgress = 0;
    const consume = (line) => {
      if (!line.trim()) return undefined;
      const part = JSON.parse(line);
      if (part.error) throw new Error(String(part.error));
      if (part.model) {
        if (part.model !== OLLAMA_MODEL) throw new Error('Ollama returned an unexpected model.');
        model = part.model;
      }
      content += part.message?.content || '';
      completion += part.response || '';
      if (part.message?.content || part.response) ++chunks;
      if (chunks && Date.now() - lastProgress >= 1000 && version === this.version) {
        lastProgress = Date.now();
        this.update({ progressText: `Ollama ${OLLAMA_MODEL} responding · ${chunks} output chunks received` });
      }
      if (part.done) return { ...part, model, response: completion, message: { role: 'assistant', content } };
      return undefined;
    };
    for await (const bytes of stream) {
      this.checkVersion(version);
      received += bytes.length;
      if (received > 1048576) throw new Error('Ollama response exceeded its output limit.');
      pending += decoder.decode(bytes, { stream: true });
      let newline;
      while ((newline = pending.indexOf('\n')) >= 0) {
        const line = pending.slice(0, newline); pending = pending.slice(newline + 1);
        const result = consume(line);
        if (result) return result;
      }
    }
    this.checkVersion(version);
    pending += decoder.decode();
    if (pending.trim()) {
      const result = consume(pending);
      if (result) return result;
    }
    throw new Error('Ollama response ended before completion. Retry the request.');
  }
  start() {
    if (this.loading) return this.loading;
    if (this.state.isReady) return Promise.resolve(this.status());
    const version = ++this.version;
    this.update({ isReady: false, isLoading: true, visionVerified: false, error: undefined, progressText: `Verifying Ollama ${OLLAMA_MODEL}…`, progressPercent: 20 });
    const loading = this.startSession(version).catch((error) => {
      if (version === this.version) this.update({ isReady: false, isLoading: false, error: error.message, progressText: 'Ollama unavailable' });
      throw error;
    }).finally(() => { if (this.loading === loading) this.loading = null; });
    this.loading = loading;
    return loading;
  }
  async startSession(version) {
    const tags = await this.request('tags', undefined, 5000);
    this.checkVersion(version);
    if (!tags.models?.some((model) => (model.name || model.model) === OLLAMA_MODEL)) {
      throw new Error(`Required model missing. Run: ollama pull ${OLLAMA_MODEL}`);
    }
    const show = await this.request('show', { model: OLLAMA_MODEL }, 10000);
    this.checkVersion(version);
    if (!show.capabilities?.includes('vision')) throw new Error(`${OLLAMA_MODEL} does not expose vision support. Update Ollama and the model.`);
    this.update({ progressPercent: 60, progressText: `Waiting for Ollama ${OLLAMA_MODEL} verification response…` });
    const probe = await this.infer('generate', { model: OLLAMA_MODEL, prompt: 'Reply with the single word READY.', stream: true, think: false, keep_alive: -1, options: { temperature: 0, num_ctx: 4096, num_predict: 16 } }, COLD_START_TIMEOUT_MS);
    this.checkVersion(version);
    if (probe.model !== OLLAMA_MODEL || !/\bREADY\b/i.test(probe.response || '')) throw new Error('Ollama text inference verification failed.');
    this.update({ isReady: true, isLoading: false, progressPercent: 100, progressText: `Ollama ${OLLAMA_MODEL} ready`, error: undefined });
    return this.status();
  }
  infer(path, payload, timeout = 120000) {
    const version = this.version;
    const run = () => { this.checkVersion(version); return this.request(path, payload, timeout); };
    const task = this.inference.then(run, run);
    this.inference = task.catch(() => {});
    return task;
  }
  async chat(messages, format) {
    if (!this.state.isReady) throw new Error('Local Ollama is connecting automatically. Wait for AI ready or retry the connection.');
    const version = this.version;
    try {
      const hasImages = messages.some(message => message.images?.length);
      const data = await this.infer('chat', { model: OLLAMA_MODEL, messages, format, stream: true, think: false, keep_alive: -1, options: { temperature: 0, num_ctx: 4096, num_predict: format ? 256 : 128 } }, hasImages ? VISION_TIMEOUT_MS : 120000);
      this.checkVersion(version);
      if (data.model !== OLLAMA_MODEL || !data.message?.content?.trim()) throw new Error('Ollama returned an empty answer or unexpected model.');
      return data.message.content.trim();
    } catch (error) {
      if (version === this.version) this.update({ isReady: false, isLoading: false, error: error.message });
      throw error;
    }
  }
  async generate(payload) {
    if (!this.state.isReady) throw new Error('Local Ollama is connecting automatically. Wait for AI ready or retry the connection.');
    if (!payload || typeof payload.prompt !== 'string' || !payload.prompt.trim() || payload.prompt.length > 32000
      || (payload.systemPrompt !== undefined && (typeof payload.systemPrompt !== 'string' || payload.systemPrompt.length > 16000))
      || (payload.temperature !== undefined && !Number.isFinite(payload.temperature))
      || (payload.maxTokens !== undefined && !Number.isFinite(payload.maxTokens))) throw new Error('Invalid local AI request.');
    const version = this.version;
    try {
      const data = await this.infer('generate', { model: OLLAMA_MODEL, prompt: payload.prompt, system: payload.systemPrompt || '', stream: true, think: false, keep_alive: -1,
        options: { num_ctx: 4096, temperature: Math.max(0, Math.min(1, payload.temperature ?? 0)), num_predict: Math.max(16, Math.min(512, Math.floor(payload.maxTokens ?? 256))) } });
      this.checkVersion(version);
      if (data.model !== OLLAMA_MODEL || !data.response?.trim()) throw new Error('Ollama returned an empty answer or unexpected model.');
      return data.response.trim();
    } catch (error) {
      if (version === this.version) this.update({ isReady: false, isLoading: false, error: error.message });
      throw error;
    }
  }
  stop() {
    ++this.version;
    this.loading = null;
    for (const controller of this.controllers) controller.abort();
    this.controllers.clear();
    this.inference = Promise.resolve();
    // Cancelling an application run does not disconnect a verified Ollama runner.
    const keepReady = this.alwaysOn && this.state.isReady;
    this.update({ isReady: keepReady, isLoading: false, visionVerified: false, error: undefined,
      progressPercent: keepReady ? 100 : 0,
      progressText: keepReady ? `Ollama ${OLLAMA_MODEL} ready` : this.alwaysOn ? 'Ollama reconnecting automatically' : 'Ollama standby' });
    if (this.alwaysOn && !keepReady) {
      // Let aborted maintenance settle before reconnecting, without waiting for its watchdog.
      const maintenance = this.maintenance;
      void Promise.resolve(maintenance).then(() => {
        if (this.alwaysOn) return this.maintainConnection();
      });
    }
    return Promise.resolve();
  }
}
