// Keep vision requests within the context budget of an 8 GB local machine.
// Omitted facts cannot be selected: values are never shortened or invented.
export function visualContext(payload, observation) {
  const facts = {};
  let factSize = 0;
  for (const [key, value] of Object.entries(payload.facts)) {
    const size = JSON.stringify({ [key]: value }).length;
    if (size > 600 || factSize + size > 2200) continue;
    facts[key] = value;
    factSize += size;
  }
  const targets = [];
  let targetSize = 0;
  const ranked = [...observation.targets].sort((a, b) => score(b) - score(a));
  for (const target of ranked) {
    const row = { id: target.id, tag: target.tag, type: target.type, label: target.label, ...(target.value ? { value: target.value } : {}), ...(target.options?.length ? { options: target.options } : {}) };
    const size = JSON.stringify(row).length;
    if (targetSize + size > 3000) continue;
    targets.push(row);
    targetSize += size;
  }
  return { goal: payload.goal, facts, resumeAvailable: Boolean(payload.resume), observation: { url: observation.url, title: observation.title, text: observation.text.slice(0, 1600), targets }, history: payload.history.slice(-2).map(item => item.slice(0, 300)) };
}
function score(target) {
  if (/date\s*posted|filter\b|experience\s*level|employment\s*type|pill/i.test(target.label)) return -20;
  return (/^(input|select|textarea)$/.test(target.tag) ? 4 : 0)
    + (/easy\s*apply|apply\b|next|continue|review|submit|upload/i.test(target.label) ? 5 : 0)
    + (/job/i.test(target.label) ? 2 : 0);
}
