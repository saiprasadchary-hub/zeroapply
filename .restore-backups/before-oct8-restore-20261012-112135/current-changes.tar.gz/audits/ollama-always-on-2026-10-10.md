# Always-on local AI — 2026-10-10

- Automatic verified qwen3.5:4b startup in Electron.
- All desktop warmup/chat/generation requests use keep_alive=-1. Official Ollama documentation defines a negative value as indefinite model residency.
- Background health checks skip active inference, detect unloaded runners, and reconnect with bounded backoff (30–120 seconds). Shutdown clears the watchdog. Browser actions are never restarted by AI recovery.
- Stop still cancels current work; the availability watchdog restores the local model independently.
- Stale errors clear on stop/recovery. Retry UI indicates automatic reconnection. Agent-idle and model readiness are separate.
- Corrected legacy setup script from qwen2.5:1.5b to qwen3.5:4b.

Verification: typecheck, production build, full npm test, lint, and 12 router regressions passed. Real router startup succeeded, a real generation returned ACTIVE, and /api/ps reported exact qwen3.5:4b with expiry in 2319 (indefinite keep-alive). Actual Electron automatically showed Local AI active and OLLAMA QWEN3.5:4B READY without clicking activation. The existing sh.brew.ollama service is registered, loaded and running under the user account.

Availability requires the Mac to be powered on and awake. OS shutdown, daemon crashes, memory/resource exhaustion or another client explicitly unloading the model can interrupt availability; the open Electron app retries. No real applications submitted and no 24-hour soak test claimed.

## Follow-up live verification

- Ollama `/api/tags` returned exactly one installed model: `qwen3.5:4b`.
- `/api/ps` returned the same loaded model, 4096 context, with expiry in 2319.
- Built and launched the actual Electron app, entered the offline demo, and observed automatic loading followed by `Local AI active` and `Local LLM (qwen3.5:4b) is active and ready to solve screening questions.` No Review or Start Auto Apply control was clicked.
- Corrected stale renderer/router messages that incorrectly told users Review was required to load the model.
- Verification: 12 router tests, startup-readiness checks, four review/start tests, TypeScript check, and production build passed. Lint reported existing repository warnings.
- This verifies the current launch and connection; it does not guarantee uninterrupted future availability.
