# Agent workflow review and glitch fixes

## Existing flow reviewed

1. Persona launch dispatches the selected portal and browser mode.
2. Desktop initializes the local model; browser startup waits for the requested search destination and page readiness.
3. The batch engine selects a job and opens its application form or external tab.
4. The orchestrator analyzes the page, scans and classifies fields, resolves answers from persona/resume context and local inference, fills controls, and handles resumes.
5. Form audits check required answers and website validation before navigation.
6. Navigation advances Next/Review/Submit, then website evidence determines submission status.
7. Confirmed applications are recorded and the batch continues. Incomplete forms remain available for review. Stop cancels further browser dispatch; model cleanup releases the AI session.

The layout, browser selection, search intent, resume storage, and intended sequence were preserved. This is a repair of observed code paths and local tests, not a guarantee that every live website will work.

## Glitches fixed in this review

- **Review-only mode:** the batch engine did not pass its submission setting into the orchestrator. It now does, including external-tab recursion, and the orchestrator stops before Submit when submission is disabled.
- **Cancellation and duplicate starts:** batch commands now check a run version before and after execution. A stopped run cannot dispatch later browser commands or clear the state of a newer run. Duplicate starts during an active batch are ignored. The orchestrator receives the same activity check.
- **Duplicate Apply clicks:** the visual cursor already clicks the target. The additional DOM click now runs only if the cursor did not find a target. The cursor correctly reports a missing target as failure.
- **Repeated Submit:** unconfirmed submission previously fell through into another wizard advance. It now returns an unconfirmed failure and leaves the form open. A Done button alone is insufficient evidence.
- **External-tab continuity:** external forms are closed automatically only after confirmed submission; incomplete forms remain open.
- **False success:** orchestrator and batch fallback checks now use the shared submission verifier. Generic close/Not now controls, profile upsells, congratulations text, and form disappearance do not establish success. The verifier ignores the agent's own activity overlay and hidden website text; success URL checks ignore query-string lookalikes.
- **Failed audits:** execution errors, malformed responses, and inconsistent audit results no longer mean ready. Unresolved audits stop before navigation.
- **Disabled controls and missing clicks:** wizard navigation no longer force-enables disabled controls or reports a failed click as a changed step. Normal DOM clicks preserve website click handlers instead of bypassing them with direct form submission.
- **Choice matching:** explicit Yes/No choices with comma/colon/semicolon descriptions match the same polarity, while opposite-polarity options remain excluded.
- **Browser consistency:** removed hard-coded client-hint headers that claimed macOS/Google Chrome independently of the running Chromium platform.
- **Injected expressions and status:** corrected escaped whitespace expressions in template-generated scripts and use the active model name in the workflow overlay.

## Verification

- Full existing suite plus registered new regression suites: **33 command groups passed, zero failed**. The local callback/update/Google sign-in group was run separately with localhost access: **12 tests passed**.
- Added targeted executable checks for unavailable/contradictory audits, disabled buttons, unsuccessful clicks, option polarity, review-only submission, in-flight cancellation, and unconfirmed-submit retry prevention.
- Submission verifier regressions cover explicit website evidence versus generic messages, modal close buttons, URL-query lookalikes, and agent-overlay success text.
- Local-model router regressions: six passed. Earlier real inference successfully used bundled Qwen2.5 1.5B; this review did not establish real inference on the installed 4B model.
- Type checking, production build, targeted lint, and whitespace checks passed. The build retains bundle-size warnings.
- Updated two stale test fixtures to match the central model router and current prompt wording; preserved their behavioral assertions. Workflow mocks now return the verifier's structured evidence result.

## Practical limits

Tests use local synthetic data and mocked browser boundaries. No employer application was sent or verified during this review. Existing application history was preserved, including suspicious prior records; these fixes do not validate historical counts. No APK was rebuilt and no code was pushed. Existing unrelated edits were preserved.

## Real browser submission follow-up

Ran the real orchestrator, scanner, field filler, auditor, visual cursor, navigator, and confirmation verifier against a synthetic three-step application in an isolated headless Chromium browser. All network requests were blocked and only fictional contact details were used.

- Review-only run: two contact fields filled, three steps reached, **zero submits**, outcome `skipped` with the review pause reason.
- Submission-enabled run: the same two fields filled, three steps reached, **exactly one submit**, explicit page confirmation, outcome `submitted`.
- Confirmed both runs with assertions and screenshots under `artifacts/local-submission-review/`. The isolated browser was closed afterward.
- Rechecked submission evidence regressions, audit/disabled-control regressions, type checking, and whitespace validation: passed.

Reproduce with `npm run test:submission:browser` on a machine with the installed Chrome or Brave executable used by the test. This verifies a real browser DOM flow, not live LinkedIn or an employer ATS, file uploads, or new LLM inference. The earlier checks cover local inference and mocked batch behavior separately.
