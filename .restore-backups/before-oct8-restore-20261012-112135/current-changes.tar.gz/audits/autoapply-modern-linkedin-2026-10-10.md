# Modern LinkedIn AutoApply follow-up

The live Electron window showed qwen3.5:4b ready after its startup inference probe. The loading text represented verification, not another model download. Updated the wording and removed the misleading fixed-percentage toolbar status.

Added role-button job-card fallback using per-card Dismiss labels, consistent selection fallback, and visible semantic Easy Apply button discovery for batch and single-job paths without legacy detail-container classes. Applied-status detection now requires an exact status node instead of any occurrence of Applied in a card title.

Standard AutoApply statuses now appear in the activity panel. The panel reports model verification separately from idle workflow state, and screenshot mode is described as optional. Batch summaries report confirmed applications or zero-submission reasons; paused applications retain their review message instead of being overwritten by a success toast.

Validation: a real Electron Chromium fixture executed the production discovery, selection and form-opening scripts against modern role-button cards and accessible Easy Apply controls. It confirmed opening the synthetic form in both paths, avoiding the filter, and distinguishing Applied AI Engineer from an Applied status. Full npm test, typecheck, production build, lint (existing warnings), and diff checks passed. No real LinkedIn application was submitted or claimed verified.
