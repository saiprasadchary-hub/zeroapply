# Ollama-only cleanup — 2026-10-10

Removed the standalone Electron model service/runtime/config/resource policy, GGUF downloader, MLC shard downloader, direct-runtime verification scripts and tests, node-llama-cpp dependency and lock entries, bundled model packaging, and release verification flag. The old source model weights were deleted. The router no longer accepts an embedded backend.

Removed Android native inference, model downloads, bundled weights, C++ runtime/build configuration and inference tests. Android model requests now return an explicit desktop/Ollama-required error. Browser and account integration remain. Updated workflows and documentation. Cleared generated Android runtime files, model assets, build output and old AI APKs, plus the writable stale desktop build.

Electron was rebuilt and restarted. Without clicking Review or Auto Apply it displayed “Local AI active” and “Local LLM (qwen3.5:4b) is active and ready to solve screening questions.” Real Ollama router inference returned the expected experience number (3) and city (Hyderabad).

Verification: full npm test, exact-model policy regression, 12 router tests, eight Android source/answer tests, desktop and Android TypeScript checks, production build and diff whitespace checks passed. Lint has existing warnings. Android native compilation was attempted but the Gradle wrapper download timed out, so native compilation is unverified.

Remaining cleanup: release_build/mac-arm64/ZeroApply.app is a root-owned old package containing the standalone runtime and model. Deletion was attempted but macOS permissions denied it; sudo requires an administrator password. Current source and the running development Electron app do not use this package. This old package must be deleted manually with administrator rights. No files outside this repository were changed or inspected for removal.

## Batch completion lifecycle correction

The supplied screenshot exposed a separate cleanup bug: AgentBrowser calls stopEmbeddedModel after a batch, which unconditionally published standby, while the desktop router invalidated readiness until the next watchdog interval. Stop now invalidates/cancels old requests while preserving an already verified always-on Ollama runner. Unready connections retry immediately after aborted maintenance settles. Renderer cleanup reads the desktop service status instead of publishing standby itself. App shutdown still disables readiness and clears maintenance.

Verification: 13 router tests passed, including late-answer cancellation while readiness stays true; renderer recovery, startup readiness and exact-model checks passed; typecheck, build and lint passed with existing warnings. Real Ollama verification started always-on mode, generated an answer, performed batch cleanup, asserted continued readiness and generated another correct answer. The existing running Electron process must be restarted to load these source changes. No real application batch was submitted for this check.
