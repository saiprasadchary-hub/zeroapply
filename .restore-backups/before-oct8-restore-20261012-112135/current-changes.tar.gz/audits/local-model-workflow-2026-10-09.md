# Desktop local model and workflow review

## Fixes

- Centralized desktop model startup, status, generation, and cancellation in `desktop/local-model-router.mjs`. Passive status checks no longer start a model or report readiness merely because Ollama is online.
- Added verified Ollama warmup and initialization of the bundled fallback. Release the session's Ollama model before loading the fallback; cancel outstanding startup and generation on stop.
- Restored the missing bundled Qwen2.5 1.5B GGUF from the existing identical Android asset.
- Propagated startup failures instead of silently continuing the application workflow. Display errors in the AI status indicator and preserve the reason after cleanup.
- Corrected startup navigation validation so a different LinkedIn job search cannot satisfy the requested destination.
- Corrected submission tracking and state transitions. Unconfirmed submission pauses and returns failure instead of reporting completion.
- Handled local model worker process errors explicitly.

## Verification

- Live local inference passed with **Qwen2.5 1.5B (built-in)** through the desktop router. Synthetic resume facts produced `3 years` and `Hyderabad`, followed by successful session stop.
- Router tests: 6 passed, covering passive readiness, empty model lists, warmup, fallback, cancellation, release ordering, and retained errors.
- Embedded model lifecycle, startup readiness, browser navigation (16 tests), and mocked workflow execution checks passed.
- Type checking, production web build, and diff whitespace validation passed. Build retains existing bundle-size warnings.
- Restarted the desktop app with the fixes; the idle dashboard displays AI standby. Standby is expected until a reviewed workflow explicitly starts the model.

## Scope and limits

The successful live inference used the bundled 1.5B fallback; it does not establish successful operation of the installed Ollama 4B model on this machine. Workflow execution was tested with mocks, and no real job applications were submitted. Existing unrelated working-tree changes were preserved. This review did not create a new APK or push code to GitHub.
