# AutoApply follow-up review

## Live observation

The desktop was idle with AI standby and a two-job batch limit. The dashboard contained a suspicious submitted record titled "0 notifications", with zero filled fields and no identified employer. Existing dashboard counts alone are not reliable evidence of real submissions. No historical records were deleted or reclassified without independent evidence.

The requested Review & start AutoApply click was attempted, but automatic approval review rejected it because it could immediately send real employment applications. Inspection confirmed that the handler directly initializes the model and dispatches AutoApply rather than opening a review screen. The launch path enables submission. No alternate execution path was used to bypass the rejection. Subsequent desktop interaction reported no available window.

**No real submission was verified in this follow-up.** Live testing remains pending authorization identifying the intended employer/job and resume/profile data to send, or a user-started run that can be observed.

## Bugs fixed

1. The form-plan path could treat disappearing inputs as confirmed submission and display success without explicit evidence. It now reports unconfirmed failure and records a failed confirmation check, with a warning to check the site before retrying.
2. If both primary and fallback submit clicks failed without validation errors, the path could still continue as though submission had occurred. It now stops with failure.
3. The external submission verifier accepted generic congratulations/contact text and an ordinary modal-close button as success. These signals were removed or narrowed to application-specific text.
4. Success-looking URL query parameters and partial route names could trigger confirmation. URL checks now compare complete path segments.

These changes reduce false positives; they cannot prove that every website's confirmation pattern is supported or that historical application records are correct.

## Validation

- Eight executable confirmation regression cases passed against the real injected verifier script.
- Real pending-click effect test passed with browser boundaries mocked: immediate dispatch, pinned tab/platform, no refresh, duplicate suppression, and cleanup.
- Standard forms safety tests passed (46/46).
- Mocked multi-step AutoApply workflow and batch execution tests passed.
- Type checking passed.
- Production build and whitespace validation checked separately in the follow-up.

The earlier local-model check successfully generated answers using bundled Qwen2.5 1.5B. This follow-up does not establish a new live model or real employer-submission result. Changes remain local; no Git push or APK rebuild was performed.
