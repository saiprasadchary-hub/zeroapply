# Ollama visual workflow implementation and verification

## Delivered

- Added an accessible Ollama Visual Workflow switch directly below AutoApply Launch Hub. Enabling selects the in-app browser; it uses the existing launch action and configured application limit.
- Added screenshot capture, bounded DOM evidence, schema-constrained local model decisions, grounded profile values, real stored-resume attachment, a visible cursor, native mouse dispatch, scrolling, and dropdown support.
- Added browser ownership checks, observation freshness checks, obscured-target rejection, cancellation, bounded stale-target retries, no-progress detection, and run/time limits.
- Added durable submission leases and fresh website confirmation checks. An ambiguous submission cannot be automatically submitted again. Confirmed applications enter the existing dashboard history.
- Added external-tab following through the existing automation tab bridge and search-tab return after confirmation.
- Unified the exact-model router on Ollama `qwen3.5:4b`; removed alternate-model and embedded fallback from desktop generation. Warmup failure, an empty response, a wrong returned model, or a disconnected daemon no longer satisfies readiness.
- Removed renderer direct-generation fallback and daemon-only readiness shortcuts. Serialized model inference and cancelled queued requests when stopping.
- Added a persistent visual workflow status banner and a Stop control.

## Live findings and fixes

The installed model is Qwen3.5 4.2B Q4_K_M and reports vision capability. A stale Ollama worker and repeated direct renderer requests interfered with initial checks. Restarted the local Homebrew Ollama service, stopped the old app instance, removed the renderer bypass, and rebuilt the app. The rebuilt app no longer produced competing renderer inference connections during the independent check.

The live 4B model sometimes described a submit click using the generic `click` action. Submit controls are now normalized to `submit` before returning the decision, so the controller must persist its lease and apply the submission gate. The browser independently validates the target again before dispatch.

## Verification

- Full `npm test` suite passed, including new workflow controller tests.
- Seven exact-model router tests passed: passive status, wrong/absent model, warmup errors, disconnects, cancellation, image request routing, and serialized inference.
- Four controller tests passed: grounded facts, confirmation counting, durable duplicate protection, and stop during inference.
- Typecheck and production build passed. Lint passed with existing repository warnings; no warnings were reported for the new visual workflow modules. Build retains existing chunk warnings.
- Real Electron/browser mechanics checks passed: grounded filling, protected password rejection, moved-target rejection, submit authorization, native click at 125% zoom, website confirmation, browser ownership, and cancellation.
- Real Electron + Ollama end-to-end check passed: screenshot decisions from actual `qwen3.5:4b`, name/email filling, native Submit click, and website confirmation on a synthetic internship application form.
- Independent image-only verification passed: the model read `Application submitted successfully` from the saved screenshot without receiving the status text in its prompt. The bounded image request took approximately 30 seconds on this machine. Full Retina images exceeded the earlier timeout, so both the workflow and independent verifier constrain image width to 1024 pixels.
- Confirmation screenshot: `audits/screenshots/visual-workflow-confirmed.png`.
- Reopened the rebuilt Electron app and verified the dashboard restored with truthful Local AI standby status.

## Reproduce

- `npm run test:visual:unit`
- `npm run verify:visual:browser` — deterministic model decisions against real Electron browser mechanics.
- `npm run verify:visual` — real Ollama model against a synthetic application form; requires local Ollama with the exact installed model.
- `npm run verify:ollama` — independent text inference and reading the saved confirmation screenshot without providing its text.

## Scope and remaining release coverage

No real employer application was submitted. The successful live test is a controlled synthetic form, not a claim that every LinkedIn or external ATS variation works. Multi-tab routing reuses the existing app machinery; real-site authentication, CAPTCHA, cross-origin iframes, unusual upload widgets, unfamiliar declarations, and missing required facts may require manual intervention. The workflow pauses rather than inventing profile facts or claiming unverified success. Real Chrome remains on its existing engine; the new screenshot workflow runs in Electron's in-app browser. Broader external-ATS and crash/restart fixture coverage from the original plan remains release work before claiming universal production readiness.

Existing unrelated working-tree changes were preserved. No installer was published, code pushed, or third-party application submitted.

## Live activity panel follow-up

- Added a dedicated Live agent side panel with current action, actual inference waiting time, model state, page URL, step and confirmed counters, timestamped activity history, and Stop. Desktop screenshot/inference events and controller action/confirmation events drive the display.
- Added Inspect current page: captures the actual active Electron webview and requests one local model suggestion without dispatching any browser action. Actual Electron window screenshots were captured through native UI inspection with the logged-in LinkedIn page visible.
- The first live LinkedIn inspection exposed competing text requests and a timeout. Restricted automatic Resume Studio audits to its visible tab, reserved the model for visual sessions, cancelled older inference on visual startup, and removed renderer error handling that could overwrite a newer desktop model state.
- Controller regression checks now verify confirmation activity and the final completed event. Controller/router tests, embedded lifecycle checks, typecheck, and production build passed.
- The controlled synthetic-form screenshot above is test evidence only; it is not a screenshot of the main ZeroApply interface or proof of real employer submission.
- The live Mac has 8 GB RAM and showed heavy memory pressure during cold starts. Reduced the router context from 8192 to 4096 and screenshot width from 1024 to 768. A bounded model context prioritizes application controls and supplies exact short profile facts; omitted long facts cannot be selected. Model targets must be present in that context. A new context regression test passed. Complex forms or long required answers may pause for manual input.
- Final real LinkedIn check: text warmup and image-input verification passed, but the page decision still exceeded the 120-second inference timeout. The panel correctly changed from Starting to Capturing to Ollama is deciding to Needs attention, returned to Not running, and kept confirmed applications at zero. No application actions were dispatched. Reliable real-site AutoApply remains unverified under the current local runtime/resource conditions.
- Actual main Electron window screenshot: `audits/screenshots/electron-live-agent-actual.png`. It shows the real LinkedIn page and the timeout status; it is not generated or a synthetic test page.
