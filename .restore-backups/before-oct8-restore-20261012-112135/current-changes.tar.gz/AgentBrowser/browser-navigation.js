const LINKEDIN_SAFETY_PATH = /^\/safety\/go\/?$/i;

const IDENTITY_HOSTS = [
  'accounts.google.com', 'accounts.googleusercontent.com', 'appleid.apple.com',
  'login.microsoftonline.com', 'login.live.com', 'github.com',
  'zero-apply.firebaseapp.com', 'zero-apply.web.app',
];

export function isAuthenticationUrl(value, baseUrl) {
  try {
    const url = new URL(value, baseUrl);
    if (url.protocol !== 'https:' || url.username || url.password) return false;
    const host = url.hostname.toLowerCase();
    return IDENTITY_HOSTS.some((domain) => host === domain || host.endsWith(`.${domain}`))
      || /\/(?:oauth2?|authorize|authorization|saml2?|sso|signin|sign-in|login|auth)(?:\/|$)/i.test(url.pathname);
  } catch {
    return false;
  }
}

export function shouldKeepAuthenticationPopup(value, authenticatedPopup) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password
      && (authenticatedPopup || isAuthenticationUrl(value));
  } catch {
    return false;
  }
}

export function isLinkedInSafetyUrl(value, baseUrl) {
  try {
    const parsed = new URL(value, baseUrl || 'https://www.linkedin.com');
    return (parsed.hostname === 'linkedin.com' || parsed.hostname.endsWith('.linkedin.com'))
      && LINKEDIN_SAFETY_PATH.test(parsed.pathname);
  } catch {
    return false;
  }
}

export function isLinkedInTrackerUrl(value, baseUrl) {
  try {
    const parsed = new URL(value, baseUrl || 'https://www.linkedin.com');
    const host = parsed.hostname.toLowerCase();
    return (host === 'linkedin.com' || host.endsWith('.linkedin.com'))
      && parsed.pathname.toLowerCase().replace(/\/+$/, '') === '/jobs-tracker';
  } catch {
    return false;
  }
}

export function isBrowserDestination(url) {
  return Boolean(url && ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password);
}

export function isDeferredPopupUrl(value) {
  if (typeof value !== 'string') return false;
  if (!value.trim()) return true;
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'about:' && parsed.pathname.toLowerCase() === 'blank';
  } catch {
    return false;
  }
}

export function resolvePopupDestination(value, baseUrl) {
  try {
    if (typeof value !== 'string' || !value.trim()) return null;
    let parsed;
    if (baseUrl) {
      parsed = new URL(value, baseUrl);
    } else {
      try {
        parsed = new URL(value);
      } catch {
        return null;
      }
    }
    const isLinkedInSafetyRedirect = isLinkedInSafetyUrl(parsed.toString(), baseUrl);
    if (!isLinkedInSafetyRedirect) return parsed;

    const redirectKeys = ['url', 'target', 'destination', 'redirect', 'dest', 'redirectUrl', 'redirect_url', 'u', 'href', 'next', 'r', 'link', 'out', 'external_url'];
    for (const key of redirectKeys) {
      let nestedValue = parsed.searchParams.get(key);
      if (!nestedValue) continue;
      try {
        if (nestedValue.includes('%')) {
          try { nestedValue = decodeURIComponent(nestedValue); } catch {}
        }
        const nested = new URL(nestedValue);
        if (isBrowserDestination(nested)) return nested;
      } catch {
        // Try the next known redirect parameter.
      }
    }
    return null;
  } catch {
    return null;
  }
}


export function normalizeGestureCandidates(rawCandidates, baseUrl) {
  if (!Array.isArray(rawCandidates)) return [];
  const normalized = [];
  for (const candidate of rawCandidates) {
    if (typeof candidate !== 'string' || candidate.length > 8_192) continue;
    try {
      const parsed = new URL(candidate, baseUrl);
      if (isBrowserDestination(parsed)) normalized.push(parsed.toString());
    } catch {
      // Ignore malformed DOM attributes sent by the isolated webview preload.
    }
    if (normalized.length === 6) break;
  }
  return [...new Set(normalized)];
}

export function resolveGestureDestination(gesture) {
  for (const candidate of gesture?.candidates || []) {
    const parsed = resolvePopupDestination(candidate);
    if (isBrowserDestination(parsed)) return parsed;
  }
  return null;
}

export function matchesStartupDestination(currentUrl, requestedUrl) {
  try {
    const current = new URL(currentUrl);
    const requested = new URL(requestedUrl);
    if (current.origin !== requested.origin) return false;

    const curPath = current.pathname.replace(/\/$/, '').toLowerCase();
    const reqPath = requested.pathname.replace(/\/$/, '').toLowerCase();

    // Check pathname: allow exact match, or if on LinkedIn jobs platform allow /jobs/ search, collections, view
    const isLinkedIn = (current.hostname === 'linkedin.com' || current.hostname.endsWith('.linkedin.com'))
      && (requested.hostname === 'linkedin.com' || requested.hostname.endsWith('.linkedin.com'));

    if (curPath !== reqPath) {
      const isJobsSubpath = isLinkedIn
        && (curPath.startsWith('/jobs/search') || curPath.startsWith('/jobs/collections') || curPath.startsWith('/jobs/view') || curPath === '/jobs')
        && (reqPath.startsWith('/jobs/search') || reqPath.startsWith('/jobs'));
      if (!isJobsSubpath) return false;
    }

    // Required query parameters (keywords / search query)
    const primaryQueryKeys = ['keywords', 'q', 'search', 'sc.keyword'];
    for (const key of primaryQueryKeys) {
      if (requested.searchParams.has(key)) {
        const reqVal = (requested.searchParams.get(key) || '').toLowerCase().trim();
        const curVal = (current.searchParams.get(key) || '').toLowerCase().trim();
        if (reqVal && curVal !== reqVal && !curPath.startsWith('/jobs/view')) {
          return false;
        }
      }
    }

    // For other parameters:
    for (const [key, value] of requested.searchParams) {
      if (primaryQueryKeys.includes(key)) continue;
      // LinkedIn frequently replaces location with geoId; don't fail if location was converted
      if (key === 'location') {
        if (current.searchParams.has('location')) {
          const curLoc = (current.searchParams.get('location') || '').toLowerCase().replace(/\+/g, ' ').trim();
          const reqLoc = value.toLowerCase().replace(/\+/g, ' ').trim();
          if (curLoc && reqLoc && !curLoc.includes(reqLoc) && !reqLoc.includes(curLoc) && !current.searchParams.has('geoId')) {
            return false;
          }
        }
        continue;
      }
      // If current URL contains the key, verify value matches
      if (current.searchParams.has(key)) {
        const curVals = current.searchParams.getAll(key);
        if (!curVals.includes(value)) return false;
      }
    }
    return true;
  } catch {
    return false;
  }
}

