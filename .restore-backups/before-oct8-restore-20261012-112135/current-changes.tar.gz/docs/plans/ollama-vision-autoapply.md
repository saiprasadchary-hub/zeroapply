# Ollama screenshot AutoApply: implementation plan

Status: proposed architecture, 9 October 2026. No new workflow implemented by this document. Existing uncommitted work must be preserved.

## 1. Product contract

Add an **Ollama Visual Workflow** on/off switch directly below **AutoApply Launch Hub** in `src/components/PersonaForm.tsx`. Default off. Enabling selects the visual workflow; starting still uses the existing launch action. Off cancels an active visual session, drains queued actions, and retains progress. Never run the existing engine and visual engine concurrently.

The run uses the selected persona, job/internship preference, search keywords, location, selected jobs or requested batch size, resume, and submission preference. Search must reflect those choices. Selected-job mode applies only to selected jobs; search mode discovers matching candidates. Track attempts separately from confirmed applications. Stop after the configured confirmed target or attempt/time budget, whichever occurs first, and explain any shortfall.

Support both LinkedIn Easy Apply and external job-site forms. Follow application-related new tabs and redirects while preserving the search tab. Unsupported sites, missing answers, authentication, and challenges produce explicit paused/skipped outcomes. No claim of universal website compatibility or perfect model accuracy.

## 2. Findings from repository inspection

- `desktop/local-model-router.mjs` selects alternate installed models and supports embedded fallback. It catches warmup failures and then sets readiness true. Generation can silently switch to embedded inference.
- `main.js` has separate embedded-generation and Ollama-query paths; the latter retries another installed model. `ollama-status` reports availability when any model exists. These paths can disagree with the status badge.
- `src/agent/localLlm/ollamaClient.ts` declares `qwen3.5:4b`, but a constant alone does not guarantee the runtime backend.
- Existing vision code in `src/agent/vision/omniVisionEngine.ts` maps DOM geometry. This is useful evidence, but does not establish an image-to-Ollama inference pipeline.
- `AgentBrowser/AgentBrowser.tsx` owns launch handling, engines, and tab events. It is the integration point, not a suitable home for another large controller.
- Reuse `src/agent/normalApply/submissionVerifier.ts`, field scanners/fillers, persona resolution, navigation, and existing telemetry after validating their evidence boundaries.
- The local HTTP probe to `127.0.0.1:11434/api/tags` failed during planning. This establishes only that the endpoint was unreachable from this session; live Ollama inference remains unverified.
- `scripts/verify-electron-model.cjs` verifies the embedded utility-process model, not Ollama Qwen 4B. Add a distinct verifier.

## 3. Proposed file structure

```text
desktop/
  local-model-router.mjs             MODIFY: shared backend policy, truthful readiness
  ollama-session.mjs                 NEW: exact model startup, probes, chat, abort
  visual-browser-service.mjs         NEW: owned webContents capture/input/tab operations
  visual-workflow-ipc.mjs            NEW: validated narrow IPC registration
  visual-run-store.mjs               NEW: durable local ledger, leases, recovery
src/agent/visualWorkflow/
  types.ts                          run config, observations, action/result unions
  controller.ts                     one observe/decide/validate/act/verify loop
  stateMachine.ts                   explicit transitions and recovery states
  modelGateway.ts                   typed preload bridge; no renderer HTTP fallback
  observationBuilder.ts             screenshots plus bounded DOM and field evidence
  decisionSchema.ts                 JSON schema and independent runtime validation
  prompts.ts                        grounded planning; webpage content is untrusted
  actionValidator.ts                freshness, ownership, bounds, allowed actions
  actionExecutor.ts                 browser-native input and verified field operations
  coordinateMapper.ts               image pixels to viewport DIP coordinates
  tabCoordinator.ts                 parent/child ownership and handoff lifecycle
  jobQueue.ts                       selected/discovered jobs, deduplication, budgets
  answerGrounding.ts                persona facts, provenance, unknown-value pauses
  submissionGate.ts                 review and configured submit authorization
  completionVerifier.ts             job-specific post-submit evidence
  recoveryPolicy.ts                 retries, no-progress detection, re-observation
  runRepository.ts                  typed access to main-process persistence
  telemetry.ts                      structured, redacted run events
src/agent/ui/
  VisualWorkflowToggle.tsx          accessible switch beneath launch hub
  VisualWorkflowStatus.tsx          actual backend, state, job, next action, pause reason
  VisualWorkflowReview.tsx          missing answers and submission review
scripts/
  verify-ollama-vision.mjs           real text/image/action-schema smoke test
  verify-visual-workflow.mjs         Electron fixture end-to-end runner
test/
  visual_workflow_policy.test.ts
  visual_workflow_coordinates.test.ts
  visual_workflow_state.test.ts
  visual_workflow_submission.test.ts
  ollama_visual_session.test.mjs
  visual_workflow_browser.test.ts
  fixtures/visual-workflow/          search, modal, ATS, redirects, failure pages
docs/plans/ollama-vision-autoapply.md
```

Modify `main.js` to register services, `preload-popup.cjs` and the existing Window bridge type declarations to expose typed operations, `src/types/index.ts` to persist workflow preference, `src/components/PersonaForm.tsx` for placement, and `AgentBrowser/AgentBrowser.tsx` for routing and tab ownership. Update the existing HUD/status components and package scripts rather than creating conflicting indicators. Confirm actual bridge type declaration locations before editing.

## 4. Exact model activation

Visual sessions require backend `ollama` and exact model `qwen3.5:4b`. No other tag, embedded model, browser model, or cloud provider may satisfy readiness or generation. Legacy fallback behavior, if retained for other features, must be explicit and cannot enter this session.

Startup sequence:

1. Validate loopback endpoint and daemon version; distinguish daemon missing, model missing, timeout, unsupported capability, out-of-memory, and inference failure.
2. Check exact tag through `/api/tags`; inspect `/api/show` capabilities for image input. Missing model offers an explicit install action with progress, not a silent multi-GB download.
3. Perform bounded warmup, then real non-empty text inference.
4. Send a synthetic image with known content and validate a semantic answer and structured action response. A successful HTTP request alone is insufficient.
5. Inspect `/api/ps` for residency; record actual returned model, digest, timings, and probe results. Expose `daemonOnline`, `modelInstalled`, `modelLoaded`, `textVerified`, and `visionVerified` separately.
6. Enter ready only after required probes pass. A daemon/model failure during a run invalidates readiness and pauses actions.

Use `/api/chat` with image payloads, `stream:false`, fixed low temperature, bounded output/context, and JSON schema where supported. Independently validate every response. Use one serialized inference queue, per-session cancellation, session generation IDs, and configurable bounded cold-start timeouts. Do not unload a model used by another ZeroApply feature; lease it and release only when no app session needs it.

## 5. Observation/action protocol

Each observation contains run ID, observation ID, job ID, tab ID, navigation generation, URL, capture time, screenshot dimensions, viewport DIP size, zoom/device-scale metadata, scroll position, bounded page text, field summaries, and visible actionable targets. Capture only the owned browser content; omit app chrome, unrelated tabs, overlays, and hidden input secrets. Keep images in memory unless diagnostics are explicitly retained.

The model returns one action: `click`, `type`, `select`, `scroll`, `upload_resume`, `wait`, `switch_tab`, `request_user_input`, `submit`, `skip_job`, or `finish_job`. Require observation ID, target ID or normalized coordinates, reason, confidence, expected postcondition, and grounded answer references where relevant. `finish_job` is advisory; only the verifier can confirm success. No model-generated JavaScript, shell commands, paths, or arbitrary URLs are executable.

Loop: capture -> infer -> validate -> execute one action -> await observable page change -> capture again -> verify postcondition. Any navigation, resize, zoom, target movement, or tab switch invalidates prior coordinates. Clicks use visible current targets, hit-testing when available, and the screenshot coordinate transform; never desktop screenshot coordinates. A visible virtual cursor reflects the actual input dispatch. Prefer semantic selectors for identifiable fields while still sending screenshots to the model each decision cycle.

Main-process input uses owned Electron `webContents` and browser-native input. Do not control the user's global OS pointer. File uploads use the selected resume artifact through the existing verified upload mechanism, with an app-owned path token rather than model-selected filesystem paths.

## 6. Job and internship workflow

Resolve the requested search and filters, verify the resulting search state, collect stable job IDs/URLs, deduplicate, and persist the queue. Filter job vs internship and other explicit constraints using listing evidence. Open one application at a time. Capture the initial job title, employer, URL, and description so later confirmation belongs to the same application.

For the first screenshot, follow the external Apply link into a tracked child tab. For the second screenshot, recognize the Easy Apply modal, inspect contact fields, fill from the active persona, scroll within the modal, and verify each Next transition. Do not assume seven steps stays constant. Handle radios, checkboxes, dropdowns, phone country codes, validation errors, resume uploads, and review pages using existing verified primitives.

Never invent experience, education, work eligibility, salary preference, or answers absent from the profile. Pause for missing required facts and save reusable answers only with user intent. Preserve existing values unless demonstrably inconsistent with approved persona data.

After review, submit according to the run's explicit submission setting. Keep a per-job submission lease and write `submitting` before dispatch. Verify completion using fresh website evidence associated with the job and transition: confirmation text/modal, recognized confirmation route plus corroborating content, receipt ID when exposed, or an applied marker. HUD logs and model statements are not proof. A timeout after submit becomes `unconfirmed`; never automatically click Submit again. Reconcile the state before allowing retry.

## 7. Tabs and external websites

Bind each run to registered browser contents and an ownership graph. Attach popup/new-tab listeners before clicking Apply; correlate new contents with the initiating action. Follow expected HTTP(S) application navigation after validating the destination. Block local/privileged schemes and localhost/private-network destinations from website-triggered handoffs. Show external destination changes and let the user configure trusted application sites; unknown or suspicious destinations pause.

Preserve session partition/authentication within each website's origin boundaries. Handle same-tab redirects, child-tab close, delayed popup creation, SPA changes, and return to search. Pause for login, MFA, or CAPTCHA; resume only with a fresh observation. Close only workflow-created tabs when safe. Real Chrome requires a separate browser adapter and validation phase; Electron support does not imply Chrome control works.

## 8. Lifecycle, persistence, and limits

States: idle -> preflight -> searching -> selecting_job -> observing -> deciding -> acting -> verifying_step -> reviewing -> submitting -> confirming -> recording -> next_job -> completed. Explicit paused_user, paused_model, cancelled, failed, skipped, and unconfirmed states retain reasons. Every transition is checked; only one controller owns the action lease.

Use a transactional local store in Electron userData for run/job/action IDs, hashes, outcomes, and evidence summaries. Enforce uniqueness for persona + portal + job ID, with URL normalization fallback. Persist minimal grounded data; redact telemetry and do not retain full screenshots or profile secrets by default. Define retention and deletion controls.

Initial configurable limits: one active job, one inference, one input dispatch; two retries for pre-submit transient errors; three unchanged observations before pause; bounded decisions per job, job duration, run duration, and attempts. Tune defaults from measured fixture/live results. Stop aborts inference and timers, rejects queued actions, releases owned leases, and cannot undo a submission already dispatched. After crash, reconcile any submitting/unconfirmed record instead of replaying it.

## 9. Delivery phases and exit gates

1. **Model integrity:** fix false readiness and alternate backend leakage; unify exact-model requests and badge; pass text/image smoke tests on the actual machine. Do not enable visual actions before this passes.
2. **Observation and execution:** implement narrow IPC, capture, coordinate transforms, one-action protocol, virtual cursor, cancellation, and fixture replay. Pass Retina/zoom/scroll/stale-observation checks.
3. **LinkedIn fixtures:** search, selection, variable multi-step modal, errors, uploads, review, submit, and confirmation. Demonstrate duplicate prevention and missing-persona pauses.
4. **External ATS fixtures:** new tabs, redirects, iframe limitations, popup denial, tab closure, uploads, authentication pause, and search return. Add adapters only when needed; unknown forms remain bounded.
5. **UI integration:** switch below Launch Hub, preference persistence, review settings, mutually exclusive engines, truthful live status, counters, pause/resume/stop, and recovery.
6. **Release verification:** typecheck/build/lint and relevant regression tests; packaged Electron capture/IPC test; real Ollama visual fixture batch; controlled real-site dry runs. Actual application submission is a separately observable run, not inferred from fixtures.

## 10. Required acceptance tests

- Daemon absent, exact tag absent but another model present, failed warmup, empty response, malformed JSON, image rejection, model crash, and memory pressure all prevent actions and readiness.
- Every visual decision request records exact `qwen3.5:4b`; embedded/cloud fallback invocation count is zero.
- Coordinates remain correct at Retina scaling, multiple zoom levels, resized windows, modal scroll, and nested frames; stale targets never dispatch.
- Late inference results after Stop/resume or tab switch cannot act. Disabling the switch prevents the next action.
- Requested jobs/internships and selected IDs are respected; already applied jobs are skipped; batch confirmation counts remain accurate.
- Unsupported fields and factual uncertainty pause without invented values.
- Unknown tab contents cannot receive IPC actions; redirects and popups retain job association.
- A clicked Submit without new confirmation is never marked applied. Crash/restart and ambiguous submit never cause automatic duplicate submissions.
- Fixture confirmations, form errors, and changing page structures produce the correct ledger outcomes; HUD text cannot contaminate verification.
- Run the actual installed Ollama model against deterministic synthetic text/image fixtures and a complete Electron application fixture. Record results and latency; do not call the workflow production-ready until these checks pass.

## 11. Sources

Ollama lists Qwen3.5 4B as accepting text and image input: https://registry.ollama.com/library/qwen3.5/tags . Structured output image example: https://github.com/ollama/ollama-python/blob/main/examples/structured-outputs-image.py . API contract: https://github.com/ollama/ollama/blob/main/docs/api.md . Runtime capability probes remain required regardless of catalog support.
