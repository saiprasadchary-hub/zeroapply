import { app, BrowserWindow } from 'electron';
import http from 'node:http';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { LocalModelRouter } from '../desktop/local-model-router.mjs';
import { VisualBrowserService } from '../desktop/visual-browser-service.mjs';

// Synthetic applicant and website only: this verifier cannot submit a real job application.
const html = `<!doctype html><html><body style="font:24px system-ui;padding:48px;background:white;color:#111"><h1>Python Developer Internship — Fixture Company</h1><form id="application"><label>Full name <input name="fullName" aria-label="Full name" required style="font:24px system-ui"></label><br><br><label>Email <input name="email" aria-label="Email" type="email" required style="font:24px system-ui"></label><br><br><button type="submit" style="font:24px system-ui">Submit application</button></form><script>document.querySelector('form').onsubmit=e=>{e.preventDefault();document.body.innerHTML='<h1>Application submitted successfully</h1><p>Fixture Company · Python Developer Internship · Receipt TEST-001</p>'}</script></body></html>`;
const server = http.createServer((_req, res) => { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(html); });
let window;
let model;
const timeout = setTimeout(() => { console.error('Electron visual verification timed out'); app.exit(1); }, 480000);
app.whenReady().then(async () => {
try {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  console.log('Fixture server ready');
  window = new BrowserWindow({ width: 1100, height: 850, show: true, webPreferences: { webviewTag: true, contextIsolation: true, nodeIntegration: false, sandbox: true } });
  const guestPromise = new Promise(resolve => window.webContents.once('did-attach-webview', (_event, guest) => resolve(guest)));
  await window.loadURL('data:text/html,' + encodeURIComponent(`<html><body style="margin:0"><webview src="http://127.0.0.1:${port}/application" style="width:100vw;height:100vh"></webview></body></html>`));
  const guest = await guestPromise;
  console.log('Electron webview attached');
  if (guest.isLoading()) await new Promise(resolve => guest.once('did-stop-loading', resolve));
  console.log('Electron webview loaded');
  model = new LocalModelRouter({ notify: state => console.log(JSON.stringify({ phase: state.progressText, ready: state.isReady, error: state.error })) });
  const service = new VisualBrowserService({ model, getOwner: () => window.webContents });
  await service.start();
  assert.equal(model.status().visionVerified, true);
  console.log('PASS: exact qwen3.5:4b text + red-image inference in Electron');
  const history = [];
  let submitted = false;
  for (let step = 0; step < 10; step++) {
    const result = await service.decide({ contentsId: guest.id, facts: { fullName: 'Synthetic Applicant', email: 'synthetic@example.com' }, goal: 'Apply for this Python Developer Internship using the supplied fullName and email facts, then submit once.', history: history.slice(-8) });
    console.log(JSON.stringify({ step: step + 1, action: result.decision.action, reason: result.decision.reason }));
    if (result.decision.action === 'pause') throw new Error(result.decision.reason);
    if (result.decision.action === 'done') break;
    const acted = await service.act({ observationId: result.observation.id, decision: result.decision, allowSubmit: true });
    submitted ||= acted.submitted;
    history.push(`${result.decision.action}: ${result.decision.reason}`);
    await new Promise(resolve => setTimeout(resolve, 500));
    if ((await guest.executeJavaScript('document.body.innerText')).includes('Application submitted successfully')) break;
  }
  assert.equal(submitted, true, 'Model must dispatch a submit action');
  assert.match(await guest.executeJavaScript('document.body.innerText'), /Application submitted successfully/);
  await fs.mkdir('audits/screenshots', { recursive: true });
  await fs.writeFile('audits/screenshots/visual-workflow-confirmed.png', (await guest.capturePage()).resize({ width: 1024 }).toPNG());
  console.log('PASS: screenshot -> actual local model -> grounded field filling -> native submit click -> website confirmation');
  // Wrong guest ownership must reject before capture.
  await assert.rejects(service.decide({ contentsId: window.webContents.id, facts: {}, goal: 'Test', history: [] }), /owned/);
  service.stop();
  await assert.rejects(service.act({ observationId: 'stale', decision: { action: 'click', target: 0, factKey: '', reason: '', direction: 'down' }, allowSubmit: true }), /expired/);
  console.log('PASS: non-webview ownership and stale-action rejection');
  await model.stop();
  clearTimeout(timeout); server.close(); window.destroy(); app.exit(0);
} catch (error) {
  console.error(error); clearTimeout(timeout); await model?.stop(); server.close(); window?.destroy(); app.exit(1);
}

});
