import assert from 'node:assert/strict';
import { LocalModelRouter } from '../desktop/local-model-router.mjs';
const router = new LocalModelRouter({});
try {
  assert.equal(router.status().isReady, false);
  router.enableAlwaysOn();
  await router.maintenance;
  assert.equal(router.status().isReady, true);
  console.log('Loaded local backend:', router.status().modelName);
  const answer = await router.generate({ prompt: 'How many years of TypeScript experience? Return just the number.', systemPrompt: 'Applicant fact: 3 years of TypeScript experience. Use only the supplied fact.', maxTokens: 16 });
  assert.match(answer, /^3(?:\b|$)/); console.log('Experience answer:', answer);
  await router.stop();
  assert.equal(router.status().isReady, true, 'Batch cleanup must retain Ollama readiness');
  const city = await router.generate({ prompt: 'What is my city? Return just the city.', systemPrompt: 'Applicant fact: My city is Hyderabad. Use only the supplied fact.', maxTokens: 16 });
  assert.match(city, /Hyderabad/i); console.log('City answer:', city);
} finally { await router.shutdown(); assert.equal(router.status().isReady, false); console.log('Always-on cleanup and shutdown verified.'); }
