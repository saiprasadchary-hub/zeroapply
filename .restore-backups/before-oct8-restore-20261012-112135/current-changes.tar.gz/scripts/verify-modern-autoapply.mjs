import { app, BrowserWindow } from 'electron';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

// Synthetic website only. Execute the production injected scripts in Chromium.
app.whenReady().then(async () => {
  let window;
  try {
    const source = await readFile(new URL('../src/agent/autoApply/autoApplyEngine.ts', import.meta.url), 'utf8');
    const extract = (name, bindings = {}) => {
      const start = source.indexOf(`const ${name} = \``);
      assert.ok(start >= 0);
      const literal = source.slice(start + `const ${name} = `.length, source.indexOf('`;\n', start) + 1);
      return vm.runInNewContext(literal, { JSON, ...bindings });
    };
    window = new BrowserWindow({ show: false, webPreferences: { sandbox: true, contextIsolation: true } });
    await window.loadURL('data:text/html,' + encodeURIComponent(`<!doctype html><html><body>
      <div class="search-filters"><button aria-label="Easy Apply" onclick="window.filterClicked=true">Easy Apply</button></div>
      <main><div role="button" onclick="window.cardClicked=true"><span>Applied AI Engineer</span><button aria-label="Dismiss Applied AI Engineer job">Dismiss</button></div>
      <div role="button"><span>Backend Developer</span><span>Applied</span><button aria-label="Dismiss Backend Developer job">Dismiss</button></div>
      <section><button aria-label="Easy Apply to this job" onclick="document.getElementById('modal').hidden=false">Easy Apply</button></section>
      <div id="modal" role="dialog" hidden><h2>Apply to Fixture Company</h2><input aria-label="Name"><button>Next</button></div></main>
      </body></html>`));
    const cards = await window.webContents.executeJavaScript(extract('detectCardsScript', { UNIVERSAL_JOB_CARD_SELECTORS: '.legacy-card' }));
    assert.equal(cards.length, 2);
    assert.equal(cards[0].title, 'Applied AI Engineer');
    assert.equal(cards[0].isApplied, false, 'Applied in a job title is not submission evidence');
    assert.equal(cards[1].isApplied, true);
    assert.equal(await window.webContents.executeJavaScript(extract('clickCardScript', { UNIVERSAL_JOB_CARD_SELECTORS: '.legacy-card', cardIndex: 0, cardMeta: cards[0] })), true);
    assert.equal(await window.webContents.executeJavaScript('window.cardClicked'), true);
    const result = await window.webContents.executeJavaScript(extract('openModalScript'));
    assert.equal(result.status, 'easy_apply_triggered');
    assert.equal(await window.webContents.executeJavaScript('document.getElementById("modal").hidden'), false);
    assert.equal(await window.webContents.executeJavaScript('window.filterClicked || false'), false);
    await window.webContents.executeJavaScript('document.getElementById("modal").hidden=true');
    const single = await window.webContents.executeJavaScript(extract('singleApplyScript'));
    assert.equal(single.status, 'easy_apply');
    assert.equal(await window.webContents.executeJavaScript('document.getElementById("modal").hidden'), false);
    console.log('PASS: modern role-button cards, applied-status discrimination, card selection, batch and single-job Easy Apply modal opening, filter exclusion.');
    window.destroy(); app.exit(0);
  } catch (error) { console.error(error); window?.destroy(); app.exit(1); }
});
