import { app, BrowserWindow } from 'electron';
import http from 'node:http';
import assert from 'node:assert/strict';
import { VisualBrowserService } from '../desktop/visual-browser-service.mjs';

// Native browser mechanics tests use deterministic decisions, not mocked DOM/input.
app.whenReady().then(async () => {
  const server = http.createServer((_req, res) => { res.writeHead(200, { 'Content-Type': 'text/html' }); res.end('<html><body><form><label>Name<input aria-label="Name"></label><label>Email<input aria-label="Email"></label><input type="password" aria-label="Password"><button type="submit">Submit application</button></form><script>document.querySelector("form").onsubmit=e=>{e.preventDefault();document.body.innerHTML="Application submitted successfully"}</script></body></html>'); });
  let win;
  try {
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    win = new BrowserWindow({ show: true, width: 1000, height: 700, webPreferences: { webviewTag: true } });
    const attached = new Promise(resolve => win.webContents.once('did-attach-webview', (_event, guest) => resolve(guest)));
    await win.loadURL('data:text/html,' + encodeURIComponent(`<webview style="width:100%;height:90vh" src="http://127.0.0.1:${server.address().port}/"></webview>`));
    const guest = await attached;
    if (guest.isLoading()) await new Promise(resolve => guest.once('did-stop-loading', resolve));
    let decision;
    let state = { isReady: true };
    const model = { start: async () => {}, status: () => state, update: value => { state = { ...state, ...value }; }, chat: async (_messages, format) => format ? JSON.stringify(decision) : 'RED' };
    const service = new VisualBrowserService({ model, getOwner: () => win.webContents });
    await service.start();
    const context = { contentsId: guest.id, goal: 'Test native mechanics', facts: { name: 'Fixture Applicant', email: 'fixture@example.com' }, history: [] };
    const observe = async (action, target, factKey = '') => {
      decision = { action, target, factKey, reason: 'Fixture action', direction: 'down' };
      const result = await service.decide(context);
      decision = result.decision;
      return result;
    };
    const suggestion = await observe('pause', -1, 'irrelevant_model_key');
    assert.equal(suggestion.decision.factKey, '');
    await assert.rejects(observe('type', 0, 'unknown_profile_key'), /outside the captured context/);
    let result = await observe('type', 0, 'name');
    await service.act({ observationId: result.observation.id, decision, allowSubmit: false });
    assert.equal(await guest.executeJavaScript('document.querySelector("input").value'), 'Fixture Applicant');
    result = await observe('type', 2, 'name');
    await assert.rejects(service.act({ observationId: result.observation.id, decision, allowSubmit: false }), /protected/);
    result = await observe('type', 1, 'email');
    await guest.executeJavaScript('document.querySelectorAll("input")[1].style.marginTop="20px"');
    await assert.rejects(service.act({ observationId: result.observation.id, decision, allowSubmit: false }), /changed/);
    result = await observe('type', 1, 'email');
    await service.act({ observationId: result.observation.id, decision, allowSubmit: false });
    result = await observe('click', 3);
    await assert.rejects(service.act({ observationId: result.observation.id, decision, allowSubmit: false }), /authorization/);
    result = await observe('submit', 3);
    await assert.rejects(service.act({ observationId: result.observation.id, decision, allowSubmit: false }), /authorization/);
    guest.setZoomFactor(1.25);
    result = await observe('submit', 3);
    await service.act({ observationId: result.observation.id, decision, allowSubmit: true });
    await new Promise(resolve => setTimeout(resolve, 250));
    assert.match(await guest.executeJavaScript('document.body.innerText'), /Application submitted successfully/);
    await assert.rejects(service.decide({ ...context, contentsId: win.webContents.id }), /owned/);
    result = await observe('wait', -1);
    service.stop();
    await assert.rejects(service.act({ observationId: result.observation.id, decision, allowSubmit: false }), /expired/);
    console.log('PASS: native Electron filling, protected fields, stale target rejection, submit authorization, zoomed native click, website confirmation, ownership, cancellation');
    win.destroy(); server.close(); app.exit(0);
  } catch (error) { console.error(error); win?.destroy(); server.close(); app.exit(1); }
});
