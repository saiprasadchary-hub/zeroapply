import { app, nativeImage } from 'electron';
import { LocalModelRouter } from '../desktop/local-model-router.mjs';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

app.whenReady().then(async () => {
  const router = new LocalModelRouter({});
  try {
    await router.start();
    const answer = await router.generate({ prompt: 'What is my city? Return only the city.', systemPrompt: 'The applicant city is Hyderabad.', maxTokens: 24 });
    assert.match(answer, /Hyderabad/i);
    console.log(`PASS: ${router.status().modelName} text inference: ${answer}`);
    const screenshot = await readFile(new URL('../audits/screenshots/visual-workflow-confirmed.png', import.meta.url));
    const image = nativeImage.createFromBuffer(screenshot).resize({ width: 1024 }).toPNG();
    const imageAnswer = await router.chat([{ role: 'user', content: 'Read the application status message visible in this screenshot. Return only that status message.', images: [image.toString('base64')] }]);
    assert.match(imageAnswer, /application submitted successfully/i);
    console.log(JSON.stringify({ imageInference: imageAnswer, model: router.status().modelName, backend: router.status().backend }));
    await router.stop(); app.exit(0);
  } catch (error) { console.error(error); await router.stop(); app.exit(1); }
});
