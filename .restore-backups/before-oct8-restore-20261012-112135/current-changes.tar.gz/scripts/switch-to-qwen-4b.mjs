import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const workspaceDir = path.resolve(__dirname, '..');
const modelfilePath = path.join(workspaceDir, 'Modelfile.zeroapply');

async function request(options, data) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => {
        body += chunk;
        try {
          const lines = chunk.toString().split('\n').filter(Boolean);
          for (const line of lines) {
            const parsed = JSON.parse(line);
            if (parsed.status) {
              if (parsed.total && parsed.completed) {
                const pct = ((parsed.completed / parsed.total) * 100).toFixed(1);
                process.stdout.write(`\r[Ollama] ${parsed.status}: ${pct}%`);
              } else {
                console.log(`[Ollama] ${parsed.status}`);
              }
            }
          }
        } catch {}
      });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

async function main() {
  console.log('============================================================');
  console.log('🚀 Switching ZeroApply Ollama Model to Qwen 3.5 4B (~3.3 GB)');
  console.log('============================================================\n');

  // 1. Check current models in Ollama
  console.log('1. Checking current models in Ollama on port 11434...');
  let tagsRes;
  try {
    tagsRes = await request({
      hostname: '127.0.0.1',
      port: 11434,
      path: '/api/tags',
      method: 'GET',
    });
  } catch (err) {
    throw new Error(`Cannot connect to Ollama daemon on http://127.0.0.1:11434: ${err.message}`);
  }

  if (tagsRes.status !== 200) {
    throw new Error(`Ollama server not responding on 11434 (status ${tagsRes.status})`);
  }

  const tagsData = JSON.parse(tagsRes.body);
  const installedNames = tagsData.models?.map((m) => m.name) || [];
  console.log('Currently installed in Ollama:', installedNames);

  const hasQwen4B = installedNames.some((n) => n.toLowerCase().startsWith('qwen3.5:4b'));

  // 2. Verify or pull qwen3.5:4b
  if (hasQwen4B) {
    console.log('\n✓ qwen3.5:4b is already downloaded and present in Ollama!');
  } else {
    console.log('\n2. Downloading and installing qwen3.5:4b (~3.3 GB)...');
    await request(
      {
        hostname: '127.0.0.1',
        port: 11434,
        path: '/api/pull',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      },
      JSON.stringify({ name: 'qwen3.5:4b', stream: true })
    );
    console.log('\n✓ qwen3.5:4b downloaded and ready!');
  }

  // 3. Compile or update specialized zeroapply model if Modelfile exists
  if (fs.existsSync(modelfilePath)) {
    console.log('\n3. Compiling custom "zeroapply" model with qwen3.5:4b base...');
    const modelfileContent = fs.readFileSync(modelfilePath, 'utf8');
    try {
      const createRes = await request(
        {
          hostname: '127.0.0.1',
          port: 11434,
          path: '/api/create',
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
        },
        JSON.stringify({
          model: 'zeroapply',
          modelfile: modelfileContent,
          stream: false,
        })
      );
      if (createRes.status === 200) {
        console.log('✓ "zeroapply" custom model successfully re-compiled with Qwen 3.5 4B base!');
      } else {
        console.warn(`Note: "zeroapply" custom model creation returned status ${createRes.status}: ${createRes.body}`);
      }
    } catch (createErr) {
      console.warn('Note: Could not compile custom zeroapply model via HTTP API:', createErr.message);
    }
  }

  // 4. Verification
  console.log('\n4. Verifying active Ollama models...');
  const verifyRes = await request({
    hostname: '127.0.0.1',
    port: 11434,
    path: '/api/tags',
    method: 'GET',
  });
  const verifyData = JSON.parse(verifyRes.body);
  console.log('Available models:', verifyData.models?.map((m) => m.name));
  console.log('\n🎉 SUCCESS: qwen3.5:4b is active and ready for ZeroApply autonomous applications!');
}

main().catch((err) => {
  console.error('\n❌ Error switching model:', err.message);
  process.exit(1);
});
