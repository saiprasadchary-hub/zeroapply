import type { SubmissionVerificationResult } from './normalApplyTypes';
import type { WebviewTarget } from '../domScanner/injectedScanner';

export class SubmissionVerifier {
  /**
   * Verifies whether an external ATS submission successfully completed and was confirmed.
   */
  public async verifySubmission(view: WebviewTarget): Promise<SubmissionVerificationResult> {
    const script = `
      (() => {
        const url = (window.location.href || '').toLowerCase();
        const pathname = new URL(url).pathname.toLowerCase();
        // Agent overlays can contain prior success logs; only website text is evidence.
        const chunks = [];
        if (document.body) {
          const walker = document.createTreeWalker(document.body, 4);
          let node;
          while ((node = walker.nextNode())) {
            const parent = node.parentElement;
            if (!parent || parent.closest('#zeroapply-live-hud-root, #zeroapply-codex-cursor-root, #za-active-badge, script, style, [hidden], [aria-hidden="true"]')) continue;
            if (parent.getClientRects().length === 0) continue;
            chunks.push(node.textContent || '');
          }
        }
        const text = chunks.join(' ').toLowerCase();

        // 1. Success URL signatures
        const successUrlKeywords = [
          '/thank-you',
          '/thankyou',
          '/confirmation',
          '/submitted',
          '/success',
          '/applied',
          '/application-received',
          '/complete',
          '/formresponse'
        ];
        for (const kw of successUrlKeywords) {
          if (pathname.split('/').filter(Boolean).includes(kw.slice(1))) {
            return {
              isConfirmed: true,
              reason: 'URL indicates successful submission (' + kw + ')',
              details: url
            };
          }
        }

        // 2. DOM text confirmation patterns
        const confirmationPatterns = [
          /your application was sent/i,
          /application (has been )?submitted/i,
          /application submitted successfully/i,
          /form submitted successfully/i,
          /successfully submitted/i,
          /thank you for (your )?applying/i,
          /thanks for (your )?applying/i,
          /thank you for (your )?submission/i,
          /thanks for (your )?submission/i,
          /application received/i,
          /received your application/i,
          /we have received your application/i,
          /we've received your application/i,
          /application was received/i,
          /submission successful/i,
          /your response has been recorded/i,
          /response has been recorded/i,
          /submit another response/i,
          /form submitted/i
        ];

        for (const pat of confirmationPatterns) {
          if (pat.test(text)) {
            return {
              isConfirmed: true,
              reason: 'Found confirmation message in page content: ' + pat.source,
              details: text.slice(0, 200)
            };
          }
        }

        // 3. Known ATS success elements
        const successSelector = [
          '.success-view',
          '#step-success.active',
          '[class*="application-submitted"]',
          '[class*="success-message"]',
          '[data-automation-id="congratulations"]',
          '.application-confirmation',
          '#application-confirmation',
          '.post-apply-container',
          '.freebirdFormviewerViewResponseConfirmationMessage',
          '[jsname="paFMDb"]'
        ].join(', ');

        const successEl = document.querySelector(successSelector);
        if (successEl && successEl.offsetParent !== null) {
          return {
            isConfirmed: true,
            reason: 'Detected ATS success confirmation container element',
            details: successEl.className || successEl.id
          };
        }

        return {
          isConfirmed: false,
          reason: 'No explicit confirmation signatures detected on page'
        };
      })()
    `;

    try {
      const res = await view.executeJavaScript<SubmissionVerificationResult>(script);
      if (res && typeof res.isConfirmed === 'boolean') {
        return res;
      }
    } catch {}

    return {
      isConfirmed: false,
      reason: 'Failed to evaluate submission confirmation script',
    };
  }
}
