export type AgentActivityPhase = 'idle' | 'starting' | 'capturing' | 'thinking' | 'acting' | 'verifying' | 'confirmed' | 'paused' | 'stopped' | 'completed';
export interface AgentActivity {
  phase: AgentActivityPhase;
  message: string;
  timestamp: number;
  url?: string;
  step?: number;
  confirmed?: number;
  target?: number;
}
export const ACTIVITY_LABELS: Record<AgentActivityPhase, string> = {
  idle: 'Standby', starting: 'Starting local AI', capturing: 'Capturing the page', thinking: 'Ollama is deciding',
  acting: 'Next action', verifying: 'Checking the result', confirmed: 'Application confirmed',
  paused: 'Needs attention', stopped: 'Stopped', completed: 'Run finished',
};
