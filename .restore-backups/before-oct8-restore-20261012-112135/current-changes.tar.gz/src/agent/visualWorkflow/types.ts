export type VisualActionKind = 'click' | 'type' | 'select' | 'scroll' | 'wait' | 'submit' | 'upload_resume' | 'pause' | 'done';
export interface VisualDecision {
  action: VisualActionKind;
  target: number;
  factKey: string;
  reason: string;
  direction: 'up' | 'down';
}
export interface VisualObservation {
  id: string;
  url: string;
  title: string;
  text: string;
  jobKey: string;
  targets: { id: number; label: string; tag: string; type: string; value: string; options: string[] }[];
}
export interface VisualStep {
  observation: VisualObservation;
  decision: VisualDecision;
}
export interface VisualBridge {
  startVisualWorkflow: () => Promise<void>;
  decideVisualWorkflow: (payload: { contentsId: number; goal: string; facts: Record<string, string>; history: string[]; resume?: { name: string; type: string; base64: string } }) => Promise<VisualStep>;
  actVisualWorkflow: (payload: { observationId: string; decision: VisualDecision; value?: string; allowSubmit: boolean }) => Promise<{ submitted: boolean }>;
  stopVisualWorkflow: () => Promise<void>;
}
