import type { AgentActivity, AgentActivityPhase } from './activity';
import { ApplicationLogger } from '../tracker/applicationLogger';
import { extractJobContext } from '../vision/jobContextExtractor';
import { getStoredResume } from '../fileUpload/resumeFileAdapter';
import type { PersonaData } from '../../types';
import { getSecureItem, setSecureItem } from '../../services/secureStorage';
import { SubmissionVerifier } from '../normalApply/submissionVerifier';
import type { VisualBridge } from './types';

export interface VisualPage {
  getWebContentsId(): number;
  getURL(): string;
  executeJavaScript<T = unknown>(script: string): Promise<T>;
  loadURL(url: string): Promise<void>;
}
export function profileFacts(persona: PersonaData): Record<string, string> {
  const facts: Record<string, string> = {};
  for (const [key, value] of Object.entries(persona)) {
    if (typeof value === 'string' && value.trim() && !['resumeText', 'browserMode'].includes(key)) facts[key] = value.trim().slice(0, 12000);
    if (typeof value === 'number' && Number.isFinite(value)) facts[key] = String(value);
  }
  const names = persona.fullName.trim().split(/\s+/);
  if (names.length > 1) { facts.firstName = names.slice(0, -1).join(' '); facts.lastName = names.at(-1) || ''; }
  if (persona.techStack?.length) facts.techStack = persona.techStack.join(', ');
  for (const [key, value] of Object.entries(persona.resumeChunks || {})) if (value?.trim()) facts[`resume.${key}`] = value.slice(0, 12000);
  return facts;
}

export class VisualWorkflowController {
  private version = 0;
  private running = false;
  public stop(): void {
    ++this.version;
    this.running = false;
    void window.zeroApply?.stopVisualWorkflow?.().catch((): void => {});
  }
  public async run(config: {
    persona: PersonaData;
    page: VisualPage;
    currentPage: () => VisualPage | undefined;
    returnToSearch: () => Promise<void>;
    notify: (message: string) => void;
    onActivity?: (activity: AgentActivity) => void;
    isActive: () => boolean;
  }): Promise<void> {
    if (this.running) throw new Error('Visual workflow is already running.');
    const bridge = window.zeroApply;
    if (!bridge?.startVisualWorkflow || !bridge.decideVisualWorkflow || !bridge.actVisualWorkflow || !bridge.stopVisualWorkflow) throw new Error('Restart Electron to load the visual workflow bridge.');
    const api = bridge as typeof bridge & VisualBridge;
    this.running = true;
    const version = ++this.version;
    const active = (): boolean => this.running && this.version === version && config.isActive();
    const facts = profileFacts(config.persona);
    const storedResume = getStoredResume();
    const resume = storedResume?.base64Data ? { name: storedResume.name, type: storedResume.type, base64: storedResume.base64Data.replace(/^data:[^,]+,/, "") } : undefined;
    const history: string[] = [];
    const limit = Math.max(1, Math.min(50, config.persona.applicationLimit || 5));
    const started = Date.now();
    let confirmed = 0;
    let submittedKey = '';
    let jobUrl = '';
    let jobTitle = '';
    let companyName = '';
    let fieldsFilled = 0;
    let unchanged = 0;
    let staleRetries = 0;
    let confirmationPolls = 0;
    const report = (phase: AgentActivityPhase, message: string, step?: number): void => {
      config.onActivity?.({ phase, message, step, confirmed, timestamp: Date.now(), url: (config.currentPage() || config.page).getURL() });
    };
    let previousFingerprint = '';
    const storageKey = 'zeroapply_visual_application_ledger';
    let ledger: Record<string, { outcome: string; at: number }> = {};
    try {
      const stored: unknown = JSON.parse((bridge.secureGet ? bridge.secureGet(storageKey) : getSecureItem(storageKey)) || '{}');
      if (stored && typeof stored === 'object' && !Array.isArray(stored)) ledger = stored as typeof ledger;
    } catch { throw new Error('Application ledger is unreadable; resolve it before starting to prevent duplicate submissions.'); }
    const persist = async (key: string, outcome: string): Promise<void> => {
      ledger[key] = { outcome, at: Date.now() };
      // Keep the latest records bounded; confirmed applications remain in the existing app tracker too.
      if (Object.keys(ledger).length > 5000) throw new Error('Application ledger is full. Archive it before continuing.');
      const value = JSON.stringify(ledger);
      if (bridge.secureSet) {
        if (!await bridge.secureSet(storageKey, value)) throw new Error('Could not persist the submission lease.');
      } else setSecureItem(storageKey, value);
    };
    try {
      report('starting', 'Check that Ollama can read text and screenshots.');
      config.notify('Verifying Ollama qwen3.5:4b text and screenshot inference…');
      await api.startVisualWorkflow();
      if (!active()) return;
      config.notify('Ollama vision verified. Starting screenshot-guided workflow.');
      for (let step = 0; step < 120 && Date.now() - started < 30 * 60_000 && confirmed < limit && active(); step++) {
        const page = config.currentPage() || config.page;
        if (submittedKey) {
          // Only fresh website evidence after our submit action can confirm this application.
          report('verifying', 'Check whether the application was submitted.', step + 1);
          const verification = await new SubmissionVerifier().verifySubmission(page);
          if (verification.isConfirmed) {
            await persist(submittedKey, 'confirmed');
            ApplicationLogger.log({ portal: new URL(jobUrl).hostname, jobTitle, companyName, jobUrl, status: 'SUCCESS', fieldsFilled, totalFields: fieldsFilled, submissionEvidence: verification.reason, durationSeconds: Math.round((Date.now() - started) / 1000), details: 'Ollama qwen3.5:4b visual workflow; fresh website confirmation.' });
            fieldsFilled = 0;
            confirmed++;
            submittedKey = '';
            history.push('Website confirmed submission. Return to search and choose a different matching job.');
            report('confirmed', 'Application confirmed by the website.', step + 1);
            config.notify(`Application confirmed (${confirmed}/${limit}).`);
            if (confirmed < limit && active()) await config.returnToSearch();
            continue;
          }
          if (++confirmationPolls >= 10) throw new Error('Submission is unconfirmed. Review this application; it will not be submitted again automatically.');
          await new Promise<void>((resolve) => setTimeout(resolve, 1000));
          continue;
        }
        report('capturing', 'Take a screenshot and check the page.', step + 1);
        const result = await api.decideVisualWorkflow({ contentsId: page.getWebContentsId(), facts, resume,
          goal: `Apply to up to ${limit} matching jobs/internships. Roles: ${config.persona.targetRoles.join(', ')}. Location: ${config.persona.location}. Work preference: ${config.persona.workPreference}. Mode: ${config.persona.applyMode}. Confirmed so far: ${confirmed}. Never open an already completed job: ${Object.keys(ledger).slice(-40).join(', ')}.`,
          history: history.slice(-8),
        });
        if (!active()) return;
        if ((config.currentPage() || config.page).getWebContentsId() !== page.getWebContentsId()) {
          history.push('Application opened a new tab. Observe the new tab before acting.');
          continue;
        }
        const { observation, decision } = result;
        const key = `${config.persona.email.toLowerCase()}|${observation.jobKey}`;
        const fingerprint = JSON.stringify([observation.url, observation.text, observation.targets]);
        unchanged = fingerprint === previousFingerprint ? unchanged + 1 : 0;
        previousFingerprint = fingerprint;
        if (unchanged >= 3) throw new Error('Page is not changing. Review the current form before resuming.');
        history.push(`${decision.action}: ${decision.reason}`.slice(0, 1000));
        config.notify(`Visual step ${step + 1} · ${confirmed}/${limit} confirmed · ${decision.reason}`);
        if (decision.action === 'pause') throw new Error(decision.reason || 'Manual input is required.');
        if (decision.action === 'done') {
          if (confirmed === 0) throw new Error('No new application submission has been confirmed.');
          break;
        }
        if (decision.action === 'submit') {
          const before = await new SubmissionVerifier().verifySubmission(page);
          if (before.isConfirmed) throw new Error('This page already shows a confirmation; refusing another submission.');
          if (ledger[key]) throw new Error('This application was previously submitted or remains unconfirmed. Review it before retrying.');
          if (ApplicationLogger.hasSubmitted({ jobUrl: observation.url })) throw new Error('This job already has a confirmed application in the dashboard.');
          const context = await extractJobContext(page);
          jobUrl = observation.url; jobTitle = context.jobTitle || observation.title; companyName = context.companyName || 'Unknown employer';
          await persist(key, 'submitting');
          if (!active()) return;
          submittedKey = key;
          confirmationPolls = 0;
        }
        const targetLabel = (observation.targets.find((target): boolean => target.id === decision.target)?.label || 'the selected button')
          .replace(/\s+/g, ' ').trim().slice(0, 80);
        const actionMessage = decision.action === 'type' ? `Fill ${targetLabel} from your saved details.`
          : decision.action === 'select' ? `Choose your saved answer for ${targetLabel}.`
          : decision.action === 'upload_resume' ? 'Attach your saved resume.'
          : decision.action === 'submit' ? 'Submit once, then check confirmation.'
          : decision.action === 'scroll' ? `Scroll ${decision.direction} to see more fields.`
          : decision.action === 'wait' ? 'Wait for the page to update.'
          : /easy\s*apply/i.test(targetLabel) ? 'Open Easy Apply.'
          : /^next\b|^continue\b/i.test(targetLabel) ? 'Go to the next step.'
          : /^review\b/i.test(targetLabel) ? 'Open the application review.'
          : `Click ${targetLabel}.`;
        report('acting', actionMessage, step + 1);
        try {
          await api.actVisualWorkflow({ observationId: observation.id, decision, allowSubmit: true });
          staleRetries = 0;
        } catch (error: unknown) {
          const message = error instanceof Error ? error.message : 'Browser action failed.';
          if (!submittedKey && /expired|Page changed|Target moved|obscured|outside viewport/.test(message) && ++staleRetries <= 2) {
            history.push('Target changed. Capture a new screenshot before deciding again.');
            continue;
          }
          throw error;
        }
        if (['type', 'select', 'upload_resume'].includes(decision.action)) fieldsFilled++;
        if (!active()) return;
        await new Promise<void>((resolve) => setTimeout(resolve, decision.action === 'wait' ? 1500 : 900));
      }
      if (submittedKey) throw new Error('Submission remains unconfirmed; automatic retry is blocked.');
      if (active()) report('completed', `Run finished with ${confirmed}/${limit} applications confirmed.`);
      if (active()) config.notify(`Visual workflow finished: ${confirmed}/${limit} applications confirmed${confirmed < limit ? '; target not reached within workflow limits' : ''}.`);
    } catch (error: unknown) {
      if (active()) report('paused', error instanceof Error ? error.message : 'The workflow needs attention.');
      throw error;
    } finally {
      if (submittedKey) await persist(submittedKey, 'unconfirmed');
      if (this.version === version) { this.running = false; await api.stopVisualWorkflow(); }
    }
  }
}
