export interface WebLlmEngineState {
  isReady: boolean;
  isLoading: boolean;
  progressText?: string;
  progressPercent?: number;
  modelName?: string;
  error?: string;
  backend?: 'ollama';
  visionVerified?: boolean;
  autoReconnect?: boolean;
}

let currentState: WebLlmEngineState = {
  isReady: false, isLoading: false, progressText: 'AI standby', progressPercent: 0,
  modelName: 'qwen3.5:4b',
};
const subscribers = new Set<(state: WebLlmEngineState) => void>();
let startup: Promise<void> | null = null;
let sessionVersion = 0;
let bridgeSubscribed = false;

export function getWebLlmState(): WebLlmEngineState { return { ...currentState }; }
function updateState(state: WebLlmEngineState): void {
  currentState = { ...state };
  for (const subscriber of subscribers) subscriber(getWebLlmState());
}
export function subscribeWebLlmState(callback: (state: WebLlmEngineState) => void): () => void {
  if (!bridgeSubscribed && typeof window !== 'undefined' && window.zeroApply?.onEmbeddedLlmState) {
    bridgeSubscribed = true;
    window.zeroApply.onEmbeddedLlmState(updateState);
    const version = sessionVersion;
    void window.zeroApply.getEmbeddedLlmStatus?.().then((state): void => {
      if (version === sessionVersion && !startup) updateState(state);
    }).catch((): void => {});
  }
  subscribers.add(callback);
  callback(getWebLlmState());
  return () => { subscribers.delete(callback); };
}

// Desktop startup maintains model availability; this entry point supports manual retry.
export function initWebLlmEngine(trigger: 'review-start'): Promise<void> {
  if (trigger !== 'review-start') return Promise.reject(new Error('Invalid local AI connection trigger.'));
  if (startup) return startup;
  if (currentState.isReady) return Promise.resolve();
  const bridge = typeof window === 'undefined' ? undefined : window.zeroApply;
  if (!bridge?.startEmbeddedLlm) return Promise.reject(new Error('Local Ollama is available in the ZeroApply desktop app.'));
  const version = ++sessionVersion;
  updateState({ ...currentState, isLoading: true, error: undefined, progressText: 'Connecting to local AI…', progressPercent: 25 });
  const loading = bridge.startEmbeddedLlm().then((state) => {
    if (version !== sessionVersion) throw new Error('AutoApply startup cancelled.');
    if (!state.isReady) throw new Error(state.error || 'Local AI did not finish loading.');
    updateState(state);
  }).catch(async (error: unknown) => {
    if (error instanceof Error && error.message.includes('cancelled')) throw error;
    if (version === sessionVersion) updateState({ ...currentState, isLoading: false, isReady: false, error: error instanceof Error ? error.message : 'Ollama failed to start.' });
    throw error;
  }).finally(() => { if (startup === loading) startup = null; });
  startup = loading;
  return loading;
}

export async function ensureEmbeddedModelReady(): Promise<void> {
  if (startup) await startup;
  if (!currentState.isReady) throw new Error(currentState.error || 'Local Ollama is connecting automatically. Wait for AI ready or retry the connection.');
}

export async function stopEmbeddedModel(): Promise<void> {
  const version = ++sessionVersion;
  startup = null;
  const bridge = typeof window === 'undefined' ? undefined : window.zeroApply;
  if (!bridge?.stopEmbeddedLlm) return;
  await bridge.stopEmbeddedLlm();
  // Readiness belongs to the desktop service, independently of application runs.
  const state = await bridge.getEmbeddedLlmStatus?.();
  if (state && version === sessionVersion && !startup) updateState(state);
}

export async function generateWebLlmResponse(prompt: string, systemPrompt = '', temperature = 0, maxTokens = 256): Promise<string> {
  await ensureEmbeddedModelReady();
  const generate = typeof window === 'undefined' ? undefined : window.zeroApply?.generateEmbeddedLlm;
  if (!generate) throw new Error('Local Ollama requires the desktop app.');
  // The desktop router owns readiness. A rejected or stale caller must not
  // overwrite the state of a newer visual session.
  return generate({ prompt, systemPrompt, temperature, maxTokens });
}
