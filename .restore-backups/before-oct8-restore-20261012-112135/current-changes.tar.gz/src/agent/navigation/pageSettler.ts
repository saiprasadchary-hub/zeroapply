/**
 * ZeroApply Navigation - Page Settler & Loading Guard
 * Ensures the web page, React components, dynamic job detail panes, and application modals
 * are 100% loaded, hydrated, and settled before the autonomous agent attempts to click or interact.
 */

export interface WebviewTarget {
  executeJavaScript: <T>(code: string) => Promise<T>;
}

export interface SettleOptions {
  timeoutMs?: number;
  minStableMs?: number;
  requiredSelector?: string;
  checkLoaders?: boolean;
}

/**
 * Waits for the document readyState to reach 'complete', verifies that
 * dynamic skeleton loaders/spinners are gone, and allows a brief settling buffer.
 */
export async function waitForPageSettled(
  view: WebviewTarget,
  options: SettleOptions = {}
): Promise<boolean> {
  const timeout = options.timeoutMs || 5000;
  const minStable = options.minStableMs || 200;
  const start = Date.now();

  while (Date.now() - start < timeout) {
    try {
      const state = await view.executeJavaScript<{
        isComplete: boolean;
        hasActiveBlocker: boolean;
        hasRequired: boolean;
        requiredCount: number;
        elementCount: number;
      }>(`
        (() => {
          const isComplete = document.readyState === 'complete' || document.readyState === 'interactive';
          
          const hasRequired = ${options.requiredSelector ? `!!document.querySelector(${JSON.stringify(options.requiredSelector)})` : 'true'};
          const requiredCount = ${options.requiredSelector ? `document.querySelectorAll(${JSON.stringify(options.requiredSelector)}).length` : '1'};

          let hasActiveBlocker = false;
          if (!hasRequired || requiredCount === 0) {
            const loaders = Array.from(document.querySelectorAll(
              '.artdeco-loader, .inline-spinner, .jobs-search-results-list__loading, .loading-spinner, .artdeco-spinner'
            ));
            hasActiveBlocker = loaders.some((el) => {
              const style = window.getComputedStyle ? window.getComputedStyle(el) : null;
              return el.offsetParent !== null && style && style.display !== 'none' && style.visibility !== 'hidden';
            });
          }

          const elementCount = document.body ? document.body.querySelectorAll('*').length : 0;

          return { isComplete, hasActiveBlocker, hasRequired, requiredCount, elementCount };
        })()
      `);

      if (state && state.isComplete && state.hasRequired && !state.hasActiveBlocker && state.elementCount > 30) {
        // Dynamic React hydration stabilization (snappy micro-delay)
        const settleDelay = Math.min(minStable, 80);
        if (settleDelay > 0) {
          await new Promise((r) => setTimeout(r, settleDelay));
        }
        return true;
      }
    } catch {
      // Transient error during page navigation
    }

    await new Promise((r) => setTimeout(r, 80));
  }

  return false;
}

/**
 * After clicking a job card in the search list, waits for the right-hand job detail pane
 * to finish fetching and rendering the new job's details and Easy Apply button.
 */
export async function waitForJobDetailPaneSettled(
  view: WebviewTarget,
  timeoutMs = 3500
): Promise<boolean> {
  const start = Date.now();

  while (Date.now() - start < timeoutMs) {
    try {
      const isReady = await view.executeJavaScript<boolean>(`
        (() => {
          const detailPane = document.querySelector(
            '.scaffold-layout__detail, .jobs-search__job-details, .job-view-layout, .jobs-details, .jobs-details__main-content, [data-job-details="true"], .jobs-description__container, .jobs-description, .job-details-pane, .scaffold-layout__list-detail-inner, .org-jobs-job-search-results-list, .jobs-unified-top-card'
          );

          // Check for active skeleton loaders or spinners inside the detail pane
          const targetRoot = detailPane || document;
          const paneLoaders = Array.from(targetRoot.querySelectorAll('.artdeco-loader, .inline-spinner, [data-test-skeleton], .jobs-search-results-list__loading'));
          const hasActiveLoaders = paneLoaders.some((l) => {
            const style = window.getComputedStyle ? window.getComputedStyle(l) : null;
            return l.offsetParent !== null && style && style.display !== 'none' && style.visibility !== 'hidden';
          });
          if (hasActiveLoaders) return false;

          // 1. Direct apply button fast-path: ONLY query within detail pane / top card, NEVER the left rail or alert switch
          const applyBtn = detailPane ? detailPane.querySelector(
            'button.jobs-apply-button, [data-view-name="job-apply-button"] button, .jobs-apply-button--top-card button, button#main-easy-apply-btn, a.jobs-apply-button, button[data-za-apply-btn], .jobs-s-apply button, button[aria-label*="Easy Apply" i]'
          ) : null;

          if (applyBtn && !applyBtn.disabled && applyBtn.getAttribute('aria-disabled') !== 'true') {
            // Guard: Never match alert switches or search filters
            const isAlert = applyBtn.closest('.jobs-search-create-alert, [class*="alert"], form[action*="alert"], form[action*="jobalert"], .jobs-search-box') || applyBtn.getAttribute('role') === 'switch';
            if (!isAlert) {
              const rect = applyBtn.getBoundingClientRect();
              if (applyBtn.offsetParent !== null || rect.width > 0) {
                return true;
              }
            }
          }

          // Otherwise return true if detail pane container exists without active spinners
          return !!detailPane;
        })()
      `);

      if (isReady) {
        // Snappy listener attachment buffer
        await new Promise((r) => setTimeout(r, 60));
        return true;
      }
    } catch {}

    await new Promise((r) => setTimeout(r, 80));
  }

  return false;
}

/**
 * After clicking "Easy Apply", waits for the multi-step application modal overlay
 * to open and finish rendering its initial form step.
 */
export async function waitForEasyApplyModalOpened(
  view: WebviewTarget,
  timeoutMs = 5000
): Promise<boolean> {
  const start = Date.now();

  while (Date.now() - start < timeoutMs) {
    try {
      const isOpened = await view.executeJavaScript<boolean>(`
        (() => {
          // Auto-bypass Job Search Safety Reminder if it appears
          const allBtns = Array.from(document.querySelectorAll('button, [role="button"], a.artdeco-button, a[role="button"]'));
          const continueApplyingBtn = allBtns.find(b => {
            const t = (b.textContent || b.getAttribute('aria-label') || '').trim().toLowerCase();
            return /continue\\s*applying/i.test(t);
          });
          if (continueApplyingBtn && !continueApplyingBtn.disabled) {
            try { continueApplyingBtn.click(); } catch(e) {}
          }

          function isMessagingElement(el) {
            if (!el) return false;
            try {
              const sel = '.msg-overlay-container, #msg-overlay, #messaging-widget, .msg-overlay-bubble-header, .msg-overlay-list-bubble, .msg-overlay-conversation-bubble, [class*="msg-overlay"], aside[aria-label*="Messaging" i], [data-view-name*="messaging" i]';
              if (el.matches && el.matches(sel)) return true;
              if (el.closest && el.closest(sel)) return true;
            } catch(e) {}
            return false;
          }

          function isTrulyVisible(el) {
            if (!el || el.hidden) return false;
            let curr = el;
            while (curr && curr !== document.body && curr !== document.documentElement) {
              if (curr.style && curr.style.display === 'none') return false;
              if (curr.hidden) return false;
              if (window.getComputedStyle) {
                const cs = window.getComputedStyle(curr);
                if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0' || parseFloat(cs.opacity) < 0.1) return false;
              }
              if (curr.id === 'easy-apply-modal-overlay' && !curr.classList.contains('active')) return false;
              curr = curr.parentElement;
            }
            const r = el.getBoundingClientRect ? el.getBoundingClientRect() : { width: 0, height: 0 };
            return r.width > 80 && r.height > 80;
          }

          // Robust check for any active visible application modal dialog
          const modalCandidates = Array.from(document.querySelectorAll(
            '#artdeco-modal-outlet .artdeco-modal, .artdeco-modal, [role="dialog"], .jobs-easy-apply-modal, [data-test-modal-id="easy-apply-modal"], .jobs-easy-apply-content, [data-view-name="job-apply-modal"], #easy-apply-modal-overlay.active'
          )).filter(m => {
            if (!m || isMessagingElement(m)) return false;
            if (m.id === 'easy-apply-modal-overlay' && !m.classList.contains('active')) return false;
            return isTrulyVisible(m);
          });

          // Check if ANY candidate modal is an active application modal
          const validModal = modalCandidates.find(modal => {
            const hasInteractive = !!modal.querySelector(
              'input, select, textarea, .fb-form-element, .jobs-easy-apply-form-element, button.artdeco-button--primary, button[data-easy-apply-next-button], button[data-easy-apply-submit-button], [data-za-step-btn], footer button, .artdeco-modal__actionbar button'
            );
            const modalText = (modal.textContent || '').toLowerCase();
            const hasApplyText = /apply|contact info|resume|screen|question|phone|email|education|experience|submit/i.test(modalText);
            return hasInteractive || hasApplyText;
          });

          return !!validModal;
        })()
      `);

      if (isOpened) {
        // Snappy slide-in and field hydration buffer
        await new Promise((r) => setTimeout(r, 120));
        return true;
      }
    } catch {}

    await new Promise((r) => setTimeout(r, 80));
  }

  return false;
}
