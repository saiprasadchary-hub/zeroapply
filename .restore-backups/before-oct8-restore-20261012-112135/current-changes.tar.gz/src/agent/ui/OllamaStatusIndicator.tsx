import React, { useEffect, useState } from 'react';
import { Cpu } from 'lucide-react';
import { getWebLlmState, subscribeWebLlmState, initWebLlmEngine } from '../llm/webLlmEngine';

export const OllamaStatusIndicator: React.FC = () => {
  const [state, setState] = useState(getWebLlmState);
  useEffect(() => subscribeWebLlmState(setState), []);

  const handleActivate = () => {
    if (!state.isReady && !state.isLoading) {
      void initWebLlmEngine('review-start').catch(() => {});
    }
  };

  return (
    <div
      role="status"
      onClick={handleActivate}
      className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono border transition-all cursor-pointer ${
        state.isReady
          ? 'border-emerald-500/60 bg-emerald-950/40 text-emerald-400'
          : state.isLoading
          ? 'border-amber-500/60 bg-amber-950/40 text-amber-300 animate-pulse'
          : state.error
          ? 'border-red-500/60 bg-red-950/40 text-red-400'
          : 'border-zinc-700 bg-zinc-800/80 text-zinc-400 hover:border-cyan-500/60 hover:text-cyan-300'
      }`}
      title={
        state.error
          ? `Local AI Error: ${state.error}. ${state.autoReconnect ? 'Reconnecting automatically; click to retry now.' : 'Click to retry.'}`
          : state.isReady
          ? 'Local Ollama LLM (Qwen 3.5:4b) is active and ready.'
          : state.isLoading
          ? state.progressText || 'Waiting for Ollama verification…'
          : 'Local Qwen 3.5:4b connects automatically when the desktop app opens. Click to retry now.'
      }
    >
      <Cpu size={10} className={state.isReady ? 'text-emerald-400' : state.isLoading ? 'text-amber-400' : 'text-zinc-500'} />
      <span>{state.error ? (state.autoReconnect ? 'OLLAMA RECONNECTING (CLICK TO RETRY NOW)' : 'OLLAMA ERROR (CLICK TO RETRY)') : state.isLoading ? 'VERIFYING OLLAMA' : state.isReady ? (state.progressText ? state.progressText.toUpperCase() : 'AI READY') : 'AI CONNECTING (CLICK TO RETRY)'}</span>
    </div>
  );
};
