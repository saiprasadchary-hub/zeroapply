import { useEffect, useState } from 'react';
import { Activity, CheckCircle2, CirclePause, Cpu, LoaderCircle, Square } from 'lucide-react';
import { ACTIVITY_LABELS } from '../visualWorkflow/activity';
import type { AgentActivity } from '../visualWorkflow/activity';

interface VisualAgentPanelProps {
  activity: AgentActivity | null;
  history: AgentActivity[];
  running: boolean;
  enabled: boolean;
  modelReady: boolean;
  modelLoading?: boolean;
  onStop: () => void;
  onInspect: () => void;
}
export function VisualAgentPanel({ activity, history, running, enabled, modelReady, modelLoading, onStop, onInspect }: VisualAgentPanelProps): React.JSX.Element {
  const [now, setNow] = useState<number>(() => Date.now());
  useEffect((): (() => void) | undefined => {
    if (!running) return undefined;
    const timer = setInterval((): void => setNow(Date.now()), 1000);
    return (): void => clearInterval(timer);
  }, [running]);
  const phase = activity?.phase || 'idle';
  const waiting = running && ['starting', 'capturing', 'thinking', 'verifying'].includes(phase);
  const message = activity?.message || (enabled ? 'Ready. Start AutoApply to capture the page and ask your local model for the next action.' : 'Ready for standard AutoApply. Click Fill & Apply to start; screenshot-guided mode is optional.');
  return (
    <aside aria-label="Live agent activity" className="w-80 max-w-[35vw] shrink-0 border-l border-zinc-200 bg-zinc-50 flex flex-col min-h-0 text-zinc-900">
      <div className="p-4 border-b border-zinc-200 flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-sm font-bold"><Activity size={17} className="text-cyan-700" />Live agent</h2>
        <span className={`rounded-full px-2 py-1 text-[11px] font-semibold ${running ? 'bg-cyan-100 text-cyan-900' : 'bg-zinc-200 text-zinc-700'}`}>{running ? 'Agent running' : 'Agent idle'}</span>
      </div>
      <div className="p-4 border-b border-zinc-200">
        <div className="flex items-center gap-2 text-xs text-zinc-600"><Cpu size={14} /><span>Ollama · qwen3.5:4b</span></div>
        <p className="mt-1 text-xs text-zinc-500">{modelReady ? 'Local model ready' : modelLoading ? 'Verifying the Ollama model…' : 'Local model not ready'}</p>
        <div role="status" aria-live="polite" aria-atomic="true" className="mt-4 rounded-xl border border-zinc-200 bg-white p-3">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-zinc-500">What the agent is doing now</p>
          <p className="mt-2 flex items-center gap-2 text-sm font-semibold">
            {waiting ? <LoaderCircle size={16} className="animate-spin motion-reduce:animate-none text-cyan-700" /> : phase === 'confirmed' ? <CheckCircle2 size={16} className="text-emerald-700" /> : <CirclePause size={16} className="text-zinc-500" />}
            {ACTIVITY_LABELS[phase]}
          </p>
          <p className="mt-2 text-sm leading-relaxed break-words">{message}</p>
        </div>
        {activity?.url && <p className="mt-3 truncate text-xs text-zinc-500" title={activity.url}>{activity.url}</p>}
        <div className="mt-3 flex justify-between text-xs text-zinc-600">
          <span>Step {activity?.step ?? 0}</span><span>{activity?.confirmed ?? 0} confirmed</span>
        </div>
        {waiting && <p className="mt-2 text-xs text-zinc-500">Waiting {Math.max(0, Math.floor((now - (activity?.timestamp ?? now)) / 1000))}s · input waits for the result</p>}
        {!running && <button type="button" onClick={onInspect} className="mt-3 w-full rounded-lg bg-cyan-800 py-2 text-sm font-semibold text-white hover:bg-cyan-900">Inspect current page</button>}
        {!running && <p className="mt-2 text-xs text-zinc-500">Reads a screenshot locally. Does not click or submit.</p>}
        {running && <button type="button" onClick={onStop} className="mt-3 w-full rounded-lg border border-zinc-300 bg-white py-2 text-sm font-semibold hover:bg-zinc-100 flex justify-center items-center gap-2"><Square size={13} />Stop agent</button>}
      </div>
      <div className="min-h-0 overflow-y-auto p-4">
        <h3 className="text-xs font-semibold text-zinc-600">Recent activity</h3>
        {history.length === 0 ? <p className="mt-3 text-xs leading-relaxed text-zinc-500">Start AutoApply to see the next actions here.</p> : <ol className="mt-3 space-y-3">{history.slice(0, 30).map((item, index): React.JSX.Element => (
          <li key={`${item.timestamp}-${index}`} className="border-l-2 border-cyan-200 pl-3">
            <p className="text-[11px] text-zinc-500">{new Date(item.timestamp).toLocaleTimeString()} · {ACTIVITY_LABELS[item.phase]}</p>
            <p className="mt-1 text-xs leading-relaxed break-words">{item.message}</p>
          </li>
        ))}</ol>}
      </div>
    </aside>
  );
}
