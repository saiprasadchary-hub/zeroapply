/**
 * ZeroApply Form Intelligence - Form Plan & Execution Engine
 * Deep perception, multi-tier planning, comprehensive checkbox management,
 * intelligent submit action execution, and post-submission confirmation verification.
 */

import type { PersonaData } from '../../types';
import type { WebviewTarget } from '../domScanner/injectedScanner';
import { scanFormFields } from '../domScanner/injectedScanner';
import { classifyFields, type ClassifiedField } from '../domScanner/fieldClassifier';
import { fillField } from '../formFiller/formFiller';
import { auditFormFields } from '../formFiller/formAuditor';
import { stepNavigator, type ForwardButtonResult } from '../navigation/wizardStepNavigator';
import { ensureVisualCursor } from '../stealth/agentCursor';
import { scanAndHandleWhatsApp } from '../workflow/whatsappHandler';
import { SubmissionVerifier } from '../normalApply/submissionVerifier';
import { resolveQuestion } from '../localLlm/questionResolver';
import { isGenderQuestion } from '../autofill/genderAnswer';
import { liveTelemetry } from '../telemetry/liveTelemetry';
import { processTracker } from '../tracker/processTracker';

export type CheckboxCategory = 'verification' | 'community' | 'terms' | 'consent' | 'general';

export interface PlannedCheckbox {
  field: ClassifiedField;
  label: string;
  category: CheckboxCategory;
  required: boolean;
  targetState: boolean;
  isCurrentlyChecked: boolean;
}

export interface FormExecutionPlan {
  pageTitle: string;
  url: string;
  formType: 'single_page' | 'wizard_step' | 'unknown';
  stepNumber: number;
  totalFieldsCount: number;
  unfilledInputsCount: number;
  inputsToFill: ClassifiedField[];
  checkboxes: PlannedCheckbox[];
  submitButton: ForwardButtonResult;
  planSummary: string;
}

export interface FormExecutionOptions {
  allowSubmit?: boolean;
  maxSettleWaitMs?: number;
  onStatus?: (status: string) => void;
  onLog?: (log: { message: string; type: 'info' | 'warn' | 'error' | 'success' }) => void;
}

export interface FormExecutionResult {
  success: boolean;
  isSubmitted: boolean;
  isConfirmed: boolean;
  confirmationEvidence?: string;
  fieldsFilled: number;
  checkboxesChecked: number;
  plan: FormExecutionPlan;
  errorMessage?: string;
  userMessage: string;
}

const INJECTED_SUBMIT_CLICK_SCRIPT = `
(async () => {
  try {
    const isVisible = (el) => {
      if (!el) return false;
      if (el.style && (el.style.display === 'none' || el.hidden || el.getAttribute('aria-hidden') === 'true')) return false;
      const r = el.getBoundingClientRect ? el.getBoundingClientRect() : { width: 0, height: 0 };
      return r.width > 0 && r.height > 0;
    };

    // 1. Locate primary submit action button
    const candidates = Array.from(document.querySelectorAll(
      '[data-za-action-target="true"], button[type="submit"], input[type="submit"], button.submit, button[data-automation-id*="submit"], button[data-qa*="submit"], button'
    )).filter(isVisible);

    const submitBtn = candidates.find(b => {
      const t = (b.textContent || b.getAttribute('aria-label') || b.getAttribute('value') || '').trim().toLowerCase();
      if (/mark.*top\\s*choice|premium|upgrade|subscribe|whatsapp|join.*group/i.test(t)) return false;
      return /submit\\s*application|^submit$|apply\\s*now|send\\s*application|complete\\s*application|finish/i.test(t);
    }) || candidates.find(b => {
      const t = (b.textContent || b.getAttribute('aria-label') || b.getAttribute('value') || '').trim().toLowerCase();
      if (/mark.*top\\s*choice|premium|upgrade|subscribe|whatsapp|join.*group/i.test(t)) return false;
      return /submit/i.test(t);
    }) || candidates.find(b => {
      const t = (b.textContent || b.getAttribute('aria-label') || b.getAttribute('value') || '').trim().toLowerCase();
      return !(/mark.*top\\s*choice|premium|upgrade|subscribe|whatsapp|join.*group/i.test(t));
    });

    if (!submitBtn) {
      return { clicked: false, reason: 'Submit button not found' };
    }

    try { submitBtn.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch(e) {}
    try { submitBtn.focus(); } catch(e) {}

    // Integrate with realistic 3D stealth visual cursor if available
    if (window.__zeroapplyCursor && typeof window.__zeroapplyCursor.clickElement === 'function') {
      await window.__zeroapplyCursor.clickElement(submitBtn, 'ZeroApply AI: Submitting Application');
      return {
        clicked: true,
        text: (submitBtn.textContent || submitBtn.getAttribute('aria-label') || 'Submit').trim(),
        selector: submitBtn.id ? '#' + submitBtn.id : submitBtn.className || submitBtn.tagName
      };
    }

    // Dispatch realistic human pointer/mouse sequence
    const opts = { bubbles: true, cancelable: true, view: window };
    submitBtn.dispatchEvent(new PointerEvent('pointerdown', opts));
    submitBtn.dispatchEvent(new MouseEvent('mousedown', opts));
    submitBtn.dispatchEvent(new PointerEvent('pointerup', opts));
    submitBtn.dispatchEvent(new MouseEvent('mouseup', opts));

    let triggeredNativeSubmit = false;
    // For standard HTML form submissions, requestSubmit triggers native validation and payload dispatch
    if (submitBtn.form && typeof submitBtn.form.requestSubmit === 'function') {
      try {
        submitBtn.form.requestSubmit(submitBtn);
        triggeredNativeSubmit = true;
      } catch (e) {
        // Fallback to standard click
      }
    }

    if (!triggeredNativeSubmit) {
      if (typeof submitBtn.click === 'function') {
        submitBtn.click();
      } else {
        submitBtn.dispatchEvent(new MouseEvent('click', opts));
      }
    }

    return {
      clicked: true,
      text: (submitBtn.textContent || submitBtn.getAttribute('aria-label') || 'Submit').trim(),
      selector: submitBtn.id ? '#' + submitBtn.id : submitBtn.className || submitBtn.tagName
    };
  } catch (err) {
    return { clicked: false, error: String(err) };
  }
})()
`;

export class FormPlanEngine {
  private submissionVerifier = new SubmissionVerifier();

  /**
   * Categorizes a form checkbox based on label and contextual cues.
   */
  private categorizeCheckbox(label: string, contextHint = ''): CheckboxCategory {
    const combined = `${contextHint} ${label}`.toLowerCase();
    if (/whatsapp|joined.*(?:community|group|channel)|join.*whatsapp|telegram|discord/i.test(combined)) {
      return 'community';
    }
    if (/verify|accurate|information.*provided|correct|certify|declare|declaration|acknowledg/i.test(combined)) {
      return 'verification';
    }
    if (/terms|condition|privacy|policy|user\\s*agreement/i.test(combined)) {
      return 'terms';
    }
    if (/consent|communications|receive.*updates|marketing|newsletter|email.*updates/i.test(combined)) {
      return 'consent';
    }
    return 'general';
  }

  /**
   * Analyzes the active webpage, detects form structure, catalogs all inputs and checkboxes,
   * finds forward/submit actions, and synthesizes a comprehensive execution plan.
   */
  public async createPlan(
    view: WebviewTarget,
    persona: PersonaData
  ): Promise<FormExecutionPlan> {
    const pageMeta = await view.executeJavaScript<{ title: string; url: string; hasForm: boolean }>(`
      (() => {
        try {
          return {
            title: document.title || '',
            url: window.location.href || '',
            hasForm: Boolean(document.querySelector('form, [role="form"], [data-qa*="form"], [class*="form"]'))
          };
        } catch (e) {
          return { title: '', url: '', hasForm: false };
        }
      })()
    `).catch(() => ({ title: '', url: '', hasForm: false }));

    let scannedFields = await scanFormFields(view);

    // If initial scan found 0 fields, check if there is an "Apply Now" or "Apply for this job" trigger on the page
    if (scannedFields.length === 0) {
      const openedForm = await view.executeJavaScript<boolean>(`
        (() => {
          const btns = Array.from(document.querySelectorAll('button, a, [role="button"], input[type="button"]'));
          const applyBtn = btns.find(b => {
            const t = (b.textContent || b.getAttribute('aria-label') || b.getAttribute('value') || '').trim();
            if (/top\\s*choice|premium|upgrade|whatsapp|join.*group/i.test(t)) return false;
            return /^(?:apply\\s*now|apply\\s*for\\s*this\\s*job|apply\\s*to\\s*this\\s*job|start\\s*application|easy\\s*apply|^apply$)$/i.test(t);
          });
          if (applyBtn) {
            try { applyBtn.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch(e) {}
            applyBtn.click();
            return true;
          }
          return false;
        })()
      `).catch(() => false);

      if (openedForm) {
        await new Promise((r) => setTimeout(r, 1200));
        scannedFields = await scanFormFields(view);
      }
    }

    const classified = classifyFields(scannedFields, persona);

    const inputsToFill: ClassifiedField[] = [];
    const plannedCheckboxes: PlannedCheckbox[] = [];

    for (const field of classified) {
      const isCheckbox = field.inputType === 'checkbox' || field.inputType === 'switch';
      if (isCheckbox) {
        const category = this.categorizeCheckbox(field.label || '', field.contextHint || '');
        const isCurrentlyChecked = field.currentValue === 'true';
        plannedCheckboxes.push({
          field,
          label: field.label || 'Agreement Checkbox',
          category,
          required: Boolean(field.required || category === 'verification' || category === 'terms' || category === 'community'),
          targetState: true,
          isCurrentlyChecked,
        });
      } else if (field.inputType !== 'hidden' && field.inputType !== 'submit' && field.inputType !== 'button') {
        inputsToFill.push(field);
      }
    }

    const submitBtn = await stepNavigator.detectForwardButton(view);
    const unfilledInputs = inputsToFill.filter((f) => !f.currentValue || f.currentValue.trim() === '');

    const checkboxSummaries = plannedCheckboxes.map(
      (c) => `[${c.category.toUpperCase()}] "${c.label.slice(0, 40)}" (Target: Checked)`
    );

    const planSummary = `Form Plan for ${pageMeta.title || 'Page'}: Identified ${inputsToFill.length} input field(s), ${plannedCheckboxes.length} checkbox(es) [${checkboxSummaries.join(', ') || 'None'}], and action button "${submitBtn.text || submitBtn.action}".`;

    return {
      pageTitle: pageMeta.title,
      url: pageMeta.url,
      formType: submitBtn.action === 'next' ? 'wizard_step' : 'single_page',
      stepNumber: 1,
      totalFieldsCount: inputsToFill.length + plannedCheckboxes.length,
      unfilledInputsCount: unfilledInputs.length,
      inputsToFill,
      checkboxes: plannedCheckboxes,
      submitButton: submitBtn,
      planSummary,
    };
  }

  /**
   * Executes the full formulated plan: fills inputs, clicks and verifies all required checkboxes,
   * safely clicks the submit button, and confirms whether submission succeeded.
   */
  public async executePlan(
    view: WebviewTarget,
    persona: PersonaData,
    options: FormExecutionOptions = {}
  ): Promise<FormExecutionResult> {
    const { allowSubmit = true, maxSettleWaitMs = 8000, onStatus, onLog } = options;

    await ensureVisualCursor(view).catch(() => {});

    // Phase 1: Create Plan
    onStatus?.('🧠 Analyzing website form structure & creating execution plan...');
    const plan = await this.createPlan(view, persona);

    liveTelemetry.emit({
      type: 'think',
      title: plan.planSummary,
      status: 'running',
    });
    onLog?.({ message: plan.planSummary, type: 'info' });

    let fieldsFilled = 0;
    let checkboxesChecked = 0;

    // Phase 2: Proactively scan for WhatsApp community invites
    const waResult = await scanAndHandleWhatsApp(view).catch(() => ({ detected: false, links: [] }));
    if (waResult.detected && waResult.links?.length) {
      onStatus?.(`📋 WhatsApp Community invite detected: Copied to clipboard!`);
    }

    // Phase 3: Fill Standard & Custom Inputs
    if (plan.inputsToFill.length > 0) {
      onStatus?.(`✍️ Filling ${plan.inputsToFill.length} form field(s)...`);
      for (const field of plan.inputsToFill) {
        let val = field.mappedValue;
        if (!val || val.trim() === '') {
          // Dynamically resolve novel / screening / custom questions using cognitive question resolver
          const res = await resolveQuestion(field, persona).catch(() => null);
          if (res?.answer) {
            val = res.answer;
          }
        }
        if (!val && !isGenderQuestion(`${field.contextHint || ''} ${field.label || field.name}`) && (field.inputType === 'radio' || (field.options && field.options.length > 0))) {
          if (field.options && field.options.length > 0) {
            const affirmative = field.options.find(o => /^(yes|agree|confirm|true)$/i.test(o.trim()))
              || field.options.find(o => /yes|agree|confirm|true/i.test(o.trim()))
              || field.options[0];
            if (affirmative) {
              val = affirmative;
            }
          }
        }
        if (val) {
          const fillRes = await fillField(view, field, val, persona);
          if (fillRes.success) {
            fieldsFilled++;
            processTracker.recordQuestionAnswer(
              field.label || 'Field',
              val,
              'persona',
              field.inputType
            );
          }
          await new Promise((r) => setTimeout(r, 220 + Math.random() * 150));
        }
      }
    }

    // Phase 4: Handle All Checkboxes ("where are check boxes")
    if (plan.checkboxes.length > 0) {
      onStatus?.(`☑️ Processing and verifying ${plan.checkboxes.length} checkbox(es)...`);
      for (const cb of plan.checkboxes) {
        liveTelemetry.emit({
          type: 'check',
          title: `Checking agreement: "${cb.label.slice(0, 60)}"`,
          target: cb.label,
          status: 'running',
        });

        const fillRes = await fillField(view, cb.field, 'true', persona);
        if (fillRes.success) {
          checkboxesChecked++;
          liveTelemetry.emit({
            type: 'check',
            title: `Successfully checked: "${cb.label.slice(0, 60)}"`,
            target: cb.label,
            status: 'completed',
          });
        } else {
          // Fallback direct execution script for resilient toggle
          const fallbackChecked = await view.executeJavaScript<boolean>(`
            (() => {
              const sel = ${JSON.stringify(cb.field.selector)};
              const el = document.querySelector(sel);
              if (!el) return false;
              if (el.tagName === 'INPUT') {
                const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'checked')?.set;
                if (setter) setter.call(el, true);
                else el.checked = true;
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
                if (!el.checked) {
                  const parentLabel = el.closest('label');
                  if (parentLabel) parentLabel.click();
                }
                return Boolean(el.checked);
              } else {
                el.setAttribute('aria-checked', 'true');
                el.setAttribute('data-state', 'checked');
                el.click();
                return true;
              }
            })()
          `).catch(() => false);

          if (fallbackChecked) {
            checkboxesChecked++;
          }
        }
        await new Promise((r) => setTimeout(r, 200 + Math.random() * 100));
      }
    }

    // Phase 5: Pre-Submission Audit
    onStatus?.('🔍 Auditing form completion before submission...');
    const audit = await auditFormFields(view);
    if (!audit.ready) {
      const msg = `Form needs review: ${[...audit.missingRequired, ...audit.errors].join(', ') || 'Required answers could not be verified.'}`;
      onStatus?.(`⚠️ ${msg}`);
      onLog?.({ message: msg, type: 'warn' });
      return {
        success: false,
        isSubmitted: false,
        isConfirmed: false,
        fieldsFilled,
        checkboxesChecked,
        plan,
        errorMessage: msg,
        userMessage: msg,
      };
    }

    // Phase 6: Submit Button Clicking ("sumbimited button clikcing on it")
    if (!allowSubmit) {
      const reviewMsg = `Form completely filled & checkboxes checked! Safe review mode enabled (submit paused for your review).`;
      onStatus?.(`✅ ${reviewMsg}`);
      return {
        success: true,
        isSubmitted: false,
        isConfirmed: false,
        fieldsFilled,
        checkboxesChecked,
        plan,
        userMessage: reviewMsg,
      };
    }

    onStatus?.('🚀 Submitting application...');
    liveTelemetry.emit({
      type: 'submit',
      title: 'Clicking submit button with visual confirmation',
      status: 'running',
    });

    const submitRes = await view.executeJavaScript<{ clicked: boolean; text?: string; error?: string }>(
      INJECTED_SUBMIT_CLICK_SCRIPT
    ).catch((err: unknown): { clicked: boolean; text?: string; error?: string } => ({ clicked: false, error: String(err) }));

    if (!submitRes.clicked) {
      // Fallback via wizard stepNavigator
      const advanceResult = await stepNavigator.advance(view);
      if (!advanceResult.success) {
        const errorDetail = advanceResult.errorMessages?.join(', ') || submitRes.error || 'No submit action was completed.';
        onStatus?.(`❌ Submission blocked: ${errorDetail}`);
        return {
          success: false,
          isSubmitted: false,
          isConfirmed: false,
          fieldsFilled,
          checkboxesChecked,
          plan,
          errorMessage: errorDetail,
          userMessage: `Submission blocked: ${errorDetail}`,
        };
      }
    }

    if (plan.formType === 'wizard_step' || plan.submitButton.action === 'next') {
      const stepMsg = `Advanced wizard step (${submitRes.text || plan.submitButton.text || 'Next'}).`;
      onStatus?.(`➡️ ${stepMsg}`);
      return {
        success: true,
        isSubmitted: false,
        isConfirmed: false,
        fieldsFilled,
        checkboxesChecked,
        plan,
        userMessage: stepMsg,
      };
    }

    // Phase 7: Post-Submission Confirmation Verification ("conforming it applied or not !")
    onStatus?.('⏳ Verifying submission confirmation from website...');
    const startTime = Date.now();
    let isConfirmed = false;
    let evidence = '';

    while (Date.now() - startTime < maxSettleWaitMs) {
      await new Promise((r) => setTimeout(r, 900));
      const verifyCheck = await this.submissionVerifier.verifySubmission(view);
      if (verifyCheck.isConfirmed) {
        isConfirmed = true;
        evidence = verifyCheck.reason || verifyCheck.details || 'Found confirmation signatures on page';
        break;
      }
    }

    if (isConfirmed) {
      const successMsg = `🎉 Application Confirmed: Successfully submitted to ${plan.pageTitle || 'website'}! (${evidence})`;
      onStatus?.(successMsg);
      liveTelemetry.emit({
        type: 'status',
        title: successMsg,
        status: 'completed',
      });
      processTracker.recordSubmissionCheck(true, successMsg);

      return {
        success: true,
        isSubmitted: true,
        isConfirmed: true,
        confirmationEvidence: evidence,
        fieldsFilled,
        checkboxesChecked,
        plan,
        userMessage: successMsg,
      };
    }

    // If confirmation signatures were not detected, perform secondary check for form disappearance or error indicators
    const secondaryAudit = await view.executeJavaScript<{ hasErrors: boolean; hasInputs: boolean }>(`
      (() => {
        const errors = document.querySelectorAll('.error, [aria-invalid="true"], .invalid-feedback, [class*="error-message"]');
        const visibleInputs = Array.from(document.querySelectorAll('input:not([type="hidden"]), select, textarea')).filter(el => {
          const r = el.getBoundingClientRect();
          return r.width > 0 && r.height > 0;
        });
        return {
          hasErrors: errors.length > 0,
          hasInputs: visibleInputs.length > 0
        };
      })()
    `).catch(() => ({ hasErrors: false, hasInputs: true }));

    if (secondaryAudit.hasErrors) {
      const errorMsg = 'Website indicated validation errors after clicking submit. Please review highlighted fields.';
      onStatus?.(`⚠️ ${errorMsg}`);
      return {
        success: false,
        isSubmitted: true,
        isConfirmed: false,
        fieldsFilled,
        checkboxesChecked,
        plan,
        errorMessage: errorMsg,
        userMessage: errorMsg,
      };
    }

    const completedMsg = `Submission is unconfirmed on ${plan.pageTitle || 'the form'}. Check the website before retrying to avoid a duplicate application.`;
    onStatus?.(`⚠️ ${completedMsg}`);
    processTracker.recordSubmissionCheck(false, completedMsg);
    return {
      success: false,
      isSubmitted: true,
      isConfirmed: false,
      fieldsFilled,
      checkboxesChecked,
      plan,
      errorMessage: completedMsg,
      userMessage: completedMsg,
    };
  }
}

export const formPlanEngine = new FormPlanEngine();
