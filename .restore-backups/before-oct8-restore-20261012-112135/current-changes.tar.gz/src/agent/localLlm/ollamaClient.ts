/**
 * ZeroApply Local Ollama & Neural Bridge Client
 * Primary Target: Qwen 3.5 4B (Instruct) via local Ollama daemon (127.0.0.1:11434)
 * Desktop inference is owned by the verified exact-model Ollama router.
 */
import { generateWebLlmResponse, getWebLlmState } from '../llm/webLlmEngine';

export const DEFAULT_OLLAMA_MODEL = 'qwen3.5:4b';
export const ONLY_LLM_MODEL = 'qwen3.5:4b';
export const OLLAMA_BASE_URL = 'http://127.0.0.1:11434';

let activeModelName: string = DEFAULT_OLLAMA_MODEL;

export function getActiveModelName(): string {
  if (typeof localStorage !== 'undefined') {
    const saved = localStorage.getItem('zeroapply_active_llm_model');
    if (saved !== ONLY_LLM_MODEL) {
      try {
        localStorage.setItem('zeroapply_active_llm_model', ONLY_LLM_MODEL);
      } catch {}
    }
  }
  return ONLY_LLM_MODEL;
}

export function setActiveModelName(modelName: string): void {
  activeModelName = modelName;
  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem('zeroapply_active_llm_model', modelName);
      window.dispatchEvent(new Event('zeroapply_model_changed'));
    } catch {
      // Storage unavailable or disabled
    }
  }
}

export interface OllamaStatus {
  online: boolean;
  modelAvailable: boolean;
  modelName: string;
  latencyMs?: number;
}

export async function fetchInstalledModels(timeoutMs = 2500): Promise<string[]> {
  // 1. Electron Node IPC bridge
  if (typeof window !== 'undefined' && window.zeroApply?.getOllamaStatus) {
    try {
      const status = await window.zeroApply.getOllamaStatus();
      return status?.online && Array.isArray(status.installedModels) ? status.installedModels : [];
    } catch { return []; }
  }

  // 2. Browser direct fetch
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const res = await fetch(`${OLLAMA_BASE_URL}/api/tags`, {
      signal: controller.signal,
    });
    clearTimeout(timer);
    if (res.ok) {
      const data = await res.json();
      const models = (data.models || []).map((m: { name?: string; model?: string }) => m.name || m.model || '');
      if (models.length > 0) return models;
    }
  } catch {
    // Ollama daemon offline
  }
  return [];
}

export async function checkOllamaStatus(timeoutMs = 2500): Promise<OllamaStatus> {
  const targetModel = ONLY_LLM_MODEL;
  if (typeof window !== 'undefined' && window.zeroApply?.startEmbeddedLlm && !window.zeroApply.getOllamaStatus) {
    const ready = getWebLlmState().isReady;
    return { online: ready, modelAvailable: ready, modelName: targetModel };
  }
  const start = Date.now();

  // 1. Electron Node IPC bridge (bypasses browser CORS & zero latency)
  if (typeof window !== 'undefined' && window.zeroApply?.getOllamaStatus) {
    try {
      const status = await window.zeroApply.getOllamaStatus();
      return {
        online: status.online === true,
        modelAvailable: status.online === true && status.modelAvailable === true && status.modelName === targetModel,
        modelName: targetModel,
        latencyMs: Date.now() - start,
      };
    } catch { return { online: false, modelAvailable: false, modelName: targetModel }; }
  }

  // 2. Direct browser fetch to local Ollama daemon
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const res = await fetch(`${OLLAMA_BASE_URL}/api/tags`, {
      signal: controller.signal,
    });
    clearTimeout(timer);

    if (res.ok) {
      const data = await res.json();
      const models: string[] = (data.models || []).map((m: { name?: string; model?: string }) => m.name || m.model || '');
      const modelAvailable = models.includes(targetModel);

      return {
        online: true,
        modelAvailable,
        modelName: targetModel,
        latencyMs: Date.now() - start,
      };
    }
  } catch {
    // Ollama daemon not reachable on 11434
  }

  return { online: false, modelAvailable: false, modelName: targetModel };
}

export async function checkOllamaHealth(timeoutMs = 2500): Promise<boolean> {
  const status = await checkOllamaStatus(timeoutMs).catch(() => ({ online: false }));
  return status.online;
}

export async function pullOllamaModelWithProgress(
  modelName = DEFAULT_OLLAMA_MODEL,
  onProgress?: (percent: number, status: string) => void
): Promise<boolean> {
  try {
    const res = await fetch(`${OLLAMA_BASE_URL}/api/pull`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: modelName, stream: true }),
    });

    if (!res.ok || !res.body) {
      throw new Error(`Failed to pull model ${modelName}: HTTP ${res.status}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (!line.trim()) continue;
        try {
          const parsed = JSON.parse(line);
          if (parsed.status && onProgress) {
            const pct = parsed.total && parsed.completed
              ? Math.round((parsed.completed / parsed.total) * 100)
              : 0;
            onProgress(pct, parsed.status);
          }
        } catch {
          // ignore stream parse glitches
        }
      }
    }

    return true;
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.warn(`[OllamaClient] Pull failed for ${modelName}:`, msg);
    throw new Error(`Could not pull ${modelName} via Ollama. Please ensure Ollama is running: ${msg}`);
  }
}

export async function deleteOllamaModel(modelName = DEFAULT_OLLAMA_MODEL): Promise<boolean> {
  try {
    const res = await fetch(`${OLLAMA_BASE_URL}/api/delete`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: modelName }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function generateOllamaAnswer(
  prompt: string,
  systemPrompt = '',
  temperature = 0,
  maxTokens = 512
): Promise<string> {
  if (typeof window !== 'undefined' && window.zeroApply?.generateEmbeddedLlm) {
    return generateWebLlmResponse(prompt, systemPrompt, temperature, maxTokens);
  }
  if (typeof window !== 'undefined' && window.zeroApply?.queryOllama) {
    return window.zeroApply.queryOllama({ model: ONLY_LLM_MODEL, prompt, systemPrompt, temperature, maxTokens });
  }
  try {
    const response = await fetch(`${OLLAMA_BASE_URL}/api/generate`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: ONLY_LLM_MODEL, prompt, system: systemPrompt, stream: false, think: false,
        options: { temperature, num_predict: Math.max(16, Math.min(512, maxTokens)), num_ctx: 4096 } }),
      signal: AbortSignal.timeout(120000),
    });
    if (!response.ok) return '';
    const data: { model?: string; response?: string } = await response.json();
    return data.model === ONLY_LLM_MODEL && typeof data.response === 'string' ? data.response.trim() : '';
  } catch { return ''; }
}

export const queryOllama = generateOllamaAnswer;

export const ollamaClient = {
  DEFAULT_OLLAMA_MODEL,
  ONLY_LLM_MODEL,
  getActiveModelName,
  setActiveModelName,
  fetchInstalledModels,
  checkOllamaHealth,
  checkOllamaStatus,
  pullOllamaModelWithProgress,
  deleteOllamaModel,
  generateOllamaAnswer,
  queryOllama,
};
