import type { PersonaData } from '../../types';
import { DOM_SCANNER_SCRIPT } from '../domScanner/injectedScanner';
import { formPlanEngine } from '../form/formPlanEngine';

export type OpenApplicationTab = (url: string) => Promise<any>;

export interface StandardFormsEngineOptions {
  openApplicationTab?: OpenApplicationTab;
}

export class StandardFormsEngine {
  private isRunning = false;
  private options: StandardFormsEngineOptions;
  private statusCallback?: (status: string) => void;
  private logCallback?: (log: { message: string; type?: 'info' | 'warn' | 'error' | 'success' }) => void;

  public constructor(options: StandardFormsEngineOptions = {}) {
    this.options = options;
  }

  public setStatusCallback(callback: (status: string) => void): void {
    this.statusCallback = callback;
  }

  public setLogCallback(callback: (log: { message: string; type?: 'info' | 'warn' | 'error' | 'success' }) => void): void {
    this.logCallback = callback;
  }

  public async startBatchApply(
    entry: any,
    persona: PersonaData,
    _platformId = 'standard',
    allowSubmit = false,
    _openTab?: OpenApplicationTab
  ): Promise<void> {
    this.isRunning = true;
    const workflow = { haltBatch: false };
    const effectiveSubmit = allowSubmit && !workflow.haltBatch;

    try {
      if (entry && entry.webview && typeof entry.webview.executeJavaScript === 'function') {
        await entry.webview.executeJavaScript(DOM_SCANNER_SCRIPT);
      }

      const view = (entry && entry.webview) ? entry.webview : entry;
      if (!view || typeof view.executeJavaScript !== 'function') {
        return;
      }

      const maxSteps = 6;
      for (let step = 1; step <= maxSteps && this.isRunning; step++) {
        const stepPrefix = maxSteps > 1 ? ` (Step ${step})` : '';
        this.statusCallback?.(`Planning website form${stepPrefix}: scanning fields, checkboxes & submission actions...`);

        const result = await formPlanEngine.executePlan(view, persona, {
          allowSubmit: effectiveSubmit,
          onStatus: (st) => this.statusCallback?.(st),
          onLog: (lg) => this.logCallback?.(lg),
        });

        if (result.isConfirmed) {
          this.statusCallback?.(result.userMessage);
          break;
        }

        if (result.isSubmitted) {
          this.statusCallback?.(result.userMessage || 'Application submitted! Please verify confirmation on screen.');
          break;
        }

        if (!result.success) {
          if (result.errorMessage) {
            this.statusCallback?.(`Application incomplete: ${result.errorMessage}`);
          }
          break;
        }

        if (!effectiveSubmit) {
          this.statusCallback?.(result.userMessage);
          break;
        }

        // Advanced to next step in a multi-step wizard - brief delay for DOM hydration
        this.statusCallback?.(`Step ${step} completed! Transitioning to next step...`);
        await new Promise((r) => setTimeout(r, 1200));
      }
    } finally {
      this.isRunning = false;
    }
  }

  public stop(): void {
    this.isRunning = false;
  }
}
