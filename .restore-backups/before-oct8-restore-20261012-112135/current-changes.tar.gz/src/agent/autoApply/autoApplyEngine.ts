import { assertSiteAccessible } from '../security/siteAccess';
import type { PersonaData } from '../../types';
import { AgentEngine } from '../orchestrator/agentEngine';
import { ApplicationLogger } from '../tracker/applicationLogger';
import {
  dailyQuotaManager,
  stealthEngine,
  ensureLinkedInSafeSession,
  uncheckLinkedInFollowCompany,
  handleLinkedInJobSafetyReminder,
} from '../stealth';
import { SubmissionVerifier } from '../normalApply/submissionVerifier';
import { orchestrator } from '../workflow/orchestrator';
import { ensureVisualCursor } from '../stealth/agentCursor';
import { processTracker } from '../tracker/processTracker';
import { waitForPageSettled, waitForJobDetailPaneSettled, waitForEasyApplyModalOpened } from '../navigation/pageSettler';
import { ensureAllModalsClosed } from '../recovery/modalDismissGuard';
import { normalApplyEngine } from '../normalApply';
import { isAutoScrollJobsEnabled } from '../../settings/settingsManager';

import type { WebviewTarget } from '../domScanner/injectedScanner';

interface JobCardMetadata { index: number; title: string; company: string; isApplied: boolean; url?: string }
interface ApplyTriggerResult { status: string; url?: string }

export const MAX_APPLICATIONS_PER_RUN = 50;

export function isExpectedPortalUrl(rawUrl: string, expectedDomain: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return false;
    }
    const hostname = parsed.hostname.toLowerCase();
    const domain = expectedDomain.toLowerCase();
    return hostname === domain || hostname.endsWith(`.${domain}`);
  } catch {
    return false;
  }
}

export function isAllowedPlatformHost(hostname: string, expectedHost: string): boolean {
  return hostname === expectedHost || hostname.endsWith(`.${expectedHost}`);
}

export class AutoApplyEngine {
  private isRunning = false;
  private runVersion = 0;
  private agentEngine: AgentEngine = new AgentEngine();
  private statusCallback: ((status: string) => void) | null = null;
  private logCallback: ((log: any) => void) | null = null;

  public setStatusCallback(callback: (status: string) => void): void {
    this.statusCallback = callback;
  }

  public setLogCallback(callback: (log: any) => void): void {
    this.logCallback = callback;
  }

  public getAgentEngine(): AgentEngine {
    return this.agentEngine;
  }

  private notifyStatus(status: string): void {
    if (this.statusCallback) {
      try {
        this.statusCallback(status);
      } catch {}
    }
  }

  private notifyLog(message: string, type: 'info' | 'success' | 'error' | 'warning' = 'info'): void {
    if (this.logCallback) {
      try {
        const now = new Date();
        const timestamp =
          now.getHours().toString().padStart(2, '0') +
          ':' +
          now.getMinutes().toString().padStart(2, '0') +
          ':' +
          now.getSeconds().toString().padStart(2, '0');

        this.logCallback({
          id: Math.random().toString(36).substring(2, 9),
          timestamp,
          message,
          type,
        });
      } catch {}
    }
  }

  public async startBatchApply(
    target: WebviewTarget,
    persona: PersonaData,
    platformLabel = 'LinkedIn',
    allowSubmit = false,
    openTab?: (url?: string) => Promise<any | null>,
    closeTabAndReturn?: (tabView?: any) => Promise<void>,
    options: { stepDelayMs?: number; singleJobOnly?: boolean; maxJobs?: number } = {}
  ): Promise<void> {
    if (this.isRunning) return;
    const version = ++this.runVersion;
    this.isRunning = true;
    const isActive = (): boolean => this.isRunning && this.runVersion === version;
    const view: WebviewTarget = {
      executeJavaScript: async <T>(code: string, userGesture?: boolean): Promise<T> => {
        if (!isActive()) throw new Error('AutoApply stopped.');
        const result = await target.executeJavaScript<T>(code, userGesture);
        if (!isActive()) throw new Error('AutoApply stopped.');
        return result;
      },
    };
    let appliedCount = 0;
    let skippedApplied = 0;
    let missingApply = 0;
    let failedToOpen = 0;
    let pausedForReview = false;
    const workflow = { haltBatch: false };
    const effectiveSubmit = allowSubmit && !workflow.haltBatch;
    const batchLimit = Math.max(1, options.maxJobs ?? persona.applicationLimit ?? 5);
    this.notifyStatus(`Starting Auto-Apply on ${platformLabel}... (Batch Limit: ${batchLimit} jobs, submit=${effectiveSubmit})`);
    this.notifyLog(`AutoApplyEngine started for ${platformLabel} (Batch Limit: ${batchLimit} jobs max, Daily Quota: ${dailyQuotaManager.getRemainingQuota()} remaining)`, 'info');

    try {
      if (!view || typeof view.executeJavaScript !== 'function') {
        throw new Error('Webview view target is unavailable');
      }

      await assertSiteAccessible(view);

      // Enforce Daily Application Safety Quota
      if (!dailyQuotaManager.canApply()) {
        const stats = dailyQuotaManager.getDailyStats();
        this.notifyLog(`Daily application limit reached (${stats.count}/${stats.maxDaily}). Pausing to protect account from platform rate limits.`, 'warning');
        this.notifyStatus(`Daily quota reached (${stats.count}/${stats.maxDaily}). Auto-apply paused until midnight.`);
        this.isRunning = false;
        return;
      }

      // Step 0: Detect target ATS architecture dynamically
      try {
        const { detectAtsArchitecture } = await import('../domScanner/atsDetector');
        const ats = await detectAtsArchitecture(view);
        if (ats && ats.platform !== 'generic_portal') {
          platformLabel = ats.displayName;
          this.notifyLog(`Universal ATS Perception: Identified ${ats.displayName} [${ats.structure}]`, 'info');
        }
      } catch {}

      // Universal modern job card selectors covering LinkedIn search, company pages, Indeed, and testbeds
      const UNIVERSAL_JOB_CARD_SELECTORS = [
        'li.org-jobs-job-search-results-list__list-item',
        '.org-jobs-job-search-results-list li',
        '.org-job-card',
        'li.job-card-list__entity-lockup',
        'li.jobs-search-results-list__list-item',
        'li.jobs-search-results__list-item',
        'div.job-card-container',
        '[data-occludable-job-id]',
        'div[data-job-id]',
        'li[data-occludable-job-id]',
        'div[data-view-name="job-card"]',
        '[data-view-name="job-card"]',
        '.jobs-search-results-list > li',
        '.scaffold-layout__list-container > li',
        '.job-card',
        'div.job_seen_beacon',
        '.base-card',
        '.base-search-card',
      ].join(', ');

      // Step 1: Wait for search page and job listings to fully load and settle (snappy detection)
      this.notifyStatus(`Waiting for ${platformLabel} page to fully load...`);
      await waitForPageSettled(view, {
        timeoutMs: 3500,
        minStableMs: 80,
        requiredSelector: `${UNIVERSAL_JOB_CARD_SELECTORS}, button.jobs-apply-button, [aria-label*="Easy Apply" i], .jobs-s-apply button`,
        checkLoaders: false,
      });

      // Initialize visual cursor on target page
      await ensureVisualCursor(view);

      const detectCardsScript = `
        (() => {
          const cardSelectors = ${JSON.stringify(UNIVERSAL_JOB_CARD_SELECTORS)};
          let rawCards = Array.from(document.querySelectorAll(cardSelectors));
          if (rawCards.length === 0) {
            rawCards = Array.from(document.querySelectorAll('button[aria-label^="Dismiss "][aria-label$=" job"]'))
              .map(button => button.parentElement?.closest('[role="button"], li'))
              .filter(Boolean);
          }
          if (rawCards.length === 0) {
            const jobLinks = Array.from(document.querySelectorAll('a[href*="/jobs/view/"]'));
            rawCards = jobLinks.map((a) => a.closest('li, div.job-card-container, div[data-view-name="job-card"], div.base-card, .org-job-card') || a);
          }
          // Deduplicate nested card elements (keep outer-most card)
          const cards = rawCards.filter((el) => {
            return !rawCards.some((parent) => parent !== el && parent.contains(el));
          });

          return cards.map((c, i) => {
            const dismissLabel = c.querySelector('button[aria-label^="Dismiss "][aria-label$=" job"]')?.getAttribute('aria-label') || '';
            const title = c.querySelector('.job-card__title, .job-card-list__title, .base-search-card__title, .artdeco-entity-lockup__title, h2, h3, a')?.textContent?.trim() || dismissLabel.replace(/^Dismiss /, '').replace(/ job$/, '') || ('Job ' + (i + 1));
            const company = c.querySelector('.job-card__company, .company-name, [class*="company"], .job-card-container__company-name, .job-card-container__primary-description, .artdeco-entity-lockup__subtitle')?.textContent?.trim() || '';
            const isApplied = Array.from(c.querySelectorAll('span, p')).some(el => /^applied$/i.test((el.textContent || '').trim()));
            const url = c.querySelector('a[href*="/jobs/view/"], a[href]')?.href || (c.tagName === 'A' ? c.href : '');
            return { index: i, title, company, isApplied, url };
          });
        })()
      `;

      let detectedCards = (await view.executeJavaScript<JobCardMetadata[]>(detectCardsScript).catch(() => [])) || [];

      // If cards are not rendered yet, check if we need to switch to the company "Jobs" tab
      if (detectedCards.length === 0) {
        const clickedJobsTab = await view.executeJavaScript<boolean>(`
          (() => {
            try {
              const jobsTab = Array.from(document.querySelectorAll(
                'a[href*="/jobs/"], a[data-control-name="org_jobs"], nav.org-page-navigation a, .org-page-navigation a, [data-control-name*="jobs" i]'
              )).find(a => /\\bjobs\\b/i.test(a.textContent || ''));
              if (jobsTab) {
                jobsTab.click();
                return true;
              }
            } catch(e) {}
            return false;
          })()
        `).catch(() => false);

        if (clickedJobsTab) {
          this.notifyStatus('Navigating to company Jobs tab...');
          await waitForPageSettled(view, {
            timeoutMs: 4000,
            minStableMs: 150,
            requiredSelector: `${UNIVERSAL_JOB_CARD_SELECTORS}, a[href*="/jobs/view/"]`,
            checkLoaders: false,
          });
          detectedCards = (await view.executeJavaScript<JobCardMetadata[]>(detectCardsScript).catch(() => [])) || [];
        }
      }

      // If cards are still not rendered yet, nudge the feed scroll to dynamically trigger lazy hydration
      if (detectedCards.length === 0 && isAutoScrollJobsEnabled()) {
        this.notifyStatus('Scanning & scrolling job postings feed...');
        await view.executeJavaScript(`
          (async () => {
            const listContainer = document.querySelector(
              '.jobs-search-results-list, .scaffold-layout__list-detail-inner, .jobs-search__left-rail, ul.jobs-search__results-list, [data-view-name="job-search-results-list"], .scaffold-layout__list-container, .org-jobs-job-search-results-list'
            );
            if (listContainer) {
              listContainer.scrollBy({ top: 350, behavior: 'smooth' });
              await new Promise((r) => setTimeout(r, 200));
              listContainer.scrollTo({ top: 0, behavior: 'smooth' });
            } else {
              window.scrollBy({ top: 300, behavior: 'smooth' });
              await new Promise((r) => setTimeout(r, 200));
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }
          })()
        `).catch(() => {});
        detectedCards = (await view.executeJavaScript<JobCardMetadata[]>(detectCardsScript).catch(() => [])) || [];
      }

      const totalCards = detectedCards.length;

      if (totalCards >= 1) {
        this.notifyLog(`Detected ${totalCards} job postings in search results. Initiating multi-job queue...`, 'info');

        // Fast-path: Check if an Easy Apply modal is ALREADY OPEN right now!
        const isModalAlreadyActive = await view.executeJavaScript<boolean>(`
          (() => {
            function isMessagingElement(el) {
              if (!el) return false;
              try {
                const sel = '.msg-overlay-container, #msg-overlay, #messaging-widget, .msg-overlay-bubble-header, .msg-overlay-list-bubble, .msg-overlay-conversation-bubble, [class*="msg-overlay"], aside[aria-label*="Messaging" i], [data-view-name*="messaging" i]';
                if (el.matches && el.matches(sel)) return true;
                if (el.closest && el.closest(sel)) return true;
              } catch(e) {}
              return false;
            }
            function isTrulyVisible(el) {
              if (!el || el.hidden) return false;
              let curr = el;
              while (curr && curr !== document.body && curr !== document.documentElement) {
                if (curr.style && curr.style.display === 'none') return false;
                if (curr.hidden) return false;
                if (window.getComputedStyle) {
                  const cs = window.getComputedStyle(curr);
                  if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0' || parseFloat(cs.opacity) < 0.1) return false;
                }
                if (curr.id === 'easy-apply-modal-overlay' && !curr.classList.contains('active')) return false;
                curr = curr.parentElement;
              }
              const r = el.getBoundingClientRect ? el.getBoundingClientRect() : { width: 0, height: 0 };
              return r.width > 80 && r.height > 80;
            }
            const modals = Array.from(document.querySelectorAll(
              '#artdeco-modal-outlet .artdeco-modal, .artdeco-modal, [role="dialog"], .jobs-easy-apply-modal, [data-test-modal-id="easy-apply-modal"], .jobs-easy-apply-content, [data-view-name="job-apply-modal"], #easy-apply-modal-overlay.active'
            )).filter(m => {
              if (!m || isMessagingElement(m)) return false;
              if (m.id === 'easy-apply-modal-overlay' && !m.classList.contains('active')) return false;
              return isTrulyVisible(m);
            });
            return modals.some(m => !!m.querySelector('input, select, textarea, .fb-form-element, button.artdeco-button--primary, [data-easy-apply-next-button], [data-easy-apply-submit-button], footer button, .artdeco-modal__actionbar button'));
          })()
        `).catch(() => false);

        if (isModalAlreadyActive) {
          this.notifyStatus('Easy Apply application form is already open on screen. Completing this application first...');
          this.notifyLog('Active application form detected. Running application workflow to completion before browsing other jobs...', 'info');
          const configuredDelay = options.stepDelayMs ?? 400;
          const appResult = await orchestrator.runApplication(view, persona, { maxSteps: 12, stepDelayMs: configuredDelay, allowSubmit: effectiveSubmit, isActive });
          this.notifyLog(`Active form application completed: outcome=${appResult.outcome}, fields=${appResult.fieldsFilled}`, 'success');

          let isEasyApplySubmitted = appResult.outcome === 'submitted';
          if (!isEasyApplySubmitted && this.isRunning) {
            const pageSubmissionDetected = (await new SubmissionVerifier().verifySubmission(view)).isConfirmed;
            if (pageSubmissionDetected) isEasyApplySubmitted = true;
          }

          if (isEasyApplySubmitted) {
            appliedCount++;
            await new Promise((r) => setTimeout(r, 600));
            await ensureVisualCursor(view);
            await view.executeJavaScript(`
              (() => {
                const modal = document.querySelector('#easy-apply-modal-overlay.active, .jobs-easy-apply-modal, [role="dialog"][aria-modal="true"], [role="dialog"], .artdeco-modal');
                if (!modal) return true;
                const notNow = Array.from(modal.querySelectorAll('button, [role="button"]')).find(b => /not\\s*now|no\\s*thanks|maybe\\s*later/i.test((b.textContent || '').trim()));
                if (notNow) { notNow.click(); return true; }
                const close = modal.querySelector('button.artdeco-modal__dismiss, [data-test-modal-close-btn], button:has(svg[data-test-icon*="close"])');
                if (close) { close.click(); return true; }
                return false;
              })()
            `).catch(() => {});
            await new Promise((r) => setTimeout(r, 500));
          } else {
            // Modal is in-progress / paused for review: strictly DO NOT abandon or move to another card!
            this.notifyLog('Active application modal kept open on screen. Please complete or review before continuing.', 'warning');
            this.notifyStatus('Application paused on screen for user review.');
            return;
          }
        }

        for (let cardIndex = 0; cardIndex < Math.min(totalCards, MAX_APPLICATIONS_PER_RUN) && this.isRunning; cardIndex++) {
          if (appliedCount >= batchLimit) {
            this.notifyStatus(`Application batch limit reached (${appliedCount}/${batchLimit} jobs). Completed application pass.`);
            this.notifyLog(`Application batch limit of ${batchLimit} reached (${appliedCount} submitted). Pausing batch.`, 'success');
            break;
          }

          const cardMeta = detectedCards[cardIndex];
          if (cardMeta && (cardMeta.isApplied || ApplicationLogger.hasSubmitted({ jobUrl: cardMeta.url, jobTitle: cardMeta.title, companyName: cardMeta.company, portal: platformLabel }))) {
            skippedApplied++;
            this.notifyLog(`Job ${cardIndex + 1}/${totalCards} (${cardMeta.title}) already applied. Moving to next job...`, 'info');
            continue;
          }

          this.notifyStatus(`Going to job ${cardIndex + 1}/${totalCards}: "${cardMeta?.title || 'Role'}" at "${cardMeta?.company || 'Company'}"`);
          this.notifyLog(`Selecting job card ${cardIndex + 1}/${totalCards}: ${cardMeta?.title}`, 'info');

          processTracker.startNewJob(cardMeta?.title || 'Role', cardMeta?.company || 'Company', platformLabel);

          // Clear any lingering popups/alerts ONLY if no active application modal is open
          const hasOpenModal = await view.executeJavaScript<boolean>(`
            (() => {
              function isMessagingElement(el) {
                if (!el) return false;
                try {
                  const sel = '.msg-overlay-container, #msg-overlay, #messaging-widget, .msg-overlay-bubble-header, .msg-overlay-list-bubble, .msg-overlay-conversation-bubble, [class*="msg-overlay"], aside[aria-label*="Messaging" i], [data-view-name*="messaging" i]';
                  if (el.matches && el.matches(sel)) return true;
                  if (el.closest && el.closest(sel)) return true;
                } catch(e) {}
                return false;
              }
              function isTrulyVisible(el) {
                if (!el || el.hidden) return false;
                let curr = el;
                while (curr && curr !== document.body && curr !== document.documentElement) {
                  if (curr.style && curr.style.display === 'none') return false;
                  if (curr.hidden) return false;
                  if (window.getComputedStyle) {
                    const cs = window.getComputedStyle(curr);
                    if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0' || parseFloat(cs.opacity) < 0.1) return false;
                  }
                  if (curr.id === 'easy-apply-modal-overlay' && !curr.classList.contains('active')) return false;
                  curr = curr.parentElement;
                }
                const r = el.getBoundingClientRect ? el.getBoundingClientRect() : { width: 0, height: 0 };
                return r.width > 80 && r.height > 80;
              }
              const modals = Array.from(document.querySelectorAll(
                '#artdeco-modal-outlet .artdeco-modal, .artdeco-modal, [role="dialog"], .jobs-easy-apply-modal, [data-test-modal-id="easy-apply-modal"], .jobs-easy-apply-content, [data-view-name="job-apply-modal"], #easy-apply-modal-overlay.active'
              )).filter(m => {
                if (!m || isMessagingElement(m)) return false;
                if (m.id === 'easy-apply-modal-overlay' && !m.classList.contains('active')) return false;
                return isTrulyVisible(m);
              });
              return modals.some(m => {
                const hasInteractive = !!m.querySelector('input, select, textarea, .fb-form-element, button.artdeco-button--primary, [data-easy-apply-next-button], [data-easy-apply-submit-button], footer button, .artdeco-modal__actionbar button');
                const hasText = /apply|contact info|resume|screen|question|phone|email/i.test((m.textContent || '').toLowerCase());
                return hasInteractive || hasText;
              });
            })()
          `).catch(() => false);
          if (!hasOpenModal) {
            await ensureAllModalsClosed(view);

            // Ensure LinkedIn session stealth & safety checks
            if (platformLabel.toLowerCase().includes('linkedin')) {
              await ensureLinkedInSafeSession(view);
            }

            // Initialize visual cursor on page
            await ensureVisualCursor(view);

            // Glide cursor to the selected job card and click with smooth scroll
            const clickCardScript = `
              (() => {
                try {
                  const cardSelectors = ${JSON.stringify(UNIVERSAL_JOB_CARD_SELECTORS)};
                  let rawCards = Array.from(document.querySelectorAll(cardSelectors));
                  if (rawCards.length === 0) {
                    rawCards = Array.from(document.querySelectorAll('button[aria-label^="Dismiss "][aria-label$=" job"]'))
                      .map(button => button.parentElement?.closest('[role="button"], li'))
                      .filter(Boolean);
                  }
                  if (rawCards.length === 0) {
                    const jobLinks = Array.from(document.querySelectorAll('a[href*="/jobs/view/"]'));
                    rawCards = jobLinks.map((a) => a.closest('li, div.job-card-container, div[data-view-name="job-card"], div.base-card, .org-job-card') || a);
                  }
                  const cards = rawCards.filter((el) => {
                    return !rawCards.some((parent) => parent !== el && parent.contains(el));
                  });

                  const target = cards[${cardIndex}];
                  if (target) {
                    try {
                      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    } catch(e) {}
                    const allAnchors = target.querySelectorAll('a[target="_blank"]');
                    allAnchors.forEach((a) => {
                      a.removeAttribute('target');
                      a.setAttribute('target', '_self');
                    });
                    if (target.tagName === 'A') {
                      target.removeAttribute('target');
                      target.setAttribute('target', '_self');
                    }
                    const clickTarget = target.querySelector(
                      'a.job-card-list__title, a.job-card-container__link, a[data-control-name*="job_card"], a[href*="/jobs/view/"], .job-card-list__title, .artdeco-entity-lockup__title a, h2 a, h3 a'
                    ) || target;
                    const rect = clickTarget.getBoundingClientRect();
                    if (window.__zeroapplyCursor && typeof window.__zeroapplyCursor.glideTo === 'function') {
                      window.__zeroapplyCursor.glideTo(rect.left + rect.width / 2, rect.top + rect.height / 2, ${JSON.stringify(`AI: View "${cardMeta?.title || 'Job'}"`)});
                    }
                    if (clickTarget && clickTarget.tagName === 'A') {
                      clickTarget.removeAttribute('target');
                      clickTarget.setAttribute('target', '_self');
                    }

                    // Dispatch full pointer and mouse lifecycle to trigger React router/state
                    const evOpts = { bubbles: true, cancelable: true, view: window };
                    if (window.PointerEvent) {
                      try { clickTarget.dispatchEvent(new PointerEvent('pointerdown', evOpts)); } catch(e) {}
                    }
                    clickTarget.dispatchEvent(new MouseEvent('mousedown', evOpts));
                    if (window.PointerEvent) {
                      try { clickTarget.dispatchEvent(new PointerEvent('pointerup', evOpts)); } catch(e) {}
                    }
                    clickTarget.dispatchEvent(new MouseEvent('mouseup', evOpts));
                    try {
                      clickTarget.click();
                    } catch(e) {
                      clickTarget.dispatchEvent(new MouseEvent('click', evOpts));
                    }

                    if (clickTarget !== target) {
                      try {
                        if (window.PointerEvent) target.dispatchEvent(new PointerEvent('pointerdown', evOpts));
                        target.dispatchEvent(new MouseEvent('mousedown', evOpts));
                        if (window.PointerEvent) target.dispatchEvent(new PointerEvent('pointerup', evOpts));
                        target.dispatchEvent(new MouseEvent('mouseup', evOpts));
                        target.click();
                      } catch(e) {}
                    }
                    return true;
                  }
                  return false;
                } catch(e) {
                  return false;
                }
              })()
            `;
            await view.executeJavaScript(clickCardScript).catch(() => false);
            // Wait for job details pane to finish loading (no skeleton loaders, Easy Apply button rendered)
            this.notifyStatus(`Waiting for job details to load: "${cardMeta?.title}"...`);

            // For subsequent jobs, simulate reading scroll; for Card 0, LinkedIn already loads the details pane
            if (cardIndex > 0) {
              await view.executeJavaScript(`
                (() => {
                  try {
                    const pane = document.querySelector(
                      '.scaffold-layout__detail, .jobs-search__job-details, .job-view-layout, .jobs-details, [data-job-details="true"], .jobs-description__container, .jobs-box__html-content'
                    );
                    if (pane && pane.scrollHeight > pane.clientHeight) {
                      pane.scrollBy({ top: 180, behavior: 'smooth' });
                      setTimeout(() => {
                        pane.scrollTo({ top: 0, behavior: 'smooth' });
                      }, 200);
                    }
                  } catch(e) {}
                })()
              `).catch(() => {});
            }
            await waitForJobDetailPaneSettled(view, 3500);
          } else {
            this.notifyLog(`Application modal is already active on screen for "${cardMeta?.title || 'Job'}". Focusing directly on the open form...`, 'info');
          }

          // Check for Easy Apply or External Apply button
          await ensureVisualCursor(view);
          const openModalScript = `
            (function() {
              try {
                function isFilterOrAlertElement(el) {
                  if (!el) return true;
                  if (el.closest(
                    '#global-nav, .global-nav, .filter-bar, .search-filters, .search-reusables__filter-list, .search-reusables__filters-bar-grouping, .jobs-search-box, [class*="pill"], ' +
                    '.jobs-search-create-alert, [data-view-name*="alert"], [class*="alert"], form[action*="alert"], form[action*="jobalert"], ' +
                    '.jobs-search-results-list, .scaffold-layout__list, [data-view-name="job-search-results-list"], .jobs-search-left-rail, ' +
                    '.msg-overlay-container, #msg-overlay, #messaging-widget'
                  )) return true;
                  if (el.getAttribute('role') === 'switch') return true;
                  const label = (el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
                  return /date\s*posted|experience\s*level|company\s*filter|jobs?\s*filter|filter|\balert\b|job\s*alert|search\s*alert|save\s*search|turn.*alert/i.test(label);
                }

                // Fast-path: Check if Easy Apply modal is ALREADY truly open on screen
                function isTrulyVisible(el) {
                  if (!el || el.hidden) return false;
                  let curr = el;
                  while (curr && curr !== document.body && curr !== document.documentElement) {
                    if (curr.style && curr.style.display === 'none') return false;
                    if (curr.hidden) return false;
                    if (window.getComputedStyle) {
                      const cs = window.getComputedStyle(curr);
                      if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0' || parseFloat(cs.opacity) < 0.1) return false;
                    }
                    if (curr.id === 'easy-apply-modal-overlay' && !curr.classList.contains('active')) return false;
                    curr = curr.parentElement;
                  }
                  const r = el.getBoundingClientRect ? el.getBoundingClientRect() : { width: 0, height: 0 };
                  return r.width > 80 && r.height > 80;
                }

                const existingModal = Array.from(document.querySelectorAll(
                  '#artdeco-modal-outlet .artdeco-modal, .artdeco-modal, [role="dialog"], .jobs-easy-apply-modal, [data-test-modal-id="easy-apply-modal"], .jobs-easy-apply-content, [data-view-name="job-apply-modal"], #easy-apply-modal-overlay.active'
                )).find(m => {
                  if (!m || isFilterOrAlertElement(m)) return false;
                  if (m.id === 'easy-apply-modal-overlay' && !m.classList.contains('active')) return false;
                  if (!isTrulyVisible(m)) return false;
                  return !!m.querySelector('input, select, textarea, button.artdeco-button--primary, [data-easy-apply-next-button], [data-easy-apply-submit-button], footer button, .artdeco-modal__actionbar button');
                });
                if (existingModal) {
                  return { status: 'easy_apply_triggered' };
                }

                const detailPane = document.querySelector(
                  '.scaffold-layout__detail, .jobs-search__job-details, .job-view-layout, .jobs-details, .jobs-details__main-content, .job-details-panel, #job-details-panel, [data-job-details="true"], .jobs-description__container, .job-details-jobs-unified-top-card__container--two-pane, .jobs-unified-top-card'
                );

                const applySelectors = [
                  'button.jobs-apply-button',
                  'button#main-easy-apply-btn',
                  '#main-easy-apply-btn',
                  '[data-view-name="job-apply-button"] button',
                  '[data-view-name="job-apply-button"]',
                  'button[data-za-apply-btn]',
                  'button[aria-label*="Easy Apply" i]',
                  'button[aria-label*="Apply" i]',
                  '[aria-label*="Easy Apply" i]',
                  'a.jobs-apply-button',
                  '.jobs-s-apply button',
                  '.jobs-apply-button--top-card button',
                  '[data-control-name*="apply" i]',
                  '[data-qa="btn-apply"]',
                  '[data-automation-id*="apply" i]',
                  '.jobs-unified-top-card button.artdeco-button--primary',
                  '.job-details-jobs-unified-top-card__container--two-pane button.artdeco-button--primary'
                ];

                const isTargetApplyBtn = (b) => {
                  if (!b || b.disabled || b.getAttribute('aria-disabled') === 'true') return false;
                  if (isFilterOrAlertElement(b)) return false;
                  if (b.getAttribute('role') === 'switch') return false;
                  const label = (b.textContent || b.getAttribute('aria-label') || '').trim();
                  if (/date\\s*posted|filter|\\balert\\b|save\\s*job|save\\s*search/i.test(label)) return false;
                  if (b.matches('button.jobs-apply-button, #main-easy-apply-btn, [data-za-apply-btn], [data-view-name="job-apply-button"] button, [data-view-name="job-apply-button"]')) return true;
                  return /^(?:easy\\s*apply|apply|apply\\s*now)$/i.test(label) || /\\b(?:easy\\s*apply|apply\\s*now)\\b/i.test(label);
                };

                let btn = null;
                if (detailPane) {
                  for (const sel of applySelectors) {
                    try {
                      const found = Array.from(detailPane.querySelectorAll(sel)).find(isTargetApplyBtn);
                      if (found) { btn = found; break; }
                    } catch(e) {}
                  }
                }
                if (!btn) {
                  const safeContainers = Array.from(document.querySelectorAll(
                    '.scaffold-layout__detail, .jobs-search__job-details, .job-view-layout, .jobs-details, .jobs-details__main-content, .job-details-jobs-unified-top-card__container--two-pane, .jobs-unified-top-card'
                  ));
                  for (const container of safeContainers) {
                    for (const sel of applySelectors) {
                      try {
                        const found = Array.from(container.querySelectorAll(sel)).find(isTargetApplyBtn);
                        if (found) { btn = found; break; }
                      } catch(e) {}
                    }
                    if (btn) break;
                  }
                }

                if (!btn) {
                  btn = Array.from(document.querySelectorAll('button[aria-label*="Easy Apply" i], button[data-za-apply-btn], button#main-easy-apply-btn'))
                    .find(candidate => candidate.getClientRects().length > 0 && isTargetApplyBtn(candidate)) || null;
                }

                if (btn) {
                  if (btn.tagName !== 'BUTTON' && btn.querySelector('button')) {
                    btn = btn.querySelector('button');
                  }
                  if (btn.disabled || btn.getAttribute('aria-disabled') === 'true') return { status: 'none' };
                  const text = (btn.textContent || btn.getAttribute('aria-label') || '').trim();
                  if (/date\\s*posted/i.test(text)) return { status: 'none' };
                  if (/applied/i.test(text)) return { status: 'none' };
                  if (/\\balert\\b/i.test(text)) return { status: 'none' };

                  if (typeof btn.scrollIntoView === 'function') {
                    btn.scrollIntoView({ behavior: 'auto', block: 'center', inline: 'center' });
                  }

                  const dispatchFullClick = (el) => {
                    try { if (typeof el.focus === 'function') el.focus(); } catch(e) {}
                    const rect = el.getBoundingClientRect();
                    const cx = rect.left + rect.width / 2;
                    const cy = rect.top + rect.height / 2;
                    const evOpts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy };
                    if (window.PointerEvent) {
                      try { el.dispatchEvent(new PointerEvent('pointerdown', evOpts)); } catch(e) {}
                    }
                    el.dispatchEvent(new MouseEvent('mousedown', evOpts));
                    if (window.PointerEvent) {
                      try { el.dispatchEvent(new PointerEvent('pointerup', evOpts)); } catch(e) {}
                    }
                    el.dispatchEvent(new MouseEvent('mouseup', evOpts));
                    try {
                      if (typeof el.click === 'function') el.click();
                      else el.dispatchEvent(new MouseEvent('click', evOpts));
                    } catch(e) {
                      el.dispatchEvent(new MouseEvent('click', evOpts));
                    }
                  };

                  const isEasyApply = /easy\\s*apply|in\\s*apply/i.test(text) || btn.matches('[aria-label*="Easy Apply" i], #main-easy-apply-btn');

                  if (isEasyApply) {
                    const rect = btn.getBoundingClientRect();
                    if (window.__zeroapplyCursor && typeof window.__zeroapplyCursor.glideTo === 'function') {
                      window.__zeroapplyCursor.glideTo(rect.left + rect.width / 2, rect.top + rect.height / 2, 'AI: Click "Easy Apply"');
                    }
                    dispatchFullClick(btn);
                    return { status: 'easy_apply_triggered' };
                  } else {
                    let capturedUrl = '';
                    try {
                      const origOpen = window.open;
                      window.open = function(u) {
                        if (u) capturedUrl = String(u);
                        return origOpen ? origOpen.apply(this, arguments) : null;
                      };
                    } catch(e) {}

                    const link = btn.closest('a')?.href || (btn.tagName === 'A' ? btn.href : '') || btn.getAttribute('data-href') || '';
                    const rect = btn.getBoundingClientRect();
                    if (window.__zeroapplyCursor && typeof window.__zeroapplyCursor.glideTo === 'function') {
                      window.__zeroapplyCursor.glideTo(rect.left + rect.width / 2, rect.top + rect.height / 2, 'AI: Click "Apply" (External)');
                    }
                    dispatchFullClick(btn);
                    return { status: 'external_apply', url: link || capturedUrl };
                  }
                }
                return { status: 'none' };
              } catch(e) {
                return { status: 'none' };
              }
            })()
          `;

          const modalStatus = await view.executeJavaScript<ApplyTriggerResult>(openModalScript).catch((): ApplyTriggerResult => ({ status: 'none' }));
          const statusType = modalStatus?.status || modalStatus;

          if (statusType === 'easy_apply_triggered') {
            processTracker.recordTabOpened('modal');
            if (platformLabel.toLowerCase().includes('linkedin')) {
              await handleLinkedInJobSafetyReminder(view);
            }
            // Wait for Easy Apply application modal to fully open and settle before form filling!
            this.notifyStatus('Waiting for Easy Apply modal to fully load...');
            let modalOpened = await waitForEasyApplyModalOpened(view, 5000);
            if (!modalOpened) {
              this.notifyStatus('Retrying click on Easy Apply button...');
              await view.executeJavaScript<ApplyTriggerResult>(openModalScript).catch((): ApplyTriggerResult => ({ status: 'none' }));
              modalOpened = await waitForEasyApplyModalOpened(view, 4500);
            }
            if (!modalOpened) {
              this.notifyLog(`Easy Apply modal did not appear for "${cardMeta?.title}". Moving to next job posting...`, 'warning');
              failedToOpen++;
              this.notifyStatus(`Modal did not open for "${cardMeta?.title}". Continuing...`);
              continue;
            }
            if (platformLabel.toLowerCase().includes('linkedin')) {
              await handleLinkedInJobSafetyReminder(view);
              await uncheckLinkedInFollowCompany(view);
            }
          } else if (statusType === 'external_apply') {
            if (platformLabel.toLowerCase().includes('linkedin')) {
              await handleLinkedInJobSafetyReminder(view);
            }
            if (openTab) {
              const rawExtUrl = modalStatus?.url || '';
              let externalUrl: string | undefined = undefined;
              if (rawExtUrl) {
                try {
                  const u = new URL(rawExtUrl);
                  const host = u.hostname.toLowerCase();
                  const isInternalPortal = (host.includes('linkedin.com') || host.includes('indeed.com')) && (
                    u.pathname.includes('/jobs/search') ||
                    u.pathname.includes('/jobs/view') ||
                    u.pathname.includes('/jobs/') ||
                    u.searchParams.has('currentJobId')
                  );
                  if (!isInternalPortal) {
                    externalUrl = rawExtUrl;
                  }
                } catch {}
              }
              const extResult = await normalApplyEngine.executeNormalApply(
                {
                  jobTitle: cardMeta?.title || persona.targetRoles[0] || 'Software Engineer',
                  companyName: cardMeta?.company || 'Target Company',
                  platform: platformLabel,
                  externalUrl,
                  cardIndex,
                  jobUrl: cardMeta?.url,
                },
                persona,
                {
                  openTab,
                  closeTabAndReturn,
                  notifyStatus: (s) => this.notifyStatus(s),
                  notifyLog: (m, t) => this.notifyLog(m, t),
                },
                {
                  allowSubmit: effectiveSubmit,

                  stepDelayMs: options.stepDelayMs ?? 650,
                  maxSteps: 15,
                }
              );

              if (extResult.outcome === 'skipped') continue;
              if (extResult.outcome === 'submitted') {
                appliedCount++;
                processTracker.recordMovingToNext(detectedCards[cardIndex + 1]?.title);

                if (options.singleJobOnly) {
                  this.notifyStatus(`Demo finished. External application completed!`);
                  break;
                }

                if (appliedCount >= batchLimit) {
                  this.notifyStatus(`Application batch limit reached (${appliedCount}/${batchLimit} jobs). Completed application pass.`);
                  this.notifyLog(`Completed ${appliedCount} job application(s) (Application Batch Limit: ${batchLimit} reached). Pausing batch.`, 'success');
                  break;
                }

                // Humanized Gaussian inter-application delay
                const interDelay = stealthEngine.getHumanInterApplicationDelay();
                this.notifyLog(`Stealth Pacing: pausing ${(interDelay / 1000).toFixed(1)}s before selecting next job posting...`, 'info');

                await new Promise((r) => setTimeout(r, interDelay));
                continue;
              } else {
                pausedForReview = true;
                this.notifyStatus(extResult.error || 'External application needs completion. Keeping tab open.');
                this.notifyLog(`New tab kept open: application for "${cardMeta?.title || 'Job'}" requires completion before returning to main search list.`, 'warning');
                break;
              }
            }

            this.notifyLog(`Job ${cardIndex + 1} has external application link. Moving to next job...`, 'info');
            await new Promise((r) => setTimeout(r, 600));
            continue;
          } else if (statusType === 'none') {
            missingApply++;
            this.notifyLog(`Job ${cardIndex + 1} has no open apply button. Moving to next job...`, 'info');
            continue;
          }

          this.notifyLog(`Easy Apply modal opened for ${cardMeta?.title}. Executing application with 3D Purple Visual Cursor & Local Qwen...`, 'success');
          await new Promise((r) => setTimeout(r, 150));

          // Execute full orchestrated application with 3D Visual Cursor, OmniVision, and Local Qwen 2.5
          const configuredDelay = options.stepDelayMs ?? 400;
          const appResult = await orchestrator.runApplication(view, persona, { maxSteps: 12, stepDelayMs: configuredDelay, allowSubmit: effectiveSubmit, isActive });
          this.notifyLog(`Applied to "${cardMeta?.title}": outcome=${appResult.outcome}, fields=${appResult.fieldsFilled}`, 'success');

          let isEasyApplySubmitted = appResult.outcome === 'submitted';

          if (!isEasyApplySubmitted) {
            // Robust check: Did submission succeed on the page (e.g. "Applied", "Application was sent", or "Not now" upsell prompt visible)?
            const pageSubmissionDetected = this.isRunning && (await new SubmissionVerifier().verifySubmission(view)).isConfirmed;

            if (pageSubmissionDetected) {
              isEasyApplySubmitted = true;
              this.notifyLog(`Submission confirmed via page inspection for "${cardMeta?.title}".`, 'success');
            }
          }

          processTracker.recordSubmissionCheck(isEasyApplySubmitted, isEasyApplySubmitted ? 'Easy Apply submitted cleanly!' : 'Form advance halted.');

          if (isEasyApplySubmitted) {
            appliedCount++;
            processTracker.recordMovingToNext(detectedCards[cardIndex + 1]?.title);

            // Close success / completion modal so we return cleanly to the search list
            await new Promise((r) => setTimeout(r, 600));
            await ensureVisualCursor(view);
            await view.executeJavaScript(`
              (async () => {
                try {
                  const modal = document.querySelector(
                    '#easy-apply-modal-overlay.active, .jobs-easy-apply-modal, [role="dialog"][aria-modal="true"], [role="dialog"], .artdeco-modal'
                  );
                  // If modal is already closed, do NOT search document and do NOT click anything!
                  if (!modal) return true;

                  // Priority 1: "Not now" button on the post-submission upsell dialog
                  // Strictly dismiss upsell prompts WITHOUT updating candidate profile
                  const allButtons = Array.from(modal.querySelectorAll('button, [role="button"], a.artdeco-button, a[role="button"]'));
                  const notNowBtn = allButtons.find(b => {
                    const txt = (b.textContent || b.getAttribute('aria-label') || '').trim().toLowerCase();
                    if (/update.*profile|save.*profile|add.*skills.*profile|add.*to.*profile/i.test(txt)) return false;
                    return /not\\s*now|no\\s*thanks|maybe\\s*later/i.test(txt);
                  });
                  if (notNowBtn) {
                    if (window.__zeroapplyCursor && typeof window.__zeroapplyCursor.clickElement === 'function') {
                      await window.__zeroapplyCursor.clickElement(notNowBtn, 'AI: Click "Not now" (Skip profile update)');
                    } else {
                      notNowBtn.click();
                    }
                    return true;
                  }

                  // Priority 2: Modal's own Close / Dismiss / 'X' button
                  const closeBtn = modal.querySelector(
                    'button.artdeco-modal__dismiss, [data-test-modal-close-btn], button[data-control-name*="close"], button:has(li-icon[type="cancel-icon"]), button:has(svg[data-test-icon*="close"])'
                  );

                  if (closeBtn) {
                    if (window.__zeroapplyCursor && typeof window.__zeroapplyCursor.clickElement === 'function') {
                      await window.__zeroapplyCursor.clickElement(closeBtn, 'AI: Application Sent! Dismissing confirmation');
                    } else {
                      closeBtn.click();
                    }
                    return true;
                  }

                  // Priority 3: Success "Done" button
                  const doneBtn = modal.querySelector(
                    '#btn-success-done, [data-test-modal-close-btn], .success-view button, [class*="application-submitted"] button, [data-za-action="done"]'
                  );
                  if (doneBtn) {
                    const doneTxt = (doneBtn.textContent || '').trim().toLowerCase();
                    if (!/update.*profile|save.*profile/i.test(doneTxt)) {
                      if (window.__zeroapplyCursor && typeof window.__zeroapplyCursor.clickElement === 'function') {
                        await window.__zeroapplyCursor.clickElement(doneBtn, 'AI: Application Sent! Click Done');
                      } else {
                        doneBtn.click();
                      }
                      return true;
                    }
                  }

                  return false;
                } catch(e) {
                  return false;
                }
              })()
            `).catch(() => {});
            await new Promise((r) => setTimeout(r, 500));
            await ensureAllModalsClosed(view);

            // Log application
            ApplicationLogger.log({
              portal: platformLabel,
              jobTitle: cardMeta?.title || persona.targetRoles[0] || 'Software Engineer',
              companyName: cardMeta?.company || 'Target Company',
              status: 'SUCCESS',
              jobUrl: cardMeta?.url,
              fieldsFilled: appResult.fieldsFilled || 5,
              totalFields: appResult.fieldsFilled || 5,
            });

            dailyQuotaManager.recordApplication();
            const remaining = dailyQuotaManager.getRemainingQuota();
            this.notifyLog(`✓ Submitted application for "${cardMeta?.title}". Daily quota remaining: ${remaining}`, 'success');

            if (options.singleJobOnly) {
              this.notifyStatus(`Demo finished. Application submitted and confirmed!`);
              this.notifyLog(`Single-job demonstration complete. Pausing so you can inspect the result.`, 'success');
              break;
            }

            if (appliedCount >= batchLimit) {
              this.notifyStatus(`Application batch limit reached (${appliedCount}/${batchLimit} jobs). Completed application pass.`);
              this.notifyLog(`Completed ${appliedCount} job application(s) (Application Batch Limit: ${batchLimit} reached). Pausing batch.`, 'success');
              break;
            }

            this.notifyStatus(`Submitted job ${cardIndex + 1}/${totalCards}. Moving to next job...`);

            // Safeguard: halt loop if daily cap reached
            if (!dailyQuotaManager.canApply()) {
              this.notifyLog('Daily application safety limit reached. Pausing batch to safeguard account.', 'warning');
              break;
            }

            // Humanized Gaussian inter-application delay before advancing to next job posting
            const interDelay = stealthEngine.getHumanInterApplicationDelay();
            this.notifyLog(`Stealth Pacing: pausing ${(interDelay / 1000).toFixed(1)}s before selecting next job posting...`, 'info');

            await new Promise((r) => setTimeout(r, interDelay));
          } else {
            // Unsubmitted / in-progress modal: DO NOT close, DO NOT dismiss! Keep open for user review!
            this.notifyLog(`Easy Apply for "${cardMeta?.title}" is open on screen (${appResult.outcome}). Modal kept open for user review.`, 'warning');
            pausedForReview = true;
            this.notifyStatus(`Application paused for "${cardMeta?.title}". Review form on screen.`);
            break;
          }
        }

        if (isActive() && !pausedForReview) {
          this.notifyStatus(appliedCount > 0
            ? `Auto-Apply finished: ${appliedCount} confirmed application(s) for ${platformLabel}.`
            : `No applications submitted: ${skippedApplied} already applied; ${missingApply} without an available Apply button; ${failedToOpen} forms could not open. Review the selected job before retrying.`);
        }
      } else {
        // Fallback for single job detail view
        await ensureVisualCursor(view);

        // Detect job metadata from page
        const singleMetaScript = `
          (() => {
            const title = document.querySelector('#detail-job-title, .jobs-unified-top-card__job-title, h1, h2, .job-details__title')?.textContent?.trim() || '';
            const company = document.querySelector('#detail-company-name, .jobs-unified-top-card__company-name, .job-details__company, .company-name')?.textContent?.trim() || '';
            return { title, company };
          })()
        `;
        const pageMeta = await view.executeJavaScript<{ title: string; company: string }>(singleMetaScript).catch(() => ({ title: '', company: '' }));
        const singleJobTitle = pageMeta?.title || detectedCards[0]?.title || persona.targetRoles[0] || 'Software Engineer';
        const singleCompany = pageMeta?.company || detectedCards[0]?.company || 'Target Company';

        const singleJobUrl = await view.executeJavaScript<string>('window.location.href').catch(() => '');
        if (ApplicationLogger.hasSubmitted({ jobUrl: singleJobUrl, jobTitle: singleJobTitle, companyName: singleCompany, portal: platformLabel })) {
          this.notifyStatus('Already submitted this application. Skipping.');
          return;
        }
        processTracker.startNewJob(singleJobTitle, singleCompany, platformLabel);

        this.notifyStatus('Waiting for job detail view to settle...');
        await waitForPageSettled(view, {
          timeoutMs: 3000,
          minStableMs: 100,
          requiredSelector: 'button.jobs-apply-button, [aria-label*="Easy Apply" i], button#main-easy-apply-btn, a.jobs-apply-button, .jobs-s-apply button, button[data-za-apply-btn], [data-view-name="job-apply-button"] button',
          checkLoaders: false,
        });

        const singleApplyScript = `
          (function() {
            try {
              // Fast-path: Check if Easy Apply modal is ALREADY open
              const existingModal = document.querySelector(
                '#artdeco-modal-outlet .artdeco-modal, .jobs-easy-apply-modal, [role="dialog"], #easy-apply-modal-overlay.active'
              );
              if (existingModal) {
                const hasControls = !!existingModal.querySelector(
                  'input, select, textarea, button.artdeco-button--primary, [data-easy-apply-next-button], [data-easy-apply-submit-button], footer button, .artdeco-modal__actionbar button'
                );
                if (hasControls) {
                  return { status: 'easy_apply_triggered' };
                }
              }

              const isFilterOrAlertElement = (el) => {
                if (!el) return true;
                if (el.closest(
                  '#global-nav, .global-nav, .filter-bar, .search-filters, .search-reusables__filter-list, .search-reusables__filters-bar-grouping, .jobs-search-box, [class*="pill"], ' +
                  '.jobs-search-create-alert, [data-view-name*="alert"], [class*="alert"], form[action*="alert"], form[action*="jobalert"], ' +
                  '.jobs-search-results-list, .scaffold-layout__list, [data-view-name="job-search-results-list"], .jobs-search-left-rail, ' +
                  '.msg-overlay-container, #msg-overlay, #messaging-widget'
                )) return true;
                if (el.getAttribute('role') === 'switch') return true;
                const label = (el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
                return /date\\s*posted|experience\\s*level|company\\s*filter|jobs?\\s*filter|filter|\\balert\\b|job\\s*alert|search\\s*alert|save\\s*search|turn.*alert/i.test(label);
              };

              const applySelectors = [
                'button.jobs-apply-button',
                'button#main-easy-apply-btn',
                '#main-easy-apply-btn',
                '[data-view-name="job-apply-button"] button',
                '[data-view-name="job-apply-button"]',
                'button[data-za-apply-btn]',
                'button[aria-label*="Easy Apply" i]',
                'button[aria-label*="Apply" i]',
                '[aria-label*="Easy Apply" i]',
                'a.jobs-apply-button',
                '.jobs-s-apply button',
                '.jobs-apply-button--top-card button',
                '[data-control-name*="apply" i]',
                '[data-qa="btn-apply"]',
                '[data-automation-id*="apply" i]',
                '.jobs-unified-top-card button.artdeco-button--primary',
                '.job-details-jobs-unified-top-card__container--two-pane button.artdeco-button--primary'
              ];

              const isTargetApplyBtn = (b) => {
                if (!b || b.disabled || b.getAttribute('aria-disabled') === 'true') return false;
                if (isFilterOrAlertElement(b)) return false;
                if (b.getAttribute('role') === 'switch') return false;
                const label = (b.textContent || b.getAttribute('aria-label') || '').trim();
                if (/date\\s*posted|filter|\\balert\\b|save\\s*job|save\\s*search/i.test(label)) return false;
                if (b.matches('button.jobs-apply-button, #main-easy-apply-btn, [data-za-apply-btn], [data-view-name="job-apply-button"] button, [data-view-name="job-apply-button"]')) return true;
                return /^(?:easy\\s*apply|apply|apply\\s*now)$/i.test(label) || /\\b(?:easy\\s*apply|apply\\s*now)\\b/i.test(label);
              };

              let btn = null;
              const detailPane = document.querySelector(
                '.scaffold-layout__detail, .jobs-search__job-details, .job-view-layout, .jobs-details, .jobs-details__main-content, .job-details-panel, #job-details-panel, [data-job-details="true"], .jobs-description__container, .job-details-jobs-unified-top-card__container--two-pane, .jobs-unified-top-card'
              );
              if (detailPane) {
                for (const sel of applySelectors) {
                  try {
                    const found = Array.from(detailPane.querySelectorAll(sel)).find(isTargetApplyBtn);
                    if (found) { btn = found; break; }
                  } catch(e) {}
                }
              }
              if (!btn) {
                const safeContainers = Array.from(document.querySelectorAll(
                  '.scaffold-layout__detail, .jobs-search__job-details, .job-view-layout, .jobs-details, .jobs-details__main-content, .job-details-jobs-unified-top-card__container--two-pane, .jobs-unified-top-card'
                ));
                for (const container of safeContainers) {
                  for (const sel of applySelectors) {
                    try {
                      const found = Array.from(container.querySelectorAll(sel)).find(isTargetApplyBtn);
                      if (found) { btn = found; break; }
                    } catch(e) {}
                  }
                  if (btn) break;
                }
              }

              if (!btn) {
                btn = Array.from(document.querySelectorAll('button[aria-label*="Easy Apply" i], button[data-za-apply-btn], button#main-easy-apply-btn'))
                  .find(candidate => candidate.getClientRects().length > 0 && isTargetApplyBtn(candidate)) || null;
              }

              if (btn) {
                if (btn.tagName !== 'BUTTON' && btn.querySelector('button')) {
                  btn = btn.querySelector('button');
                }
                if (btn.disabled || btn.getAttribute('aria-disabled') === 'true') return { status: 'none' };
                const text = (btn.textContent || btn.getAttribute('aria-label') || '').trim();
                if (/date\\s*posted/i.test(text)) return { status: 'none' };
                if (/applied/i.test(text)) return { status: 'none' };
                if (/\\balert\\b/i.test(text)) return { status: 'none' };

                if (typeof btn.scrollIntoView === 'function') {
                  btn.scrollIntoView({ behavior: 'auto', block: 'center', inline: 'center' });
                }

                const dispatchFullClick = (el) => {
                  try { if (typeof el.focus === 'function') el.focus(); } catch(e) {}
                  const rect = el.getBoundingClientRect();
                  const cx = rect.left + rect.width / 2;
                  const cy = rect.top + rect.height / 2;
                  const evOpts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy };
                  if (window.PointerEvent) {
                    try { el.dispatchEvent(new PointerEvent('pointerdown', evOpts)); } catch(e) {}
                  }
                  el.dispatchEvent(new MouseEvent('mousedown', evOpts));
                  if (window.PointerEvent) {
                    try { el.dispatchEvent(new PointerEvent('pointerup', evOpts)); } catch(e) {}
                  }
                  el.dispatchEvent(new MouseEvent('mouseup', evOpts));
                  try {
                    if (typeof el.click === 'function') el.click();
                    else el.dispatchEvent(new MouseEvent('click', evOpts));
                  } catch(e) {
                    el.dispatchEvent(new MouseEvent('click', evOpts));
                  }
                };

                const isEasyApply = /easy\\s*apply|in\\s*apply/i.test(text) || btn.matches('[aria-label*="Easy Apply" i], #main-easy-apply-btn');

                if (isEasyApply) {
                  const rect = btn.getBoundingClientRect();
                  if (window.__zeroapplyCursor && typeof window.__zeroapplyCursor.glideTo === 'function') {
                    window.__zeroapplyCursor.glideTo(rect.left + rect.width / 2, rect.top + rect.height / 2, 'AI: Click "Easy Apply"');
                  }
                  dispatchFullClick(btn);
                  return { status: 'easy_apply' };
                } else {
                  let capturedUrl = '';
                  try {
                    const origOpen = window.open;
                    window.open = function(u) {
                      if (u) capturedUrl = String(u);
                      return origOpen ? origOpen.apply(this, arguments) : null;
                    };
                  } catch(e) {}

                  const link = btn.closest('a')?.href || (btn.tagName === 'A' ? btn.href : '') || btn.getAttribute('data-href') || '';
                  const rect = btn.getBoundingClientRect();
                  if (window.__zeroapplyCursor && typeof window.__zeroapplyCursor.glideTo === 'function') {
                    window.__zeroapplyCursor.glideTo(rect.left + rect.width / 2, rect.top + rect.height / 2, 'AI: Click "Apply" (External)');
                  }
                  dispatchFullClick(btn);
                  return { status: 'external_apply', url: link || capturedUrl };
                }
              }
              return { status: 'none' };
            } catch(e) {
              return { status: 'none' };
            }
          })()
        `;

        const applyResult = await view.executeJavaScript<ApplyTriggerResult>(singleApplyScript).catch((): ApplyTriggerResult => ({ status: 'none' }));

        if (applyResult?.status === 'external_apply' && openTab) {
          const extResult = await normalApplyEngine.executeNormalApply(
            {
              jobTitle: singleJobTitle,
              companyName: singleCompany,
              platform: platformLabel,
              externalUrl: applyResult.url || undefined,
            },
            persona,
            {
              openTab,
              closeTabAndReturn,
              notifyStatus: (s) => this.notifyStatus(s),
              notifyLog: (m, t) => this.notifyLog(m, t),
            },
            {
              allowSubmit: effectiveSubmit,

              stepDelayMs: options.stepDelayMs ?? 650,
              maxSteps: 15,
            }
          );

          if (extResult.outcome === 'submitted') {
            this.notifyStatus(`Normal application complete! Returned to 1st tab.`);
          } else {
            this.notifyStatus(extResult.error || 'Normal application tab kept open until completely filled and submitted.');
          }
          return;
        }

        if (applyResult?.status === 'easy_apply') {
          processTracker.recordTabOpened('modal');
          this.notifyStatus('Waiting for Easy Apply application modal to fully load...');
          const modalOpened = await waitForEasyApplyModalOpened(view, 8000);
          if (!modalOpened) {
            this.notifyLog('Easy Apply modal did not appear. Aborting form filling.', 'warning');
            this.notifyStatus('Modal did not open. Aborting.');
            return;
          }
          this.notifyLog('Easy Apply modal opened and fully settled', 'success');
        } else if (applyResult?.status === 'none') {
          // If no apply button was clicked, verify if an application modal or form is already open
          const hasOpenModalOrForm = await view.executeJavaScript<boolean>(`
            Boolean(document.querySelector(
              '.jobs-easy-apply-modal, [role="dialog"][aria-modal="true"], [role="dialog"], .artdeco-modal, form[data-view-name*="apply"], form[class*="application"]'
            ))
          `).catch(() => false);
          if (!hasOpenModalOrForm) {
            this.notifyStatus('No open Easy Apply button or application form found on page.');
            this.notifyLog('No apply button or active application modal found to fill.', 'warning');
            return;
          }
        }

        // Execute full orchestrated application with 3D Purple Visual Cursor & Local Qwen
        await ensureVisualCursor(view);
        const appRes = await orchestrator.runApplication(view, persona, { maxSteps: 12, stepDelayMs: 400, allowSubmit: effectiveSubmit, isActive });
        this.notifyLog(`Application completed: outcome=${appRes.outcome}, fields=${appRes.fieldsFilled}`, 'success');

        let isEasyApplySubmitted = appRes.outcome === 'submitted';

        if (!isEasyApplySubmitted) {
          const pageSubmissionDetected = this.isRunning && (await new SubmissionVerifier().verifySubmission(view)).isConfirmed;

          if (pageSubmissionDetected) {
            isEasyApplySubmitted = true;
            this.notifyLog(`Submission confirmed via page inspection.`, 'success');
          }
        }

        processTracker.recordSubmissionCheck(isEasyApplySubmitted, isEasyApplySubmitted ? 'Easy Apply submitted cleanly!' : 'Form advance halted.');

        if (isEasyApplySubmitted) {
          // Close completion modal with visual cursor ONLY when submitted
          await new Promise((r) => setTimeout(r, 600));
          await view.executeJavaScript(`
            (async () => {
              try {
                const modal = document.querySelector(
                  '#easy-apply-modal-overlay.active, .jobs-easy-apply-modal, [role="dialog"][aria-modal="true"], [role="dialog"], .artdeco-modal'
                );
                // If modal is already closed, do NOT search document and do NOT click anything!
                if (!modal) return true;

                // Priority 1: "Not now" button on the post-submission upsell dialog
                // Strictly dismiss upsell prompts WITHOUT updating candidate profile
                const allButtons = Array.from(modal.querySelectorAll('button, [role="button"], a.artdeco-button, a[role="button"]'));
                const notNowBtn = allButtons.find(b => {
                  const txt = (b.textContent || b.getAttribute('aria-label') || '').trim().toLowerCase();
                  if (/update.*profile|save.*profile|add.*skills.*profile|add.*to.*profile/i.test(txt)) return false;
                  return /not\\s*now|no\\s*thanks|maybe\\s*later/i.test(txt);
                });
                if (notNowBtn) {
                  if (window.__zeroapplyCursor && typeof window.__zeroapplyCursor.clickElement === 'function') {
                    await window.__zeroapplyCursor.clickElement(notNowBtn, 'AI: Click "Not now" (Skip profile update)');
                  } else {
                    notNowBtn.click();
                  }
                  return true;
                }

                // Priority 2: Modal's own Close / Dismiss / 'X' button
                const closeBtn = modal.querySelector(
                  'button.artdeco-modal__dismiss, [data-test-modal-close-btn], button[data-control-name*="close"], button:has(li-icon[type="cancel-icon"]), button:has(svg[data-test-icon*="close"])'
                );

                if (closeBtn) {
                  if (window.__zeroapplyCursor && typeof window.__zeroapplyCursor.clickElement === 'function') {
                    await window.__zeroapplyCursor.clickElement(closeBtn, 'AI: Application Sent! Dismissing confirmation');
                  } else {
                    closeBtn.click();
                  }
                  return true;
                }

                // Priority 3: Success "Done" button
                const doneBtn = modal.querySelector(
                  '#btn-success-done, [data-test-modal-close-btn], .success-view button, [class*="application-submitted"] button, [data-za-action="done"]'
                );
                if (doneBtn) {
                  const doneTxt = (doneBtn.textContent || '').trim().toLowerCase();
                  if (!/update.*profile|save.*profile/i.test(doneTxt)) {
                    if (window.__zeroapplyCursor && typeof window.__zeroapplyCursor.clickElement === 'function') {
                      await window.__zeroapplyCursor.clickElement(doneBtn, 'AI: Application Sent! Click Done');
                    } else {
                      doneBtn.click();
                    }
                    return true;
                  }
                }
                return false;
              } catch(e) {
                return false;
              }
            })()
          `).catch(() => {});
          await new Promise((r) => setTimeout(r, 400));
          await ensureAllModalsClosed(view);

          ApplicationLogger.log({
            portal: platformLabel,
            jobTitle: singleJobTitle,
            companyName: singleCompany,
            status: 'SUCCESS',
            jobUrl: singleJobUrl,
            fieldsFilled: appRes.fieldsFilled,
            totalFields: Math.max(appRes.fieldsFilled, 5),
          });

          dailyQuotaManager.recordApplication();
          this.notifyStatus(`Application successfully submitted for ${platformLabel}!`);
          this.notifyLog(`Application submitted and confirmed for "${singleJobTitle}"!`, 'success');
        } else {
          // Unsubmitted / in-progress modal: DO NOT close, DO NOT dismiss! Keep open for user review!
          this.notifyLog(`Easy Apply for "${singleJobTitle}" is open on screen (${appRes.outcome}). Modal kept open for user review.`, 'warning');
          this.notifyStatus(`Application paused for "${singleJobTitle}". Review form on screen.`);
        }
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      this.notifyLog(`AutoApply error: ${msg}`, 'error');
      console.error('[AutoApplyEngine] Error:', err);
    } finally {
      if (this.runVersion === version) this.isRunning = false;
    }
  }

  public stop(): void {
    this.runVersion++;
    this.isRunning = false;
    this.agentEngine.stop();
    this.notifyStatus('AutoApply stopped');
    this.notifyLog('AutoApply stopped by user', 'warning');
  }
}
