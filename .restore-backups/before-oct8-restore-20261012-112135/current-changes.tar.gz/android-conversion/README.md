# ZeroApply Android interface

Packages the shared responsive interface with Capacitor. Browser, profile, resume and account features remain available. Native phone inference, GGUF downloads and the standalone model runtime have been removed.

AI automation requires the Electron desktop app with Ollama and `qwen3.5:4b`. Android model-start and generation requests return an explicit desktop-required error; the Android app does not connect to the desktop computer or run a model itself.

The Android workflow builds and verifies the interface and native browser. It no longer downloads or bundles model weights or compiles a native AI runtime. Generated Android projects and old APKs must be rebuilt to reflect this change.

Keep existing Firebase configuration and signing keys for compatible account access and local updates. Do not commit private signing keys.
