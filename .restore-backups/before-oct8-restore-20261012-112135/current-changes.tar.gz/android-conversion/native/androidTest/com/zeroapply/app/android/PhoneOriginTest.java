package com.zeroapply.app.android;

import static org.junit.Assert.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class PhoneOriginTest {
    @Test public void secureLinkedInOrigins() {
        assertTrue(PhoneAgentPlugin.linkedInUrl("https://www.linkedin.com/jobs/"));
        assertFalse(PhoneAgentPlugin.linkedInUrl("http://www.linkedin.com/jobs/"));
        assertFalse(PhoneAgentPlugin.linkedInUrl("https://linkedin.com.evil.example/"));
        assertFalse(PhoneAgentPlugin.linkedInUrl("https://evil.example/?linkedin.com"));
        assertFalse(PhoneAgentPlugin.linkedInUrl("https://user@linkedin.com/"));
        assertFalse(PhoneAgentPlugin.linkedInUrl("https://linkedin.com:444/"));
    }
}
